import { z } from "zod";

export const contactInfoSchema = z.object({
  emails: z.array(z.string().email()).default([]),
  telegram: z.array(z.string()).default([]),
  phones: z.array(z.string()).default([]),
  website: z.string().optional(),
});

export const eventSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string(),
  eventUrl: z.string().url(),
  date: z.string().optional(),
  location: z.enum(['МОСКВА', 'СПб', 'Онлайн', 'Международное']),
  category: z.string(),
  organizerInfo: contactInfoSchema.optional(),
  relevanceScore: z.number().min(0).max(100),
  priority: z.enum(['high', 'medium', 'low']),
  status: z.enum(['pending', 'processing', 'analyzed', 'accepted', 'rejected']),
  aiPitch: z.string().optional(),
});

export const insertEventSchema = eventSchema.omit({ id: true });

export const generatedLetterSchema = z.object({
  id: z.string(),
  eventId: z.string(),
  speakerProfile: z.enum(['corporate', 'crypto']),
  letterContent: z.string(),
  generatedAt: z.string(),
});

export const insertGeneratedLetterSchema = generatedLetterSchema.omit({ id: true, generatedAt: true });

export const generateLetterRequestSchema = z.object({
  eventId: z.string(),
  speakerProfile: z.enum(['corporate', 'crypto']),
});

export const eventFeedbackSchema = z.object({
  id: z.string(),
  eventId: z.string(),
  isGoodFit: z.boolean(),
  reason: z.string().optional(),
  createdAt: z.string(),
});

export const insertEventFeedbackSchema = eventFeedbackSchema.omit({ id: true, createdAt: true });

export const searchCriteriaSchema = z.object({
  id: z.string(),
  query: z.string(),
  location: z.enum(['МОСКВА', 'СПб', 'Онлайн', 'Международное', 'Все']).default('Все'),
  categories: z.array(z.string()).default([]),
  dateFrom: z.string().optional(),
  dateTo: z.string().optional(),
});

export const insertSearchCriteriaSchema = searchCriteriaSchema.omit({ id: true });

export const metricsSchema = z.object({
  totalEventsFound: z.number(),
  totalProcessed: z.number(),
  totalAccepted: z.number(),
  totalRejected: z.number(),
  successRate: z.number(),
  topCategories: z.array(z.object({
    category: z.string(),
    count: z.number(),
  })),
});

export type ContactInfo = z.infer<typeof contactInfoSchema>;
export type Event = z.infer<typeof eventSchema>;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type GeneratedLetter = z.infer<typeof generatedLetterSchema>;
export type InsertGeneratedLetter = z.infer<typeof insertGeneratedLetterSchema>;
export type GenerateLetterRequest = z.infer<typeof generateLetterRequestSchema>;
export type EventFeedback = z.infer<typeof eventFeedbackSchema>;
export type InsertEventFeedback = z.infer<typeof insertEventFeedbackSchema>;
export type SearchCriteria = z.infer<typeof searchCriteriaSchema>;
export type InsertSearchCriteria = z.infer<typeof insertSearchCriteriaSchema>;
export type Metrics = z.infer<typeof metricsSchema>;
