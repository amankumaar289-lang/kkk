import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Radar, Target } from "lucide-react";

interface VladykaMetrics {
  totalOpportunities: number;
  byStatus: {
    scouted: number;
    verified: number;
    analyzing: number;
    attack_ready: number;
    sent: number;
    rejected: number;
  };
  avgScores: {
    alpha: number;
    bravo: number;
  };
}

interface MetricsDashboardProps {
  metrics: VladykaMetrics;
}

export function MetricsDashboard({ metrics }: MetricsDashboardProps) {

  return (
    <div className="h-full bg-card border-l border-border p-6 space-y-6 overflow-y-auto">
      <div className="space-y-2">
        <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
          <Radar className="w-5 h-5 text-primary" />
          Протокол Владыка
        </h2>
        <p className="text-sm text-muted-foreground">
          4 фазы автоматизации
        </p>
      </div>

      <Card className="bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm border border-primary/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Всего Opportunities
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <div className="text-4xl font-bold font-mono text-foreground" data-testid="text-total-processed">
              {metrics.totalOpportunities}
            </div>
            <div className="text-sm text-muted-foreground mt-1">
              в базе данных
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <Target className="w-4 h-4" />
            Средние скоры
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Alpha (Разведка)</span>
              <span className="text-2xl font-bold text-blue-500 font-mono" data-testid="text-alpha-score">
                {metrics.avgScores.alpha}/100
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Bravo (Верификация)</span>
              <span className="text-2xl font-bold text-green-500 font-mono" data-testid="text-bravo-score">
                {metrics.avgScores.bravo}/100
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            По статусам
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">🔍 Scouted</span>
            <span className="text-sm font-bold font-mono" data-testid="text-status-scouted">
              {metrics.byStatus.scouted}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">✅ Verified</span>
            <span className="text-sm font-bold font-mono text-blue-500" data-testid="text-status-verified">
              {metrics.byStatus.verified}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">🧠 Analyzing</span>
            <span className="text-sm font-bold font-mono" data-testid="text-status-analyzing">
              {metrics.byStatus.analyzing}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">🎯 Attack Ready</span>
            <span className="text-sm font-bold font-mono text-priority-high" data-testid="text-status-attack-ready">
              {metrics.byStatus.attack_ready}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">📨 Sent</span>
            <span className="text-sm font-bold font-mono text-green-600" data-testid="text-status-sent">
              {metrics.byStatus.sent}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">❌ Rejected</span>
            <span className="text-sm font-bold font-mono text-destructive" data-testid="text-status-rejected">
              {metrics.byStatus.rejected}
            </span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
