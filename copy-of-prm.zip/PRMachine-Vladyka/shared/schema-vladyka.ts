import { pgTable, text, integer, boolean, timestamp, jsonb, uuid, index } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// ============================================================================
// ТАБЛИЦА: intel_assets - Арсенал интеллектуальных активов
// ============================================================================
export const intel_assets = pgTable("intel_assets", {
  id: uuid("id").primaryKey().defaultRandom(),
  asset_type: text("asset_type").notNull(), // "speaker_profile", "prompt_template", "email_example"
  name: text("name").notNull(),
  content: text("content").notNull(),
  metadata: jsonb("metadata").default({}).notNull(),
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  assetTypeIdx: index("idx_asset_type").on(table.asset_type),
}));

export const insertIntelAssetSchema = createInsertSchema(intel_assets);
export const selectIntelAssetSchema = createSelectSchema(intel_assets);

// ============================================================================
// ТАБЛИЦА: opportunities - Возможности (мероприятия)
// ============================================================================
export const opportunities = pgTable("opportunities", {
  id: uuid("id").primaryKey().defaultRandom(),
  
  // Основная информация
  title: text("title").notNull(),
  description: text("description").notNull(),
  event_url: text("event_url").notNull(),
  event_date: text("event_date"),
  location: text("location").notNull(), // МОСКВА, СПб, Онлайн, Международное
  category: text("category").notNull(),
  
  // Протокол "Владыка" - статусы фаз
  status: text("status").notNull().default("scouted"), 
  // scouted -> verified -> analyzing -> attack_ready -> sent -> rejected
  
  // Скоринг
  alpha_score: integer("alpha_score"), // Разведка (0-100)
  bravo_score: integer("bravo_score"), // Верификация (0-100)
  priority: text("priority").notNull().default("medium"), // high, medium, low
  
  // AI анализ
  ai_analysis: text("ai_analysis"),
  key_insights: jsonb("key_insights").default([]).notNull(), // массив инсайтов
  
  // Временные метки
  scouted_at: timestamp("scouted_at").defaultNow().notNull(),
  verified_at: timestamp("verified_at"),
  analyzed_at: timestamp("analyzed_at"),
  attack_ready_at: timestamp("attack_ready_at"),
  
  // Метаданные
  raw_search_data: jsonb("raw_search_data").default({}).notNull(),
}, (table) => ({
  statusIdx: index("idx_status").on(table.status),
  priorityIdx: index("idx_priority").on(table.priority),
  locationIdx: index("idx_location").on(table.location),
}));

export const insertOpportunitySchema = createInsertSchema(opportunities);
export const selectOpportunitySchema = createSelectSchema(opportunities);

// ============================================================================
// ТАБЛИЦА: contacts - Контакты организаторов
// ============================================================================
export const contacts = pgTable("contacts", {
  id: uuid("id").primaryKey().defaultRandom(),
  opportunity_id: uuid("opportunity_id").notNull().references(() => opportunities.id, { onDelete: 'cascade' }),
  
  // Контактная информация
  email: text("email"),
  telegram: text("telegram"),
  phone: text("phone"),
  name: text("name"),
  role: text("role"),
  
  // Дополнительные данные
  linkedin_url: text("linkedin_url"),
  notes: text("notes"),
  
  // Временные метки
  created_at: timestamp("created_at").defaultNow().notNull(),
  
  // Метаданные
  extraction_source: text("extraction_source"), // URL или способ получения контакта
}, (table) => ({
  opportunityIdx: index("idx_opportunity_id").on(table.opportunity_id),
}));

export const insertContactSchema = createInsertSchema(contacts);
export const selectContactSchema = createSelectSchema(contacts);

// ============================================================================
// ТАБЛИЦА: attacks - Сгенерированные письма для атаки
// ============================================================================
export const attacks = pgTable("attacks", {
  id: uuid("id").primaryKey().defaultRandom(),
  opportunity_id: uuid("opportunity_id").notNull().references(() => opportunities.id, { onDelete: 'cascade' }),
  
  // 3 варианта писем (каждый с subject, body, mailto_link)
  generated_pitches: jsonb("generated_pitches").notNull(),
  /**
   * Structure:
   * [
   *   {
   *     variant_name: "Дерзкий",
   *     subject: "Raw subject",
   *     body: "Raw body",
   *     mailto_link: "mailto:...?subject=encoded&body=encoded"
   *   },
   *   { variant_name: "Консервативный", ... },
   *   { variant_name: "Технический", ... }
   * ]
   */
  
  // Какой вариант выбрал пользователь
  user_chosen_variant: integer("user_chosen_variant"), // 0, 1, or 2
  user_chosen_pitch: text("user_chosen_pitch"), // Финальный текст после редактирования
  
  // Отправка
  is_sent: boolean("is_sent").default(false).notNull(),
  sent_at: timestamp("sent_at"),
  
  // Метаданные генерации
  speaker_profile: text("speaker_profile").notNull(), // corporate или crypto
  generation_model: text("generation_model").default("deepseek-r1").notNull(),
  
  // Временные метки
  created_at: timestamp("created_at").defaultNow().notNull(),
  updated_at: timestamp("updated_at").defaultNow().notNull(),
}, (table) => ({
  opportunityIdx: index("idx_attacks_opportunity_id").on(table.opportunity_id),
  isSentIdx: index("idx_is_sent").on(table.is_sent),
}));

export const insertAttackSchema = createInsertSchema(attacks);
export const selectAttackSchema = createSelectSchema(attacks);

// ============================================================================
// ТИПЫ TypeScript
// ============================================================================
export type IntelAsset = typeof intel_assets.$inferSelect;
export type InsertIntelAsset = typeof intel_assets.$inferInsert;

export type Opportunity = typeof opportunities.$inferSelect;
export type InsertOpportunity = typeof opportunities.$inferInsert;

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = typeof contacts.$inferInsert;

export type Attack = typeof attacks.$inferSelect;
export type InsertAttack = typeof attacks.$inferInsert;

// ============================================================================
// ZOD СХЕМЫ ДЛЯ ВАЛИДАЦИИ API REQUESTS
// ============================================================================

export const searchRequestSchema = z.object({
  query: z.string().min(1),
  location: z.enum(['МОСКВА', 'СПб', 'Онлайн', 'Международное', 'Все']).default('Все'),
  dateFrom: z.string().optional(),
  dateTo: z.string().optional(),
});

export const deepAnalyzeRequestSchema = z.object({
  opportunityId: z.string().uuid(),
});

export const generatePitchesRequestSchema = z.object({
  opportunityId: z.string().uuid(),
  speakerProfile: z.enum(['corporate', 'crypto']),
});

export const updateAttackStatusSchema = z.object({
  attackId: z.string().uuid(),
  userChosenVariant: z.number().int().min(0).max(2),
  userChosenPitch: z.string().optional(),
  isSent: z.boolean(),
});

export type SearchRequest = z.infer<typeof searchRequestSchema>;
export type DeepAnalyzeRequest = z.infer<typeof deepAnalyzeRequestSchema>;
export type GeneratePitchesRequest = z.infer<typeof generatePitchesRequestSchema>;
export type UpdateAttackStatus = z.infer<typeof updateAttackStatusSchema>;
