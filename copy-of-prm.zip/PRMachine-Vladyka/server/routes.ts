import type { Express } from "express";
import { db } from "./lib/db";
import { opportunities, contacts, attacks } from "@shared/schema-vladyka";
import { 
  searchRequestSchema,
  deepAnalyzeRequestSchema,
  generatePitchesRequestSchema,
  updateAttackStatusSchema,
} from "@shared/schema-vladyka";
import {
  executeReconnaissance,
  executeVerification,
  executeDeepAnalysis,
  executeStrikeSynthesis,
  getOpportunitiesByStatus,
  getAttackByOpportunityId,
  markAttackAsSent,
  getProtocolMetrics,
} from "./lib/vladykaProtocol";
import { eq, desc, and, or } from "drizzle-orm";

export function registerRoutes(app: Express) {
  
  // ============================================================================
  // ФАЗА 1: РАЗВЕДКА (Alpha) - Поиск и первичный скоринг
  // ============================================================================
  
  /**
   * POST /api/vladyka/reconnaissance
   * Выполняет разведку через Brave Search, создает opportunities со статусом 'scouted'
   */
  app.post("/api/vladyka/reconnaissance", async (req, res) => {
    try {
      const parsed = searchRequestSchema.parse(req.body);
      const result = await executeReconnaissance(parsed);
      res.json(result);
    } catch (error: any) {
      console.error('Reconnaissance error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================================================
  // ФАЗА 2: ВЕРИФИКАЦИЯ (Bravo) - Проверка релевантности и контактов
  // ============================================================================
  
  /**
   * POST /api/vladyka/verification
   * Верифицирует opportunities через AI анализ, извлекает контакты
   */
  app.post("/api/vladyka/verification", async (req, res) => {
    try {
      const { opportunityIds } = req.body;
      
      if (!Array.isArray(opportunityIds) || opportunityIds.length === 0) {
        return res.status(400).json({ error: "opportunityIds array is required" });
      }
      
      const result = await executeVerification({ opportunityIds });
      res.json(result);
    } catch (error: any) {
      console.error('Verification error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================================================
  // ФАЗА 3: ГЛУБОКИЙ АНАЛИЗ (Charlie) - AI-driven детальный разбор
  // ============================================================================
  
  /**
   * POST /api/vladyka/deep-analysis
   * Выполняет глубокий AI анализ opportunity
   */
  app.post("/api/vladyka/deep-analysis", async (req, res) => {
    try {
      const parsed = deepAnalyzeRequestSchema.parse(req.body);
      const result = await executeDeepAnalysis(parsed);
      res.json(result);
    } catch (error: any) {
      console.error('Deep analysis error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================================================
  // ФАЗА 4: СИНТЕЗ АТАКИ (Delta) - Генерация писем и mailto-ссылок
  // ============================================================================
  
  /**
   * POST /api/vladyka/strike-synthesis
   * Генерирует 3 варианта писем с mailto-ссылками
   */
  app.post("/api/vladyka/strike-synthesis", async (req, res) => {
    try {
      const parsed = generatePitchesRequestSchema.parse(req.body);
      const result = await executeStrikeSynthesis(parsed);
      res.json(result);
    } catch (error: any) {
      console.error('Strike synthesis error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /api/vladyka/mark-sent
   * Отмечает attack как отправленный
   */
  app.post("/api/vladyka/mark-sent", async (req, res) => {
    try {
      const parsed = updateAttackStatusSchema.parse(req.body);
      
      await markAttackAsSent(
        parsed.attackId,
        parsed.userChosenVariant,
        parsed.userChosenPitch
      );
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Mark sent error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================================================
  // DATA ACCESS ENDPOINTS - Получение данных
  // ============================================================================
  
  /**
   * GET /api/opportunities
   * Получить все opportunities с фильтрацией по статусу
   */
  app.get("/api/opportunities", async (req, res) => {
    try {
      const { status } = req.query;
      
      let results;
      if (status && typeof status === 'string') {
        results = await getOpportunitiesByStatus(status);
      } else {
        results = await db.select().from(opportunities).orderBy(desc(opportunities.alpha_score));
      }
      
      res.json(results);
    } catch (error: any) {
      console.error('Get opportunities error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /api/opportunities/:id
   * Получить конкретный opportunity с контактами
   */
  app.get("/api/opportunities/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      const [opportunity] = await db.select().from(opportunities).where(eq(opportunities.id, id));
      
      if (!opportunity) {
        return res.status(404).json({ error: "Opportunity not found" });
      }
      
      const opportunityContacts = await db.select().from(contacts).where(eq(contacts.opportunity_id, id));
      
      res.json({
        ...opportunity,
        contacts: opportunityContacts,
      });
    } catch (error: any) {
      console.error('Get opportunity error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /api/attacks/:opportunityId
   * Получить attack по opportunity ID
   */
  app.get("/api/attacks/:opportunityId", async (req, res) => {
    try {
      const { opportunityId } = req.params;
      const attack = await getAttackByOpportunityId(opportunityId);
      
      if (!attack) {
        return res.status(404).json({ error: "Attack not found" });
      }
      
      res.json(attack);
    } catch (error: any) {
      console.error('Get attack error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /api/metrics
   * Получить метрики протокола Владыка
   */
  app.get("/api/metrics", async (req, res) => {
    try {
      const metrics = await getProtocolMetrics();
      res.json(metrics);
    } catch (error: any) {
      console.error('Get metrics error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // ============================================================================
  // LEGACY COMPATIBILITY (для обратной совместимости)
  // ============================================================================
  
  /**
   * POST /api/search-events (DEPRECATED - use /api/vladyka/reconnaissance)
   */
  app.post("/api/search-events", async (req, res) => {
    try {
      const { query, location, dateFrom, dateTo } = req.body;
      const result = await executeReconnaissance({ query, location: location || 'Все', dateFrom, dateTo });
      
      res.json({
        success: result.success,
        eventsFound: result.opportunitiesFound,
        events: result.opportunities,
      });
    } catch (error: any) {
      console.error('Search events error:', error);
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /api/events (DEPRECATED - use /api/opportunities)
   */
  app.get("/api/events", async (_req, res) => {
    try {
      const results = await db.select().from(opportunities).orderBy(desc(opportunities.alpha_score));
      res.json(results);
    } catch (error: any) {
      console.error('Get events error:', error);
      res.status(500).json({ error: error.message });
    }
  });
}
