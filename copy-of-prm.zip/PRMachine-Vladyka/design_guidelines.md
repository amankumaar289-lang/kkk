# Design Guidelines: Автоматизированная PR-машина

## Design Approach: Utility-Focused Command Center
**Selected System**: Custom tactical dashboard inspired by Material Design Dark with military-command aesthetics
**Rationale**: This is a productivity tool requiring rapid data processing, clear prioritization, and real-time feedback. The "operational headquarters" theme aligns with the mission-critical nature of speaker prospecting.

## Core Design Principles
1. **Information Density with Clarity** - Maximum data visibility without overwhelming
2. **Priority-Driven Visual Hierarchy** - Moscow events visually dominate
3. **Real-time Feedback** - Every action provides immediate visual response
4. **Tactical Efficiency** - Minimize clicks, maximize output

## Color Palette

### Dark Mode (Primary)
- **Background Main**: 13 10% 12% (deep command center blue-black)
- **Background Cards**: 210 30% 18% (elevated surface)
- **Background Elevated**: 210 25% 22% (modal/overlay)

### Accent Colors
- **Primary Action**: 195 100% 50% (bright cyan - echoes Brave/AI tech)
- **Priority High (Moscow)**: 142 76% 36% (vibrant green - GO signal)
- **Priority Medium**: 48 89% 50% (amber warning)
- **Priority Low**: 210 15% 45% (muted blue-gray)
- **Danger/Reject**: 0 84% 60% (red alert)

### Text Colors
- **Primary Text**: 210 40% 98% (bright white-blue)
- **Secondary Text**: 210 20% 70% (muted info)
- **Disabled**: 210 10% 45% (de-emphasized)

## Typography
- **Font Family**: 'Manrope' (primary), system-ui (fallback)
- **Hierarchy**:
  - H1 (Dashboard Title): 2rem, 800 weight, tracking-tight
  - H2 (Section Headers): 1.5rem, 700 weight
  - H3 (Card Titles): 1.25rem, 600 weight
  - Body: 0.95rem, 400 weight, leading-relaxed
  - Small (Meta): 0.85rem, 500 weight
  - Mono (Stats/IDs): 'JetBrains Mono', monospace

## Layout System
**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20
- Container: max-w-7xl, px-4 md:px-8
- Card Padding: p-4 md:p-6
- Section Gaps: gap-6 md:gap-8
- Grid Gaps: gap-4

**Grid Structure**:
- Dashboard: 3-column (Sidebar 280px | Main flex-1 | Metrics 320px)
- Event Cards: Grid 1-2-3 columns (mobile-tablet-desktop)
- Filters: Horizontal flex wrap with gap-3

## Component Library

### Navigation/Header
- Fixed top bar, h-16, backdrop-blur-lg bg-opacity-90
- Left: Logo + "PR Command Center" title
- Right: Stats counter (events found, success rate) + settings icon
- Bottom border: 1px cyan glow effect

### Event Cards (Primary Component)
**Structure**:
- Border-left 4px indicating priority (green/amber/gray)
- Header: Event name (bold) + Location badge (МОСКВА in bright green capsule)
- Subheader: Date + Audience size + Category tags
- Body: AI-generated pitch preview (2 lines, expandable)
- Footer: Contact chips (email/telegram icons) + Relevance score (0-100)
- Actions: "Подходит" (green) / "Не подходит" (red outline) / "Подробнее" (ghost)

**States**:
- Default: subtle shadow, border-left glow
- Hover: translateY(-2px), stronger shadow, scale-101
- Processing: Pulsing border animation
- Accepted: Green check overlay, fade to 50% opacity
- Rejected: Red X overlay, slide-out animation

### Control Panel (Sidebar)
- Search input with real-time filter
- Priority filters: Checkbox group with count badges
- Location toggles: Москва (always on) / СПб / Онлайн / International
- Date range picker (calendar dropdown)
- "Запустить поиск" big button (full-width, gradient cyan-to-blue, glow effect)

### Metrics Dashboard (Right Panel)
**Cards Layout**:
1. Today's Progress: Circular progress (found/processed)
2. Success Rate: Large percentage + sparkline chart
3. Top Categories: Horizontal bar chart (top 5)
4. Quick Stats: Grid of icon+number pairs

**Design**: Glass-morphism cards (backdrop-blur, border-cyan, subtle gradient)

### Generated Letter Modal
- Full-screen overlay (bg-black/80 backdrop-blur)
- Letter preview: White paper effect (shadow-2xl) with pre-formatted text
- Header: Event name + selected speaker profile toggle
- Footer: Copy to clipboard (with success animation) + Direct send (future)

### Status/Loading States
- Initial load: Skeleton cards (shimmer animation)
- Searching: Radar sweep animation in top-right corner
- Processing: Per-card spinner on event name
- Error: Toast notification (top-right, auto-dismiss)

## Interactions & Animations
**Micro-interactions**:
- Button clicks: Scale-95 + ripple effect
- Card selection: Border grows from left, color pulse
- Score update: Number counter animation (odometer effect)
- New card arrival: Slide-in from right + subtle bounce

**Transitions**: Use ease-in-out, 200-300ms duration (never exceed 400ms)

## Accessibility
- Dark mode optimized: WCAG AAA contrast ratios (text 18:1 minimum)
- Focus states: 2px cyan outline with 4px offset
- Keyboard nav: Tab order follows visual hierarchy, Escape closes modals
- Screen reader: Aria-labels on all interactive elements, live regions for updates

## Images
**Not applicable** - This is a data-dense dashboard without hero imagery. Focus on iconography (Heroicons) for status indicators, categories, and actions.

## Key Visual Differentiators
1. **Priority Borders**: Thick left-border color-coding (Moscow = green dominance)
2. **Real-time Pulse**: Subtle glow animations on active processes
3. **Military Precision**: Monospace for data, sharp corners (radius-lg max)
4. **Command Center Glow**: Cyan accent used sparingly for critical CTAs and active states
5. **Data Density**: Compact but readable - every pixel serves intelligence gathering