# PR Command Center

## Обзор проекта

Автоматизированная система поиска и подачи заявок на выступления на конференциях и мероприятиях. Система использует Brave Search API для поиска событий, анализирует их релевантность с помощью DeepSeek R1 AI, извлекает контакты организаторов и генерирует персонализированные сопроводительные письма.

## Текущее состояние

**Статус:** ✅ СИСТЕМА ПОЛНОСТЬЮ РАБОТАЕТ - Все компоненты протестированы и функционируют

**Последние изменения (14 октября 2025):**
- ✅ Реализована полная схема данных (Event, GeneratedLetter, EventFeedback, Metrics)
- ✅ Настроены API клиенты (Brave Search с ротацией 4 ключей, OpenRouter DeepSeek R1)
- ✅ Создана система приоритизации (Москва офлайн = высший приоритет)
- ✅ Реализована генерация сопроводительных писем на основе TDR-протокола
- ✅ Настроен военно-тактический дизайн интерфейса (темная тема, cyan акценты)
- ✅ Интегрированы все компоненты frontend и backend
- ✅ **E2E тесты пройдены:** поиск → анализ → генерация писем → feedback
- ✅ **Исправлен критический баг:** валидация схемы для генерации писем

**Результаты E2E тестирования:**
- Поиск "конференция бизнес" нашел 20 событий
- Анализ релевантности работает (score 0-100)
- Генерация писем для обоих профилей (Corporate/Crypto) функционирует
- Feedback loop обновляет статусы и метрики
- Метрики: найдено 20, обработано 20, одобрено 1, success rate 5%

## Архитектура системы

### Frontend (React + TypeScript + Tailwind)
- **Header:** Метрики в реальном времени (найдено событий, успешность)
- **ControlPanel:** Фильтры по локации, дате, категориям; запуск поиска
- **EventCard:** Карточки мероприятий с приоритетами, контактами, AI-анализом
- **LetterPreviewModal:** Генерация и просмотр сопроводительных писем
- **MetricsDashboard:** Статистика и аналитика (топ категории, прогресс)

### Backend (Express + TypeScript)
- **Brave Search API:** 4 API ключа с ротацией, rate limiting 1 req/sec
- **OpenRouter API:** DeepSeek R1 для анализа релевантности и генерации писем
- **TDR Protocol:** Генерация поисковых запросов, извлечение контактов
- **In-Memory Storage:** Event[], GeneratedLetter[], EventFeedback[]

### API Endpoints
- `POST /api/search-events` - Поиск и анализ мероприятий
- `POST /api/generate-letter` - Генерация сопроводительного письма
- `POST /api/feedback` - Обратная связь (подходит/не подходит)
- `GET /api/events` - Получить все события
- `GET /api/metrics` - Получить метрики

## Критерии приоритизации

### Локация (приоритет)
1. **МОСКВА офлайн** (высший) - личные знакомства, нетворкинг
2. **СПб с оплатой проезда** (средний)
3. **Международные английские** (средний)
4. **Онлайн** (низкий)

### Тематика (70% вес для non-AI конференций)
- Приоритет: продажи, маркетинг, бизнес-конференции
- Избегать: pure AI conferences (конкуренты вместо клиентов)

### Аудитория
- Целевая: CEO, Head of Sales, HR Directors
- Компании: 3-5 млн руб/год выручка, 5+ менеджеров

## Спикерские профили

### Корпоративный профиль
- URL: https://speaker-zakhar-kondratev.replit.app/
- Темы: AI для бизнеса, автоматизация продаж, практическое применение AI
- Аудитория: Бизнес-конференции, корпоративные мероприятия

### Крипто/продакшн профиль  
- URL: http://the-trends-zakhar-kondratev.replit.app/
- Темы: AI в Web3, крипто-технологии, децентрализованные системы
- Аудитория: Tech-конференции, крипто-события

## Технический стек

### Frontend
- React 18 + TypeScript
- Tailwind CSS (военно-тактический дизайн)
- TanStack Query v5 (data fetching)
- Wouter (routing)
- Shadcn/ui (компоненты)
- Framer Motion (анимации)

### Backend
- Express.js + TypeScript
- Brave Search API (4 ключа, ротация)
- OpenRouter API (DeepSeek R1)
- In-memory storage (MemStorage)

### Важные файлы
- `shared/schema.ts` - Схемы данных TypeScript/Zod
- `server/lib/braveClient.ts` - Клиент Brave Search API
- `server/lib/openrouterClient.ts` - Клиент OpenRouter/DeepSeek
- `server/lib/tdrProtocol.ts` - TDR протокол генерации запросов
- `server/routes.ts` - API endpoints
- `server/storage.ts` - In-memory хранилище
- `client/src/pages/Home.tsx` - Главная страница

## Дизайн система

### Цветовая палитра (Military Command Center)
- **Background:** Темно-серые оттенки (#0a0e1a)
- **Primary:** Cyan (#00d9ff) - критические действия
- **Accent:** Голубые градиенты - важные элементы
- **Success/Danger:** Зеленый/Красный для статусов

### Визуальные эффекты
- Glass-morphism для панелей
- Radar sweep анимация при поиске
- Glow effects на активных элементах
- Sharp corners (max border-radius: 0.5rem)
- Monospace шрифт для данных (JetBrains Mono)

## Переменные окружения

```env
# Brave Search API (4 ключа для ротации)
BRAVE_API_KEY_1=BSAiH1vhLfsKM_unpLEPqIulBOwnDgt
BRAVE_API_KEY_2=BSA-qCbl-osY1wjC2lW4PsIjx0Qt1IN
BRAVE_API_KEY_3=BSArBFB2NMjeC8WUZ_Mlif9CwSyjw_2
BRAVE_API_KEY_4=(резервный)

# OpenRouter API
OPENROUTER_API_KEY=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

# Session
SESSION_SECRET=(auto-generated)
```

## Workflow

### Процесс работы
1. Пользователь настраивает фильтры (локация, даты, категории)
2. Нажимает "Запустить поиск"
3. Система генерирует поисковые запросы по TDR-протоколу
4. Brave Search API ищет мероприятия (параллельно, 4 ключа)
5. DeepSeek R1 анализирует релевантность (scoring 0-100)
6. Система извлекает контакты организаторов (email, telegram, phone)
7. Карточки добавляются в интерфейс с приоритизацией
8. Пользователь отмечает "Подходит"/"Не подходит" (обучение ML)
9. Генерируется персонализированное сопроводительное письмо
10. Copy to clipboard и отправка организаторам

### Автоматизация
- Параллельный поиск через 4 Brave API ключа
- Автоматический retry при ошибках (exponential backoff)
- Rate limiting 1 req/sec на ключ
- Continuous learning из feedback

## Планы развития

### Фаза 1 (Текущая) ✅
- Базовый поиск и анализ мероприятий
- Генерация сопроводительных писем
- Feedback loop для обучения

### Фаза 2 (Следующая)
- Pre-event research (LinkedIn участников)
- Post-event follow-up (автоматические письма через 24ч)
- Integration с email providers (автоотправка)
- Advanced ML для улучшения приоритизации

### Фаза 3
- Telegram bot для уведомлений
- Calendar integration
- CRM интеграция
- Analytics dashboard
