/**
 * ПРОТОКОЛ "ВЛАДЫКА" (VLADYKA PROTOCOL)
 * 
 * Четырехфазная система автоматизированного сбора, анализа и контакта с организаторами мероприятий
 * 
 * ФАЗА 1: РАЗВЕДКА (Alpha) - Поиск и первичный скоринг
 * ФАЗА 2: ВЕРИФИКАЦИЯ (Bravo) - Проверка релевантности и контактов
 * ФАЗА 3: ГЛУБОКИЙ АНАЛИЗ (Charlie) - AI-driven детальный анализ
 * ФАЗА 4: СИНТЕЗ АТАКИ (Delta) - Генерация персонализированных писем и mailto-ссылок
 */

import { db } from './db';
import { intel_assets, opportunities, contacts, attacks } from '@shared/schema-vladyka';
import { searchMultipleQueries } from './braveClient';
import { analyzeEventRelevance, generateCoverLetter, extractContacts } from './openrouterClient';
import { eq, desc, and, or, inArray } from 'drizzle-orm';

// ============================================================================
// УТИЛИТЫ ДЛЯ ПРОТОКОЛА
// ============================================================================

/**
 * Генерация поисковых запросов для Brave Search
 */
function generateSearchQueries(query: string, location: string): string[] {
  const baseQueries = [
    `${query} ${location} выступление спикер`,
    `${query} ${location} конференция 2025`,
    `${query} ${location} митап выступить`,
    `${query} ${location} call for speakers`,
  ];

  if (location === 'Все') {
    return [
      ...baseQueries.map(q => q.replace('Все', 'Москва')),
      ...baseQueries.map(q => q.replace('Все', 'СПб')),
      ...baseQueries.map(q => q.replace('Все', 'Онлайн')),
    ];
  }

  return baseQueries;
}

/**
 * Определение локации из текста
 */
function determineLocation(text: string): string {
  const lowerText = text.toLowerCase();
  if (lowerText.includes('москва') || lowerText.includes('moscow')) return 'МОСКВА';
  if (lowerText.includes('санкт-петербург') || lowerText.includes('питер') || lowerText.includes('спб')) return 'СПб';
  if (lowerText.includes('онлайн') || lowerText.includes('online') || lowerText.includes('remote')) return 'Онлайн';
  if (lowerText.includes('международ') || lowerText.includes('international')) return 'Международное';
  return 'Онлайн';
}

/**
 * Определение приоритета на основе локации и скора
 */
function determinePriority(location: string, score: number): 'high' | 'medium' | 'low' {
  if (location === 'МОСКВА' && score >= 70) return 'high';
  if (location === 'СПб' && score >= 65) return 'high';
  if (score >= 80) return 'high';
  if (score >= 50) return 'medium';
  return 'low';
}

/**
 * Извлечение даты события из описания
 */
function extractEventDate(description: string): string | null {
  const datePatterns = [
    /(\d{1,2})\s+(января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\s+(\d{4})/i,
    /(\d{1,2})\.(\d{1,2})\.(\d{4})/,
    /(\d{4})-(\d{2})-(\d{2})/,
  ];

  for (const pattern of datePatterns) {
    const match = description.match(pattern);
    if (match) return match[0];
  }

  return null;
}

/**
 * Категоризация события
 */
function categorizeEvent(title: string, description: string): string {
  const text = (title + ' ' + description).toLowerCase();
  
  if (text.includes('blockchain') || text.includes('crypto') || text.includes('web3')) return 'Blockchain & Crypto';
  if (text.includes('ai') || text.includes('machine learning') || text.includes('нейросет')) return 'AI & ML';
  if (text.includes('devops') || text.includes('kubernetes') || text.includes('docker')) return 'DevOps & Infrastructure';
  if (text.includes('frontend') || text.includes('react') || text.includes('vue')) return 'Frontend Development';
  if (text.includes('backend') || text.includes('api') || text.includes('microservice')) return 'Backend Development';
  if (text.includes('data') || text.includes('analytics') || text.includes('big data')) return 'Data Science & Analytics';
  if (text.includes('security') || text.includes('безопасность')) return 'Security';
  if (text.includes('управление') || text.includes('product') || text.includes('management')) return 'Product & Management';
  
  return 'Технологии';
}

/**
 * Вычисление Alpha Score (Разведка)
 */
function calculateAlphaScore(result: any, location: string, category: string): number {
  let score = 50; // базовый скор
  
  // Локация
  if (location === 'МОСКВА') score += 15;
  if (location === 'СПб') score += 10;
  if (location === 'Онлайн') score += 5;
  
  // Категория
  if (category.includes('Blockchain') || category.includes('AI')) score += 10;
  
  // Качество описания
  if (result.description && result.description.length > 200) score += 5;
  
  // Наличие ключевых слов
  const text = (result.title + ' ' + result.description).toLowerCase();
  if (text.includes('speaker') || text.includes('спикер')) score += 10;
  if (text.includes('call for') || text.includes('заявки')) score += 10;
  
  return Math.min(100, Math.max(0, score));
}

// ============================================================================
// ФАЗА 1: РАЗВЕДКА (Alpha) - Поиск и первичный скоринг
// ============================================================================

export interface ReconnaissanceRequest {
  query: string;
  location: string;
  dateFrom?: string;
  dateTo?: string;
}

export interface ReconnaissanceResult {
  success: boolean;
  opportunitiesFound: number;
  opportunities: any[];
}

/**
 * ФАЗА 1: Выполняет разведку через Brave Search, создает opportunities со статусом 'scouted'
 */
export async function executeReconnaissance(request: ReconnaissanceRequest): Promise<ReconnaissanceResult> {
  console.log(`🔍 [ALPHA] Starting reconnaissance for: "${request.query}" in ${request.location}`);
  
  // Генерируем поисковые запросы
  const searchQueries = generateSearchQueries(request.query, request.location);
  console.log(`📡 [ALPHA] Generated ${searchQueries.length} search queries`);
  
  // Выполняем поиск через Brave API
  const searchResults = await searchMultipleQueries(searchQueries);
  console.log(`📊 [ALPHA] Found ${searchResults.length} raw results`);
  
  const createdOpportunities = [];
  
  // Обрабатываем результаты
  for (const result of searchResults.slice(0, 20)) {
    try {
      const detectedLocation = determineLocation(result.title + ' ' + result.description);
      
      // Фильтр по локации
      if (request.location !== 'Все' && detectedLocation !== request.location) {
        continue;
      }
      
      const category = categorizeEvent(result.title, result.description);
      const alphaScore = calculateAlphaScore(result, detectedLocation, category);
      const eventDate = extractEventDate(result.description);
      const priority = determinePriority(detectedLocation, alphaScore);
      
      // Создаем opportunity со статусом 'scouted'
      const [opportunity] = await db.insert(opportunities).values({
        title: result.title,
        description: result.description || '',
        event_url: result.url,
        event_date: eventDate,
        location: detectedLocation,
        category,
        status: 'scouted',
        alpha_score: alphaScore,
        priority,
        raw_search_data: result,
      }).returning();
      
      createdOpportunities.push(opportunity);
      console.log(`✅ [ALPHA] Created opportunity: ${opportunity.title} (score: ${alphaScore})`);
      
    } catch (error) {
      console.error('❌ [ALPHA] Error processing result:', error);
    }
  }
  
  console.log(`🎯 [ALPHA] Reconnaissance complete: ${createdOpportunities.length} opportunities created`);
  
  return {
    success: true,
    opportunitiesFound: createdOpportunities.length,
    opportunities: createdOpportunities,
  };
}

// ============================================================================
// ФАЗА 2: ВЕРИФИКАЦИЯ (Bravo) - Проверка релевантности и извлечение контактов
// ============================================================================

export interface VerificationRequest {
  opportunityIds: string[];
}

export interface VerificationResult {
  success: boolean;
  verified: number;
  rejected: number;
  results: any[];
}

/**
 * ФАЗА 2: Верифицирует opportunities через AI анализ, извлекает контакты, обновляет статус
 */
export async function executeVerification(request: VerificationRequest): Promise<VerificationResult> {
  console.log(`🔬 [BRAVO] Starting verification for ${request.opportunityIds.length} opportunities`);
  
  const results = [];
  let verifiedCount = 0;
  let rejectedCount = 0;
  
  for (const opportunityId of request.opportunityIds) {
    try {
      // Загружаем opportunity
      const [opportunity] = await db.select().from(opportunities).where(eq(opportunities.id, opportunityId));
      
      if (!opportunity) {
        console.warn(`⚠️  [BRAVO] Opportunity ${opportunityId} not found`);
        continue;
      }
      
      // AI анализ релевантности
      const analysis = await analyzeEventRelevance(
        opportunity.title,
        opportunity.description,
        opportunity.location
      );
      
      const bravoScore = analysis.score;
      
      // Если скор слишком низкий - отклоняем
      if (bravoScore < 40) {
        await db.update(opportunities)
          .set({ 
            status: 'rejected',
            bravo_score: bravoScore,
            verified_at: new Date(),
          })
          .where(eq(opportunities.id, opportunityId));
        
        rejectedCount++;
        console.log(`❌ [BRAVO] Rejected: ${opportunity.title} (score: ${bravoScore})`);
        continue;
      }
      
      // Извлекаем контакты со страницы
      let extractedContacts: any = null;
      try {
        const pageResponse = await fetch(opportunity.event_url);
        const htmlContent = await pageResponse.text();
        extractedContacts = await extractContacts(htmlContent);
        
        // Сохраняем контакты в базу
        if (extractedContacts.emails.length > 0 || extractedContacts.telegram.length > 0) {
          for (const email of extractedContacts.emails.slice(0, 3)) {
            await db.insert(contacts).values({
              opportunity_id: opportunityId,
              email,
              extraction_source: opportunity.event_url,
            });
          }
          
          for (const telegram of extractedContacts.telegram.slice(0, 2)) {
            await db.insert(contacts).values({
              opportunity_id: opportunityId,
              telegram,
              extraction_source: opportunity.event_url,
            });
          }
        }
      } catch (error) {
        console.log(`⚠️  [BRAVO] Could not extract contacts from: ${opportunity.event_url}`);
      }
      
      // Обновляем opportunity - переводим в статус 'verified'
      await db.update(opportunities)
        .set({
          status: 'verified',
          bravo_score: bravoScore,
          verified_at: new Date(),
        })
        .where(eq(opportunities.id, opportunityId));
      
      verifiedCount++;
      console.log(`✅ [BRAVO] Verified: ${opportunity.title} (score: ${bravoScore})`);
      
      results.push({
        opportunityId,
        status: 'verified',
        bravoScore,
        contactsFound: extractedContacts ? (extractedContacts.emails.length + extractedContacts.telegram.length) : 0,
      });
      
    } catch (error) {
      console.error(`❌ [BRAVO] Error verifying opportunity ${opportunityId}:`, error);
    }
  }
  
  console.log(`🎯 [BRAVO] Verification complete: ${verifiedCount} verified, ${rejectedCount} rejected`);
  
  return {
    success: true,
    verified: verifiedCount,
    rejected: rejectedCount,
    results,
  };
}

// ============================================================================
// ФАЗА 3: ГЛУБОКИЙ АНАЛИЗ (Charlie) - AI-driven детальный разбор
// ============================================================================

export interface DeepAnalysisRequest {
  opportunityId: string;
}

export interface DeepAnalysisResult {
  success: boolean;
  opportunityId: string;
  analysis: string;
  keyInsights: string[];
}

/**
 * ФАЗА 3: Выполняет глубокий AI анализ, извлекает ключевые инсайты
 */
export async function executeDeepAnalysis(request: DeepAnalysisRequest): Promise<DeepAnalysisResult> {
  console.log(`🧠 [CHARLIE] Starting deep analysis for opportunity: ${request.opportunityId}`);
  
  // Загружаем opportunity
  const [opportunity] = await db.select().from(opportunities).where(eq(opportunities.id, request.opportunityId));
  
  if (!opportunity) {
    throw new Error(`Opportunity ${request.opportunityId} not found`);
  }
  
  // AI анализ с более детальным промптом
  const deepAnalysisPrompt = `
Проанализируй это мероприятие максимально детально:

Название: ${opportunity.title}
Описание: ${opportunity.description}
Локация: ${opportunity.location}
Категория: ${opportunity.category}

Предоставь:
1. Ключевую аудиторию и её интересы
2. Идеальные темы для выступления
3. Тон и стиль коммуникации организаторов
4. Уникальные особенности мероприятия
5. Recommended hook для первого контакта

Формат ответа: JSON с полями analysis (детальный текст) и insights (массив из 3-5 коротких инсайтов)
`;
  
  // Используем OpenRouter для глубокого анализа
  const analysis = await analyzeEventRelevance(
    opportunity.title,
    opportunity.description,
    opportunity.location
  );
  
  // Генерируем ключевые инсайты (упрощенная версия, можно расширить)
  const keyInsights = [
    `Локация: ${opportunity.location} - ${opportunity.priority} приоритет`,
    `Категория: ${opportunity.category}`,
    `Релевантность: ${opportunity.bravo_score || opportunity.alpha_score}/100`,
    analysis.pitch || 'AI-generated pitch available',
  ];
  
  // Обновляем opportunity
  await db.update(opportunities)
    .set({
      status: 'analyzing',
      ai_analysis: analysis.pitch || 'Deep analysis completed',
      key_insights: keyInsights,
      analyzed_at: new Date(),
    })
    .where(eq(opportunities.id, request.opportunityId));
  
  console.log(`✅ [CHARLIE] Deep analysis complete for: ${opportunity.title}`);
  
  return {
    success: true,
    opportunityId: request.opportunityId,
    analysis: analysis.pitch || 'Analysis completed',
    keyInsights,
  };
}

// ============================================================================
// ФАЗА 4: СИНТЕЗ АТАКИ (Delta) - Генерация писем и mailto-ссылок
// ============================================================================

export interface StrikeSynthesisRequest {
  opportunityId: string;
  speakerProfile: 'corporate' | 'crypto';
}

export interface StrikeSynthesisResult {
  success: boolean;
  attackId: string;
  pitches: Array<{
    variant_name: string;
    subject: string;
    body: string;
    mailto_link: string;
  }>;
}

/**
 * Генерирует mailto ссылку
 */
function generateMailtoLink(email: string, subject: string, body: string): string {
  const encodedSubject = encodeURIComponent(subject);
  const encodedBody = encodeURIComponent(body);
  return `mailto:${email}?subject=${encodedSubject}&body=${encodedBody}`;
}

/**
 * ФАЗА 4: Генерирует 3 варианта писем с mailto-ссылками
 */
export async function executeStrikeSynthesis(request: StrikeSynthesisRequest): Promise<StrikeSynthesisResult> {
  console.log(`🎯 [DELTA] Starting strike synthesis for opportunity: ${request.opportunityId}`);
  
  // Загружаем opportunity и контакты
  const [opportunity] = await db.select().from(opportunities).where(eq(opportunities.id, request.opportunityId));
  
  if (!opportunity) {
    throw new Error(`Opportunity ${request.opportunityId} not found`);
  }
  
  // Загружаем контакты
  const opportunityContacts = await db.select().from(contacts).where(eq(contacts.opportunity_id, request.opportunityId));
  
  const recipientEmail = opportunityContacts.find(c => c.email)?.email || 'info@example.com';
  
  // Генерируем 3 варианта писем
  const variants = [
    { name: 'Дерзкий', tone: 'bold and confident' },
    { name: 'Консервативный', tone: 'professional and formal' },
    { name: 'Технический', tone: 'technical and detailed' },
  ];
  
  const pitches = [];
  
  for (const variant of variants) {
    // Генерируем письмо через AI
    const letterContent = await generateCoverLetter(
      opportunity.title,
      opportunity.description,
      request.speakerProfile,
      { emails: [recipientEmail] }
    );
    
    // Извлекаем subject и body (если AI вернул структурированный ответ)
    const subject = `Предложение выступления: ${opportunity.title}`;
    const body = letterContent;
    
    // Генерируем mailto-ссылку
    const mailtoLink = generateMailtoLink(recipientEmail, subject, body);
    
    pitches.push({
      variant_name: variant.name,
      subject,
      body,
      mailto_link: mailtoLink,
    });
  }
  
  // Сохраняем атаку в базу
  const [attack] = await db.insert(attacks).values({
    opportunity_id: request.opportunityId,
    generated_pitches: pitches,
    speaker_profile: request.speakerProfile,
    generation_model: 'deepseek-r1',
  }).returning();
  
  // Обновляем opportunity на статус 'attack_ready'
  await db.update(opportunities)
    .set({
      status: 'attack_ready',
      attack_ready_at: new Date(),
    })
    .where(eq(opportunities.id, request.opportunityId));
  
  console.log(`✅ [DELTA] Strike synthesis complete: ${pitches.length} pitches generated`);
  
  return {
    success: true,
    attackId: attack.id,
    pitches,
  };
}

// ============================================================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ДЛЯ УПРАВЛЕНИЯ ПРОТОКОЛОМ
// ============================================================================

/**
 * Получить все opportunities по статусу
 */
export async function getOpportunitiesByStatus(status: string) {
  return await db.select().from(opportunities).where(eq(opportunities.status, status)).orderBy(desc(opportunities.alpha_score));
}

/**
 * Получить attack по opportunity_id
 */
export async function getAttackByOpportunityId(opportunityId: string) {
  const [attack] = await db.select().from(attacks).where(eq(attacks.opportunity_id, opportunityId));
  return attack;
}

/**
 * Обновить статус отправки атаки
 */
export async function markAttackAsSent(attackId: string, variantIndex: number, finalPitch?: string) {
  await db.update(attacks)
    .set({
      is_sent: true,
      sent_at: new Date(),
      user_chosen_variant: variantIndex,
      user_chosen_pitch: finalPitch,
    })
    .where(eq(attacks.id, attackId));
  
  // Обновляем opportunity на статус 'sent'
  const [attack] = await db.select().from(attacks).where(eq(attacks.id, attackId));
  if (attack) {
    await db.update(opportunities)
      .set({ status: 'sent' })
      .where(eq(opportunities.id, attack.opportunity_id));
  }
}

/**
 * Получить метрики протокола
 */
export async function getProtocolMetrics() {
  const allOpportunities = await db.select().from(opportunities);
  
  const totalScouted = allOpportunities.filter(o => o.status === 'scouted').length;
  const totalVerified = allOpportunities.filter(o => o.status === 'verified').length;
  const totalAnalyzing = allOpportunities.filter(o => o.status === 'analyzing').length;
  const totalAttackReady = allOpportunities.filter(o => o.status === 'attack_ready').length;
  const totalSent = allOpportunities.filter(o => o.status === 'sent').length;
  const totalRejected = allOpportunities.filter(o => o.status === 'rejected').length;
  
  const avgAlphaScore = allOpportunities.reduce((sum, o) => sum + (o.alpha_score || 0), 0) / allOpportunities.length || 0;
  const avgBravoScore = allOpportunities.filter(o => o.bravo_score).reduce((sum, o) => sum + (o.bravo_score || 0), 0) / allOpportunities.filter(o => o.bravo_score).length || 0;
  
  return {
    totalOpportunities: allOpportunities.length,
    byStatus: {
      scouted: totalScouted,
      verified: totalVerified,
      analyzing: totalAnalyzing,
      attack_ready: totalAttackReady,
      sent: totalSent,
      rejected: totalRejected,
    },
    avgScores: {
      alpha: Math.round(avgAlphaScore),
      bravo: Math.round(avgBravoScore),
    },
  };
}
