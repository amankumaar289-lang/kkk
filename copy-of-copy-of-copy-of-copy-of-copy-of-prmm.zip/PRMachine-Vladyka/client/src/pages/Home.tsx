import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Opportunity, Attack } from "@shared/schema-vladyka";
import { Header } from "@/components/Header";
import { ControlPanel } from "@/components/ControlPanel";
import { EventCard } from "@/components/EventCard";
import { LetterPreviewModal } from "@/components/LetterPreviewModal";
import { MetricsDashboard } from "@/components/MetricsDashboard";
import { EmptyState, RadarSearching } from "@/components/LoadingState";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface VladykaMetrics {
  totalOpportunities: number;
  byStatus: {
    scouted: number;
    verified: number;
    analyzing: number;
    attack_ready: number;
    sent: number;
    rejected: number;
  };
  avgScores: {
    alpha: number;
    bravo: number;
  };
}

export default function Home() {
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);
  const [selectedLetter, setSelectedLetter] = useState<GeneratedLetter | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();

  const { data: events = [] } = useQuery<Event[]>({
    queryKey: ['/api/events'],
  });

  const { data: metrics } = useQuery<Metrics>({
    queryKey: ['/api/metrics'],
  });

  const searchMutation = useMutation({
    mutationFn: async (criteria: any) => {
      setIsSearching(true);
      const response = await apiRequest('POST', '/api/search-events', criteria);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      setIsSearching(false);
      toast({
        title: "Поиск завершен",
        description: "События успешно найдены и проанализированы",
      });
    },
    onError: () => {
      setIsSearching(false);
      toast({
        title: "Ошибка поиска",
        description: "Не удалось выполнить поиск событий",
        variant: "destructive",
      });
    },
  });

  const feedbackMutation = useMutation({
    mutationFn: async ({ eventId, isGoodFit }: { eventId: string; isGoodFit: boolean }) => {
      return await apiRequest('POST', '/api/feedback', { eventId, isGoodFit });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
    },
  });

  const letterMutation = useMutation({
    mutationFn: async ({ eventId, profile }: { eventId: string; profile: 'corporate' | 'crypto' }) => {
      return await apiRequest('POST', '/api/generate-letter', { eventId, speakerProfile: profile });
    },
    onSuccess: (data: GeneratedLetter) => {
      setSelectedLetter(data);
      toast({
        title: "Письмо сгенерировано",
        description: "Сопроводительное письмо готово к отправке",
      });
    },
  });

  const handleSearch = (criteria: any) => {
    searchMutation.mutate(criteria);
  };

  const handleVerify = (opportunityId: string) => {
    verificationMutation.mutate([opportunityId]);
  };

  const handleViewDetails = async (opportunity: Opportunity) => {
    setSelectedOpportunity(opportunity);
    setIsModalOpen(true);
    
    // Генерируем атаку
    attackMutation.mutate({ 
      opportunityId: opportunity.id, 
      profile: 'corporate' 
    });
  };

  const handleProfileChange = (profile: 'corporate' | 'crypto') => {
    if (selectedOpportunity) {
      attackMutation.mutate({ 
        opportunityId: selectedOpportunity.id, 
        profile 
      });
    }
  };

  const defaultMetrics: VladykaMetrics = metrics || {
    totalOpportunities: 0,
    byStatus: {
      scouted: 0,
      verified: 0,
      analyzing: 0,
      attack_ready: 0,
      sent: 0,
      rejected: 0,
    },
    avgScores: {
      alpha: 0,
      bravo: 0,
    },
  };

  return (
    <div className="min-h-screen bg-background">
      <Header 
        totalEvents={events.length} 
        successRate={defaultMetrics.successRate} 
      />
      
      <div className="flex h-[calc(100vh-80px)]">
        <aside className="w-80 flex-shrink-0">
          <ControlPanel 
            onSearch={handleSearch} 
            isSearching={isSearching} 
          />
        </aside>

        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-5xl mx-auto space-y-4">
            {isSearching && <RadarSearching />}
            
            {!isSearching && events.length === 0 && <EmptyState />}
            
            {!isSearching && events.length > 0 && events.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                onAccept={handleAccept}
                onReject={handleReject}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        </main>

        <aside className="w-80 flex-shrink-0">
          <MetricsDashboard metrics={defaultMetrics} />
        </aside>
      </div>

      <LetterPreviewModal
        event={selectedEvent}
        letter={selectedLetter}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedEvent(null);
          setSelectedLetter(null);
        }}
        onProfileChange={handleProfileChange}
      />
    </div>
  );
}
