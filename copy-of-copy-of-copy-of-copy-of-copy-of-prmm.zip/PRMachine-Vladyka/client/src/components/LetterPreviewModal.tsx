import { useState } from "react";
import { Event, GeneratedLetter } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, CheckCircle2, Building2, Coins } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LetterPreviewModalProps {
  event: Event | null;
  letter: GeneratedLetter | null;
  isOpen: boolean;
  onClose: () => void;
  onProfileChange: (profile: 'corporate' | 'crypto') => void;
}

export function LetterPreviewModal({
  event,
  attack,
  isOpen,
  onClose,
  onProfileChange,
}: LetterPreviewModalProps) {
  const [copied, setCopied] = useState(false);
  const [activeVariant, setActiveVariant] = useState(0);
  const { toast } = useToast();

  const handleCopy = async (text: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    toast({
      title: "Скопировано!",
      description: "Письмо скопировано в буфер обмена",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  if (!event || !attack) return null;

  const pitches = attack.generated_pitches as any[];
  
  if (!pitches || pitches.length === 0) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Генерация писем...</DialogTitle>
            <DialogDescription>Пожалуйста, подождите</DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col" data-testid="modal-letter-preview">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-3" data-testid="text-modal-title">
            <span>{event.title}</span>
            <Badge variant="outline" data-testid="badge-event-location">
              {event.location}
            </Badge>
          </DialogTitle>
          <DialogDescription data-testid="text-modal-description">
            Персонализированное сопроводительное письмо
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2 py-3 border-y border-border">
          <span className="text-sm text-muted-foreground">Спикерское досье:</span>
          <Button
            variant={letter.speakerProfile === 'corporate' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onProfileChange('corporate')}
            className="gap-1.5"
            data-testid="button-profile-corporate"
          >
            <Building2 className="w-4 h-4" />
            Корпоративное
          </Button>
          <Button
            variant={letter.speakerProfile === 'crypto' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onProfileChange('crypto')}
            className="gap-1.5"
            data-testid="button-profile-crypto"
          >
            <Coins className="w-4 h-4" />
            Крипто/Web3
          </Button>
        </div>

        <div className="flex-1 overflow-auto">
          <div className="bg-white text-black p-8 rounded-lg shadow-xl min-h-[400px]">
            <div className="prose prose-sm max-w-none">
              <div
                className="whitespace-pre-wrap font-serif leading-relaxed"
                data-testid="text-letter-content"
              >
                {letter.letterContent}
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            onClick={handleCopy}
            variant="default"
            className="gap-2"
            data-testid="button-copy-letter"
          >
            {copied ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                Скопировано!
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                Копировать
              </>
            )}
          </Button>
          <Button
            onClick={onClose}
            variant="outline"
            data-testid="button-close-modal"
          >
            Закрыть
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
