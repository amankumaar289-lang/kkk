import { defineConfig } from "drizzle-kit";

// Supabase connection string
const connectionString = process.env.SUPABASE_DB_CONNECTION_STRING || process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error("SUPABASE_DB_CONNECTION_STRING or DATABASE_URL is required");
}

export default defineConfig({
  out: "./migrations",
  schema: "./shared/schema-vladyka.ts",
  dialect: "postgresql",
  dbCredentials: {
    url: connectionString,
  },
});