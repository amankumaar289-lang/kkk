import type { Express } from "express";
import { db } from "./lib/db";
import { opportunities, contacts, attacks } from "@shared/schema-vladyka";
import { 
  searchRequestSchema,
  generatePitchesRequestSchema,
} from "@shared/schema-vladyka";
import {
  executeReconnaissance,
  executeVerification,
  executeDeepAnalysis,
  executeStrikeSynthesis,
  handleFeedback,
  getProtocolMetrics,
} from "./lib/vladykaProtocol";
import { eq, desc, and } from "drizzle-orm";

export function registerRoutes(app: Express) {
  
  // PHASE 1: RECONNAISSANCE (+ background PHASE 2)
  app.post("/api/search-events", async (req, res, next) => {
    try {
      const parsed = searchRequestSchema.parse(req.body);
      const result = await executeReconnaissance(parsed);
      
      // Trigger verification for new opportunities in the background
      const newOpportunities = await db.query.opportunities.findMany({ where: eq(opportunities.status, 'scouted') });
      for (const opp of newOpportunities) {
        executeVerification(opp.id).catch(e => console.error(`Background verification failed for ${opp.id}:`, e));
      }

      res.json(result);
    } catch (error) { next(error); }
  });

  // GET ALL OPPORTUNITIES
  app.get("/api/events", async (_req, res, next) => {
    try {
      const results = await db.query.opportunities.findMany({
        with: { contacts: true },
        orderBy: [desc(opportunities.priority), desc(opportunities.scouted_at)],
      });
      res.json(results);
    } catch (error) { next(error); }
  });

  // PHASE 3: DEEP ANALYSIS (Triggered manually)
  app.post("/api/deep-analyze", async (req, res, next) => {
    try {
        const { opportunityId } = req.body;
        if (!opportunityId) return res.status(400).json({ error: "opportunityId is required" });
        await executeDeepAnalysis(opportunityId);
        res.json({ success: true, message: 'Deep analysis started.' });
    } catch (error) {
        next(error);
    }
  });


  // PHASE 4: STRIKE SYNTHESIS
  app.post("/api/generate-letter", async (req, res, next) => {
    try {
      const parsed = generatePitchesRequestSchema.parse(req.body);

      // Check for existing attack
      let attack = await db.query.attacks.findFirst({
        where: and(
            eq(attacks.opportunity_id, parsed.opportunityId),
            eq(attacks.speaker_profile, parsed.speakerProfile)
        )
      });
      
      if (!attack) {
          // Trigger deep analysis if not done yet
          const opp = await db.query.opportunities.findFirst({ where: eq(opportunities.id, parsed.opportunityId) });
          if(opp && opp.status === 'verified') {
              await executeDeepAnalysis(parsed.opportunityId);
          }
          attack = await executeStrikeSynthesis(parsed);
      }

      res.json(attack);
    } catch (error) { next(error); }
  });

  // HANDLE FEEDBACK (SENT/REJECTED)
  app.post("/api/feedback", async (req, res, next) => {
    try {
      const { opportunityId, isGoodFit, finalPitch } = req.body;
      if (!opportunityId) return res.status(400).json({ error: "opportunityId is required" });
      const result = await handleFeedback(opportunityId, isGoodFit, finalPitch);
      res.json(result);
    } catch (error) { next(error); }
  });

  // GET METRICS
  app.get("/api/metrics", async (_req, res, next) => {
    try {
      const metrics = await getProtocolMetrics();
      res.json(metrics);
    } catch (error) { next(error); }
  });
}