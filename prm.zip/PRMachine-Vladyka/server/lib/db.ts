/**
 * DATABASE CLIENT - Supabase + Drizzle ORM
 * 
 * Инициализация клиента для работы с Supabase PostgreSQL через Drizzle ORM.
 * Это единственный источник правды для всех операций с базой данных.
 */

import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from '@shared/schema-vladyka';

// Получаем connection string из переменных окружения
const connectionString = process.env.SUPABASE_DB_CONNECTION_STRING || process.env.DATABASE_URL;

if (!connectionString) {
  throw new Error('SUPABASE_DB_CONNECTION_STRING or DATABASE_URL is required');
}

// Создаем Postgres клиент с настройками для serverless окружения
const queryClient = postgres(connectionString, {
  max: 1, // Рекомендуется для serverless функций
  idle_timeout: 20,
  connect_timeout: 10,
});

// Инициализируем Drizzle ORM
export const db = drizzle(queryClient, { schema });

// Экспортируем схемы для использования в других модулях
export { schema };

// Экспортируем типы для удобства
export type {
  IntelAsset,
  InsertIntelAsset,
  Opportunity,
  InsertOpportunity,
  Contact,
  InsertContact,
  Attack,
  InsertAttack,
} from '@shared/schema-vladyka';
