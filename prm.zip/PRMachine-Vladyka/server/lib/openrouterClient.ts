const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;

if (!OPENROUTER_API_KEY) {
  throw new Error("OPENROUTER_API_KEY is not configured in environment variables.");
}

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface ChatCompletionResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export async function chatCompletion(messages: ChatMessage[]): Promise<string> {
  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
      'HTTP-Referer': 'https://pr-command-center.replit.app',
      'X-Title': 'PR Command Center',
    },
    body: JSON.stringify({
      model: 'deepseek/deepseek-r1-0528-qwen3-8b',
      messages,
    }),
  });

  if (!response.ok) {
    throw new Error(`OpenRouter API error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json() as ChatCompletionResponse;
  return data.choices[0]?.message?.content || '';
}

export async function analyzeEventRelevance(
  eventTitle: string,
  eventDescription: string,
  location: string
): Promise<{ score: number; pitch: string; category: string }> {
  const prompt = `Проанализируй мероприятие и оцени его релевантность для спикера-эксперта по AI.

МЕРОПРИЯТИЕ:
Название: ${eventTitle}
Описание: ${eventDescription}
Локация: ${location}

КРИТЕРИИ ОЦЕНКИ:
1. Локация (40 баллов):
   - МОСКВА офлайн: 40 баллов (абсолютный приоритет!)
   - СПб с оплатой проезда: 25 баллов
   - Онлайн: 15 баллов
   - Международное английское: 30 баллов
   
2. Тематика (30 баллов):
   - НЕ AI конференции (продажи, маркетинг, бизнес): 30 баллов
   - AI конференции: 10 баллов
   
3. Аудитория (20 баллов):
   - Бизнес, CEO, отделы продаж: 20 баллов
   - IT-специалисты, разработчики: 10 баллов
   
4. Формат (10 баллов):
   - Бизнес-конференция: 10 баллов
   - Узкоспециализированная: 5 баллов

ВЕРНИ JSON:
{
  "score": число от 0 до 100,
  "pitch": "Краткое предложение ценности для организаторов (1-2 предложения)",
  "category": "Категория мероприятия"
}`;

  const response = await chatCompletion([
    { role: 'user', content: prompt }
  ]);

  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return {
        score: Math.min(100, Math.max(0, parsed.score || 0)),
        pitch: parsed.pitch || '',
        category: parsed.category || 'Другое'
      };
    }
  } catch (e) {
    console.error('Failed to parse AI response:', e);
  }

  return { score: 50, pitch: '', category: 'Другое' };
}

export async function generateCoverLetter(
  eventTitle: string,
  eventDescription: string,
  speakerProfile: 'corporate' | 'crypto',
  organizerInfo: any
): Promise<string> {
  const profileData = speakerProfile === 'corporate' 
    ? {
        name: 'Захар Кондратьев',
        expertise: 'AI для бизнеса и автоматизации продаж',
        achievements: 'Внедрял AI в Росатом, Газпром. Эксперт по практическому применению AI в продажах и маркетинге.',
        topics: 'Как AI увеличивает продажи на 30%, Автоматизация отдела продаж с AI, AI для бизнеса: от хайпа к реальной выгоде',
        link: 'https://speaker-zakhar-kondratev.replit.app/'
      }
    : {
        name: 'Захар Кондратьев',
        expertise: 'AI в Web3 и продакшн-технологиях',
        achievements: 'Эксперт по AI и крипто-технологиям. Практическое применение AI в децентрализованных системах.',
        topics: 'AI в Web3, Автоматизация через AI, Практическое применение AI в криптоиндустрии',
        link: 'http://the-trends-zakhar-kondratev.replit.app/'
      };

  const prompt = `Создай персонализированное сопроводительное письмо для заявки спикера на мероприятие.

МЕРОПРИЯТИЕ:
${eventTitle}
${eventDescription}

СПИКЕР:
${profileData.name}
Экспертиза: ${profileData.expertise}
Достижения: ${profileData.achievements}
Темы выступлений: ${profileData.topics}
Портфолио: ${profileData.link}

СТРУКТУРА ПИСЬМА:
1. Приветствие и краткое представление
2. Почему это мероприятие важно для спикера (адаптируй под описание события)
3. Какую ценность принесет выступление участникам (боли аудитории, практическая польза)
4. Предлагаемые темы выступлений (адаптируй под мероприятие)
5. Призыв к действию

ВАЖНО:
- Письмо должно быть персонализированным под конкретное мероприятие
- Упомяни боли целевой аудитории
- Покажи конкретную ценность для участников
- Максимум 250-300 слов
- Профессиональный, но дружелюбный тон

Напиши письмо на русском языке:`;

  const response = await chatCompletion([
    { role: 'user', content: prompt }
  ]);

  return response.trim();
}

export async function extractContacts(htmlContent: string): Promise<{
  emails: string[];
  telegram: string[];
  phones: string[];
}> {
  const emailRegex = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g;
  const telegramRegex = /@[A-Za-z0-9_]{5,}/g;
  const phoneRegex = /\+?[0-9]{1,4}?[-.\s]?\(?[0-9]{1,3}?\)?[-.\s]?[0-9]{1,4}[-.\s]?[0-9]{1,4}[-.\s]?[0-9]{1,9}/g;

  const emails = Array.from(new Set(htmlContent.match(emailRegex) || []));
  const telegram = Array.from(new Set(htmlContent.match(telegramRegex) || []));
  const phones = Array.from(new Set(htmlContent.match(phoneRegex) || []));

  return { emails, telegram, phones };
}
