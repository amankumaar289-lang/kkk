const BRAVE_API_KEYS = [
  process.env.BRAVE_API_KEY_1,
  process.env.BRAVE_API_KEY_2,
  process.env.BRAVE_API_KEY_3,
  process.env.BRAVE_API_KEY_4,
].filter(Boolean) as string[];

if (BRAVE_API_KEYS.length === 0) {
  throw new Error("Brave API keys are not configured in environment variables (BRAVE_API_KEY_1, etc).");
}


let currentKeyIndex = 0;
let lastRequestTime = 0;

function getNextApiKey(): string {
  const key = BRAVE_API_KEYS[currentKeyIndex];
  currentKeyIndex = (currentKeyIndex + 1) % BRAVE_API_KEYS.length;
  return key;
}

async function rateLimitedRequest<T>(fn: () => Promise<T>): Promise<T> {
  const now = Date.now();
  const timeSinceLastRequest = now - lastRequestTime;
  
  if (timeSinceLastRequest < 1000) {
    await new Promise(resolve => setTimeout(resolve, 1000 - timeSinceLastRequest));
  }
  
  lastRequestTime = Date.now();
  return fn();
}

export interface BraveSearchResult {
  title: string;
  url: string;
  description: string;
  extra_snippets?: string[];
}

export interface BraveSearchResponse {
  web?: {
    results: BraveSearchResult[];
  };
}

export async function searchEvents(query: string, retries = 3): Promise<BraveSearchResult[]> {
  const apiKey = getNextApiKey();
  
  const searchQuery = encodeURIComponent(query);
  const url = `https://api.search.brave.com/res/v1/web/search?q=${searchQuery}&count=20&text_decorations=false&extra_snippets=true`;
  
  try {
    const response = await rateLimitedRequest(async () => {
      const res = await fetch(url, {
        headers: {
          'Accept': 'application/json',
          'X-Subscription-Token': apiKey,
        },
      });
      
      if (!res.ok) {
        throw new Error(`Brave API error: ${res.status} ${res.statusText}`);
      }
      
      return res.json();
    });
    
    const data = response as BraveSearchResponse;
    return data.web?.results || [];
  } catch (error) {
    if (retries > 0) {
      console.log(`Brave API error, retrying... (${retries} attempts left)`);
      await new Promise(resolve => setTimeout(resolve, 2000));
      return searchEvents(query, retries - 1);
    }
    throw error;
  }
}

export async function searchMultipleQueries(queries: string[]): Promise<BraveSearchResult[]> {
  const allResults: BraveSearchResult[] = [];
  const seenUrls = new Set<string>();
  
  for (const query of queries) {
    const results = await searchEvents(query);
    
    for (const result of results) {
      if (!seenUrls.has(result.url)) {
        seenUrls.add(result.url);
        allResults.push(result);
      }
    }
  }
  
  return allResults;
}
