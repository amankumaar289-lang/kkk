/**
 * ПРОТОКОЛ "ВЛАДЫКА" (VLADYKA PROTOCOL)
 * 
 * Четырехфазная система автоматизированного сбора, анализа и контакта с организаторами мероприятий
 * 
 * ФАЗА 1: РАЗВЕДКА (Alpha) - Поиск и первичный скоринг
 * ФАЗА 2: ВЕРИФИКАЦИЯ (Bravo) - Проверка релевантности и контактов
 * ФАЗА 3: ГЛУБОКИЙ АНАЛИЗ (Charlie) - AI-driven детальный анализ
 * ФАЗА 4: СИНТЕЗ АТАКИ (Delta) - Генерация персонализированных писем и mailto-ссылок
 */
import { db } from './db';
import { opportunities, contacts, attacks, intel_assets } from '@shared/schema-vladyka';
import { searchMultipleQueries } from './braveClient';
import { analyzeEventRelevance, generateCoverLetter, extractContacts, chatCompletion } from './openrouterClient';
import { eq, desc, and, or, inArray, isNull, sql } from 'drizzle-orm';

// ============================================================================
// УТИЛИТЫ ДЛЯ ПРОТОКОЛА
// ============================================================================

function generateSearchQueries(query: string, location: string): string[] {
    const baseQueries = [
      `"${query}" ${location} "call for speakers" 2025 OR 2026`,
      `конференция ${query} ${location} 2025 OR 2026`,
      `форум ${query} ${location} спикеры`,
      `митап ${query} ${location} программа`,
    ];
    return baseQueries;
}

function determineLocation(text: string): string {
    const lowerText = text.toLowerCase();
    if (lowerText.includes('москва') || lowerText.includes('moscow')) return 'МОСКВА';
    if (lowerText.includes('санкт-петербург') || lowerText.includes('питер') || lowerText.includes('спб')) return 'СПб';
    if (lowerText.includes('онлайн') || lowerText.includes('online')) return 'Онлайн';
    return 'Международное';
}

function determinePriority(location: string, score: number): 'high' | 'medium' | 'low' {
    if (location === 'МОСКВА') return 'high';
    if (location === 'СПб' && score > 60) return 'medium';
    if (score > 75) return 'medium';
    return 'low';
}

function extractEventDate(text: string): string | null {
  const match = text.match(/(\d{1,2}[./-]\d{1,2}[./-]\d{2,4})|(\d{1,2}\s+(?:января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\s+\d{4})/i);
  return match ? match[0] : null;
}

function categorizeEvent(title: string, description: string): string {
  const text = `${title} ${description}`.toLowerCase();
  const categories: Record<string, string[]> = {
    'AI/Технологии': ['ai', 'ии', 'нейросети', 'ml', 'deep learning'],
    'Продажи/Маркетинг': ['продажи', 'маркетинг', 'sales', 'marketing', 'cmo'],
    'Бизнес/Финансы': ['бизнес', 'business', 'инвестиции', 'финансы', 'ceo'],
    'Крипто/Web3': ['crypto', 'blockchain', 'web3', 'defai', 'криптовалюты'],
  };
  for (const [cat, keywords] of Object.entries(categories)) {
    if (keywords.some(kw => text.includes(kw))) return cat;
  }
  return 'Другое';
}

function calculateAlphaScore(result: any, location: string): number {
  let score = 50;
  if (location === 'МОСКВА') score += 20;
  if (result.description.length > 150) score += 10;
  if (result.title.toLowerCase().includes('конференция') || result.title.toLowerCase().includes('форум')) score += 10;
  return Math.min(100, score);
}

function generateMailtoLink(email: string, subject: string, body: string): string {
    return `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

// ============================================================================
// ФАЗА 1: РАЗВЕДКА (Alpha)
// ============================================================================
export async function executeReconnaissance(request: { query: string; location: string }) {
    console.log(`[ALPHA] Starting reconnaissance: "${request.query}" in ${request.location}`);
    const searchQueries = generateSearchQueries(request.query, request.location);
    const searchResults = await searchMultipleQueries(searchQueries);

    const createdOpportunities = [];
    for (const result of searchResults) {
        try {
            const existing = await db.query.opportunities.findFirst({ where: eq(opportunities.event_url, result.url) });
            if (existing) continue;

            const location = determineLocation(result.title + ' ' + result.description);
            const alpha_score = calculateAlphaScore(result, location);
            const priority = determinePriority(location, alpha_score);

            const [opportunity] = await db.insert(opportunities).values({
                title: result.title,
                description: result.description,
                event_url: result.url,
                location,
                priority,
                alpha_score,
                status: 'scouted',
                event_date: extractEventDate(result.description),
                category: categorizeEvent(result.title, result.description),
                raw_search_data: result,
            }).returning();
            createdOpportunities.push(opportunity);
        } catch (error) { console.error(`[ALPHA] Error processing result ${result.url}:`, error); }
    }
    console.log(`[ALPHA] Reconnaissance complete: ${createdOpportunities.length} new opportunities created.`);
    return { success: true, opportunitiesFound: createdOpportunities.length };
}


// ============================================================================
// ФАЗА 2: ВЕРИФИКАЦИЯ (Bravo)
// ============================================================================
export async function executeVerification(opportunityId: string) {
    console.log(`[BRAVO] Verifying opportunity ID: ${opportunityId}`);
    const [opp] = await db.select().from(opportunities).where(eq(opportunities.id, opportunityId));
    if (!opp) throw new Error("Opportunity not found");

    const analysis = await analyzeEventRelevance(opp.title, opp.description, opp.location);
    
    if (analysis.score < 40) {
        await db.update(opportunities).set({ status: 'rejected', bravo_score: analysis.score }).where(eq(opportunities.id, opportunityId));
        console.log(`[BRAVO] Rejected: ${opp.title} (Score: ${analysis.score})`);
        return;
    }

    try {
        const pageRes = await fetch(opp.event_url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
        if (pageRes.ok) {
            const html = await pageRes.text();
            const contactInfo = await extractContacts(html);
            for (const email of [...new Set(contactInfo.emails)].slice(0, 2)) {
                await db.insert(contacts).values({ opportunity_id: opportunityId, email }).onConflictDoNothing();
            }
        }
    } catch (e) { console.error(`[BRAVO] Failed to fetch or extract contacts from ${opp.event_url}`); }
    
    await db.update(opportunities).set({ status: 'verified', bravo_score: analysis.score, ai_analysis: analysis.pitch }).where(eq(opportunities.id, opportunityId));
    console.log(`[BRAVO] Verified: ${opp.title} (Score: ${analysis.score})`);
}

// ============================================================================
// ФАЗА 3: ГЛУБОКИЙ АНАЛИЗ (Charlie)
// ============================================================================
export async function executeDeepAnalysis(opportunityId: string) {
    console.log(`[CHARLIE] Deep analysis for: ${opportunityId}`);
    await db.update(opportunities).set({ status: 'analyzing' }).where(eq(opportunities.id, opportunityId));
    
    const [opp] = await db.select().from(opportunities).where(eq(opportunities.id, opportunityId));
    if (!opp) throw new Error("Opportunity not found");
    
    const analysisPrompt = `Проведи глубокий анализ мероприятия "${opp.title}" (${opp.event_url}). Изучи программу, спикеров, темы, аудиторию. Сделай 5-7 дополнительных запросов в Brave Search для сбора контекста. Суммаризируй всю информацию в "ключевые инсайты" (массив строк).`;
    const summary = await chatCompletion([{ role: 'user', content: analysisPrompt }]);
    
    await db.update(opportunities).set({ status: 'attack_ready', key_insights: summary.split('\n'), analyzed_at: new Date() }).where(eq(opportunities.id, opportunityId));
    console.log(`[CHARLIE] Deep analysis complete for: ${opp.title}`);
}


// ============================================================================
// ФАЗА 4: СИНТЕЗ АТАКИ (Delta)
// ============================================================================
export async function executeStrikeSynthesis(request: { opportunityId: string, speakerProfile: 'corporate' | 'crypto' }) {
    console.log(`[DELTA] Strike synthesis for: ${request.opportunityId}`);
    const [opp] = await db.select().from(opportunities).where(eq(opportunities.id, request.opportunityId));
    if (!opp) throw new Error("Opportunity not found");

    const oppContacts = await db.select().from(contacts).where(eq(contacts.opportunity_id, request.opportunityId));
    const recipientEmails = oppContacts.map(c => c.email).filter(Boolean).join(',');

    const assets = await db.query.intel_assets.findMany({
      where: or(
        inArray(intel_assets.asset_type, ['topic', 'case_study', 'accolade']),
        eq(intel_assets.name, `link_speaker_${request.speakerProfile}`)
      )
    });
    const assetsString = assets.map(a => `- ${a.name}: ${a.content}`).join('\n');

    const synthesisPrompt = `Ты - AI-продюсер Захар Кондратьев. Сгенерируй 3 РАЗНЫХ, коротких, бьющих в цель письма для мероприятия.

**Мероприятие:**
- Название: ${opp.title}
- Описание: ${opp.description}
- Ключевые инсайты: ${opp.key_insights?.join(', ')}

**Твои активы (Арсенал):**
${assetsString}

**Задача:**
Создай 3 варианта письма (Дерзкий, Экспертный, B2B-ценность). Для каждого варианта верни JSON объект: { "variant_name": "...", "subject": "...", "body": "..." }.
ВЕСЬ ОТВЕТ ДОЛЖЕН БЫТЬ МАССИВОМ ИЗ 3-Х JSON ОБЪЕКТОВ ВНУТРИ \`\`\`json [...] \`\`\` блока.`;
    
    const response = await chatCompletion([{ role: 'user', content: synthesisPrompt }]);
    const jsonMatch = response.match(/```json([\s\S]*?)```/);
    if (!jsonMatch) throw new Error("Failed to generate valid JSON for pitches.");
    
    const pitchesData: any[] = JSON.parse(jsonMatch[1]);
    const pitches = pitchesData.map(p => ({
        ...p,
        mailto_link: generateMailtoLink(recipientEmails, p.subject, p.body)
    }));

    const [attack] = await db.insert(attacks).values({
      opportunity_id: request.opportunityId,
      generated_pitches: pitches,
      speaker_profile: request.speakerProfile,
    }).returning();
    
    await db.update(opportunities).set({ status: 'attack_ready' }).where(eq(opportunities.id, request.opportunityId));
    return attack;
}

// ============================================================================
// УПРАВЛЕНИЕ И МЕТРИКИ
// ============================================================================

export async function handleFeedback(opportunityId: string, isGoodFit: boolean, finalPitch?: string) {
    const status = isGoodFit ? 'sent' : 'rejected';
    await db.update(opportunities).set({ status }).where(eq(opportunities.id, opportunityId));

    if (isGoodFit) {
        const [attack] = await db.select().from(attacks).where(eq(attacks.opportunity_id, opportunityId)).orderBy(desc(attacks.created_at));
        if (attack) {
            await db.update(attacks).set({ is_sent: true, sent_at: new Date(), user_chosen_pitch: finalPitch }).where(eq(attacks.id, attack.id));
        }
    }
    return { success: true };
}

export async function getProtocolMetrics() {
    const counts = await db.select({ status: opportunities.status, count: sql`count(*)` }).from(opportunities).groupBy(opportunities.status);
    const byStatus = counts.reduce((acc, row) => ({ ...acc, [row.status]: Number(row.count) }), {});
    
    const scores = await db.select({ alpha: sql`avg(alpha_score)`, bravo: sql`avg(bravo_score)` }).from(opportunities);

    return {
        totalOpportunities: await db.select({ count: sql`count(*)` }).from(opportunities).then(res => Number(res[0].count)),
        byStatus,
        avgScores: {
            alpha: Math.round(Number(scores[0].alpha) || 0),
            bravo: Math.round(Number(scores[0].bravo) || 0),
        },
    };
}