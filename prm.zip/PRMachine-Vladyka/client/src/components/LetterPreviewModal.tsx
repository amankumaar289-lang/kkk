import { useState, useEffect } from "react";
import { Opportunity, Attack, Contact } from "@shared/schema-vladyka";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Copy, CheckCircle2, Building2, Coins, Loader2, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LetterPreviewModalProps {
  opportunity: (Opportunity & { contacts?: Contact[] }) | null;
  attack: Attack | null;
  isLoading: boolean;
  isOpen: boolean;
  onClose: () => void;
  onProfileChange: (profile: 'corporate' | 'crypto') => void;
  onSent: (finalPitch: string) => void;
}

export function LetterPreviewModal({
  opportunity: event,
  attack,
  isLoading,
  isOpen,
  onClose,
  onProfileChange,
  onSent,
}: LetterPreviewModalProps) {
  const [activeVariantName, setActiveVariantName] = useState<string>("Дерзкий");
  const [editedPitches, setEditedPitches] = useState<Record<string, string>>({});
  const [mailtoClicked, setMailtoClicked] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (attack?.generated_pitches) {
      const initialEdits: Record<string, string> = {};
      (attack.generated_pitches as any[]).forEach(p => {
        initialEdits[p.variant_name] = p.body;
      });
      setEditedPitches(initialEdits);
      setActiveVariantName((attack.generated_pitches as any[])[0]?.variant_name || "Дерзкий");
    }
    if(isOpen) {
        setMailtoClicked(false);
    }
  }, [attack, isOpen]);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Скопировано!", description: "Текст письма скопирован." });
  };

  const handlePitchChange = (variant: string, newText: string) => {
    setEditedPitches(prev => ({ ...prev, [variant]: newText }));
  };
  
  const currentPitch = (attack?.generated_pitches as any[])?.find(p => p.variant_name === activeVariantName);
  const currentBody = editedPitches[activeVariantName] || currentPitch?.body || '';
  const recipientEmails = event?.contacts?.map(c => c.email).filter(Boolean).join(',') || '';
  const mailtoLink = currentPitch ? `mailto:${recipientEmails}?subject=${encodeURIComponent(currentPitch.subject)}&body=${encodeURIComponent(currentBody)}` : '#';

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-2xl">{event?.title}</DialogTitle>
          <DialogDescription>Синтез атаки: персонализированные сопроводительные письма</DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2 py-3 border-y border-border">
          <span className="text-sm text-muted-foreground">Профиль спикера:</span>
          <Button variant={attack?.speaker_profile === 'corporate' ? 'secondary' : 'outline'} size="sm" onClick={() => onProfileChange('corporate')}> <Building2 className="w-4 h-4 mr-2" />Корпоративный</Button>
          <Button variant={attack?.speaker_profile === 'crypto' ? 'secondary' : 'outline'} size="sm" onClick={() => onProfileChange('crypto')}> <Coins className="w-4 h-4 mr-2" />Крипто/Web3</Button>
        </div>

        {isLoading ? (
          <div className="flex-1 flex items-center justify-center min-h-[300px]"><Loader2 className="w-12 h-12 animate-spin text-primary" /></div>
        ) : (
          attack && currentPitch ? (
            <Tabs value={activeVariantName} onValueChange={setActiveVariantName} className="flex-1 overflow-hidden flex flex-col">
              <TabsList className="grid w-full grid-cols-3">
                {(attack.generated_pitches as any[]).map(p => (
                  <TabsTrigger key={p.variant_name} value={p.variant_name}>{p.variant_name}</TabsTrigger>
                ))}
              </TabsList>
              <div className="flex-1 overflow-auto p-1 mt-2">
                <div className="bg-muted/30 p-4 rounded-lg space-y-4">
                  <div className="font-mono text-sm">
                    <span className="text-muted-foreground">Тема: </span>
                    <span className="font-semibold">{currentPitch.subject}</span>
                  </div>
                  <Textarea 
                    value={currentBody}
                    onChange={(e) => handlePitchChange(activeVariantName, e.target.value)}
                    className="min-h-[250px] text-base"
                  />
                </div>
              </div>
            </Tabs>
          ) : <div className="flex-1 flex items-center justify-center min-h-[300px]"><p>Не удалось сгенерировать письма.</p></div>
        )}

        <DialogFooter className="gap-2 pt-4 border-t border-border sm:justify-between">
          <Button onClick={() => handleCopy(currentBody)} variant="outline" className="gap-2" disabled={isLoading || !currentPitch}><Copy className="w-4 h-4" />Копировать</Button>
          <div className="flex gap-2">
             <Button asChild variant="default" className="gap-2" disabled={isLoading || !currentPitch} onClick={() => setMailtoClicked(true)}>
              <a href={mailtoLink} target="_blank">
                <Mail className="w-4 h-4" />Открыть в почте
              </a>
            </Button>
            <Button onClick={() => onSent(currentBody)} variant="outline" className="bg-green-600/20 text-green-500 border-green-500 hover:bg-green-600/30" disabled={!mailtoClicked || isLoading}>
              <CheckCircle2 className="w-4 h-4 mr-1.5" />Я отправил
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}