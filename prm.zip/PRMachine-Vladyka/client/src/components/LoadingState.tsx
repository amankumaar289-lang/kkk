import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Loader2 } from "lucide-react";

export function EventCardSkeleton() {
  return (
    <Card className="border-l-4 border-l-muted animate-pulse">
      <CardHeader className="space-y-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 space-y-2">
            <Skeleton className="h-6 w-3/4" />
            <Skeleton className="h-4 w-full" />
          </div>
          <Skeleton className="h-6 w-16" />
        </div>
        <div className="flex items-center gap-2">
          <Skeleton className="h-6 w-24" />
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-6 w-28" />
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <Skeleton className="h-16 w-full" />
        <div className="flex items-center gap-2">
          <Skeleton className="h-8 w-24" />
          <Skeleton className="h-8 w-32" />
        </div>
      </CardContent>
    </Card>
  );
}

export function RadarSearching() {
  return (
    <div className="flex flex-col items-center justify-center py-16 space-y-6">
      <div className="relative w-32 h-32">
        <div className="absolute inset-0 border-4 border-primary/20 rounded-full"></div>
        <div className="absolute inset-0 border-4 border-transparent border-t-primary rounded-full animate-radar"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <Loader2 className="w-12 h-12 text-primary animate-spin" data-testid="icon-searching" />
        </div>
      </div>
      <div className="text-center space-y-2">
        <h3 className="text-lg font-bold text-foreground">
          Сканирование событий...
        </h3>
        <p className="text-sm text-muted-foreground font-mono">
          Tactical Deep Reconnaissance в процессе
        </p>
      </div>
    </div>
  );
}

export function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 space-y-4 text-center">
      <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center">
        <svg
          className="w-10 h-10 text-muted-foreground"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
          />
        </svg>
      </div>
      <div className="space-y-2">
        <h3 className="text-lg font-bold text-foreground" data-testid="text-empty-title">
          Нет событий
        </h3>
        <p className="text-sm text-muted-foreground max-w-md" data-testid="text-empty-description">
          Настройте параметры поиска и запустите сканирование для обнаружения релевантных событий
        </p>
      </div>
    </div>
  );
}

interface ShimmerCardProps {
  count?: number;
}

export function ShimmerCards({ count = 3 }: ShimmerCardProps) {
  return (
    <div className="space-y-4">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="h-48 rounded-lg bg-gradient-to-r from-muted via-muted/50 to-muted animate-shimmer bg-[length:200%_100%]"
          data-testid={`shimmer-card-${i}`}
        ></div>
      ))}
    </div>
  );
}
