import { useState } from "react";
import { Search, Play, MapPin, Calendar, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";

interface ControlPanelProps {
  onSearch: (criteria: SearchCriteria) => void;
  isSearching: boolean;
}

export interface SearchCriteria {
  query: string;
  location: string;
  dateFrom?: string;
  dateTo?: string;
}

export function ControlPanel({ onSearch, isSearching }: ControlPanelProps) {
  const [query, setQuery] = useState("");
  const [location, setLocation] = useState("Все");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  const handleSearch = () => {
    onSearch({
      query,
      location,
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
    });
  };

  return (
    <div className="h-full bg-card border-r border-border p-6 space-y-6">
      <div className="space-y-2">
        <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
          <Search className="w-5 h-5 text-primary" />
          Панель управления
        </h2>
        <p className="text-sm text-muted-foreground">
          Настройте параметры поиска
        </p>
      </div>

      <Card className="p-4 space-y-4 bg-card/50">
        <div className="space-y-2">
          <Label htmlFor="search-query" className="text-sm font-medium flex items-center gap-2">
            <Tag className="w-4 h-4" />
            Поисковый запрос
          </Label>
          <Input
            id="search-query"
            data-testid="input-search-query"
            placeholder="конференция блокчейн..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="font-mono text-sm"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="location" className="text-sm font-medium flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Локация
          </Label>
          <Select value={location} onValueChange={setLocation}>
            <SelectTrigger id="location" data-testid="select-location">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Все">Все локации</SelectItem>
              <SelectItem value="МОСКВА">
                <span className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-priority-high"></span>
                  МОСКВА (приоритет)
                </span>
              </SelectItem>
              <SelectItem value="СПб">СПб</SelectItem>
              <SelectItem value="Онлайн">Онлайн</SelectItem>
              <SelectItem value="Международное">Международное</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="date-from" className="text-sm font-medium flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              От
            </Label>
            <Input
              id="date-from"
              data-testid="input-date-from"
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              className="font-mono text-sm"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="date-to" className="text-sm font-medium">
              До
            </Label>
            <Input
              id="date-to"
              data-testid="input-date-to"
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              className="font-mono text-sm"
            />
          </div>
        </div>
      </Card>

      <Button
        onClick={handleSearch}
        disabled={!query || isSearching}
        data-testid="button-start-search"
        className="w-full bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground shadow-glow"
        size="lg"
      >
        {isSearching ? (
          <>
            <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2"></div>
            Поиск...
          </>
        ) : (
          <>
            <Play className="w-5 h-5 mr-2" />
            Запустить поиск
          </>
        )}
      </Button>

      <div className="pt-4 space-y-2 border-t border-border">
        <p className="text-xs text-muted-foreground uppercase tracking-wide font-bold">
          Система приоритетов
        </p>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-sm bg-priority-high"></div>
            <span className="text-muted-foreground">Высокий — Москва офлайн</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-sm bg-priority-medium"></div>
            <span className="text-muted-foreground">Средний — СПб, компенсация</span>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <div className="w-3 h-3 rounded-sm bg-priority-low"></div>
            <span className="text-muted-foreground">Низкий — международные</span>
          </div>
        </div>
      </div>
    </div>
  );
}