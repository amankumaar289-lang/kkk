import * as React from 'react';
import { Opportunity, Contact } from "@shared/schema-vladyka";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, Mail, Send, Eye, CheckCircle2, XCircle, Loader2, BrainCircuit, Target } from "lucide-react";
import { cn } from "@/lib/utils";

interface EventCardProps {
  opportunity: Opportunity & { contacts?: Contact[] };
  onReject: (opportunityId: string) => void;
  onViewDetails: (opportunity: Opportunity) => void;
}

const statusConfig: Record<string, { text: string; icon: React.ReactNode; color: string }> = {
    scouted: { text: 'Разведка', icon: <Loader2 className="w-3 h-3 animate-spin" />, color: 'text-gray-400' },
    verified: { text: 'Верификация', icon: <CheckCircle2 className="w-3 h-3" />, color: 'text-blue-400' },
    analyzing: { text: 'Глубинный анализ', icon: <Loader2 className="w-3 h-3 animate-spin" />, color: 'text-purple-400' },
    attack_ready: { text: 'Готов к атаке', icon: <Target className="w-3 h-3" />, color: 'text-priority-high' },
    sent: { text: 'Отправлено', icon: <Send className="w-3 h-3" />, color: 'text-green-500' },
    rejected: { text: 'Отклонено', icon: <XCircle className="w-3 h-3" />, color: 'text-destructive' },
};

export function EventCard({ opportunity: event, onReject, onViewDetails }: EventCardProps) {
  const isProcessed = event.status === 'sent' || event.status === 'rejected';
  const statusInfo = statusConfig[event.status] || statusConfig.scouted;

  const priorityBorderClass = {
    high: "border-l-[hsl(142_76%_36%)]",
    medium: "border-l-[hsl(48_89%_50%)]",
    low: "border-l-[hsl(210_15%_45%)]",
  }[event.priority as 'high' | 'medium' | 'low'] || 'border-l-border';

  const handleDetailsClick = () => {
    if (event.status === 'verified' || event.status === 'analyzing' || event.status === 'attack_ready') {
      onViewDetails(event);
    } else if (event.status === 'scouted') {
      onViewDetails(event);
    } else {
      onViewDetails(event);
    }
  };

  return (
    <Card
      className={cn(
        "border-l-4 hover-elevate transition-all duration-200 animate-slide-in",
        priorityBorderClass,
        isProcessed && "opacity-60 bg-card/50"
      )}
    >
      <CardHeader className="space-y-3 pb-4">
        <div className="flex items-start justify-between gap-3">
            <CardTitle className="text-lg font-bold text-foreground line-clamp-2">
              <a href={event.event_url} target="_blank" rel="noopener noreferrer" className="hover:underline">{event.title}</a>
            </CardTitle>
            <div className="flex items-center gap-3 flex-shrink-0">
                <Badge variant="outline" className={cn("gap-1.5 font-mono text-xs", statusInfo.color)}>
                    {statusInfo.icon}
                    {statusInfo.text}
                </Badge>
                <div className="flex items-center gap-2 font-mono text-xs text-muted-foreground">
                  <span>A: <span className="font-bold text-blue-400">{event.alpha_score ?? '??'}%</span></span>
                  <span className="text-border">|</span>
                  <span>B: <span className="font-bold text-green-400">{event.bravo_score ?? '??'}%</span></span>
                </div>
            </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="outline" className="gap-1.5"><MapPin className="w-3 h-3" />{event.location}</Badge>
          {event.event_date && <Badge variant="outline" className="gap-1.5"><Calendar className="w-3 h-3" />{event.event_date}</Badge>}
          <Badge variant="outline">{event.category}</Badge>
        </div>
      </CardHeader>

      {event.ai_analysis && (
        <CardContent className="pt-0 pb-4">
          <p className="text-sm text-muted-foreground italic border-l-2 border-border pl-3">"{event.ai_analysis}"</p>
        </CardContent>
      )}

      {event.contacts && event.contacts.length > 0 && (
          <CardContent className="pt-0 pb-4">
              <div className="flex items-center gap-2 flex-wrap">
                  {event.contacts.map((contact) => (
                      contact.email && <Badge key={contact.id} variant="secondary" className="gap-1.5 text-xs"><Mail className="w-3 h-3" />{contact.email}</Badge>
                  ))}
              </div>
          </CardContent>
      )}

      <CardFooter className="pt-0 flex items-center justify-between gap-2">
        {!isProcessed && (
          <Button onClick={() => onReject(event.id)} variant="outline" size="sm" className="border-destructive/50 text-destructive hover:bg-destructive/10">
            <XCircle className="w-4 h-4 mr-1.5" />Не подходит
          </Button>
        )}
        
        <div className='flex items-center gap-2 ml-auto'>
            {event.status === 'verified' && (
                 <Button onClick={handleDetailsClick} size="sm">
                    <BrainCircuit className="w-4 h-4 mr-1.5" />Начать Глубинный Анализ
                </Button>
            )}
            {event.status === 'attack_ready' && (
                <Button onClick={handleDetailsClick} size="sm" className="bg-priority-high hover:bg-priority-high/90">
                    <Target className="w-4 h-4 mr-1.5" />Открыть Письма для Атаки
                </Button>
            )}
            {(event.status === 'sent' || event.status === 'rejected') && (
                 <Button onClick={handleDetailsClick} variant="ghost" size="sm">
                    <Eye className="w-4 h-4 mr-1.5" />Просмотреть
                </Button>
            )}
        </div>
      </CardFooter>
    </Card>
  );
}