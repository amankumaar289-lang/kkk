import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Opportunity, Attack } from "@shared/schema-vladyka";
import { Header } from "@/components/Header";
import { ControlPanel, SearchCriteria } from "@/components/ControlPanel";
import { EventCard } from "@/components/EventCard";
import { LetterPreviewModal } from "@/components/LetterPreviewModal";
import { MetricsDashboard, VladykaMetrics } from "@/components/MetricsDashboard";
import { EmptyState, ShimmerCards, RadarSearching } from "@/components/LoadingState";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type OpportunityWithContacts = Opportunity & { contacts?: any[] };

export default function Home() {
  const queryClient = useQueryClient();
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const { toast } = useToast();

  const { data: opportunities = [], isLoading: isLoadingOpportunities } = useQuery<OpportunityWithContacts[]>({
    queryKey: ['/api/events'],
    refetchInterval: (query: any) => {
      const data = query.state.data as OpportunityWithContacts[] | undefined;
      const isProcessing = data?.some(
        (opp) => ['scouted', 'verified', 'analyzing'].includes(opp.status)
      ) ?? false;
      return isProcessing ? 5000 : false; // Poll every 5 seconds if processing
    },
  });

  const { data: metrics } = useQuery<VladykaMetrics>({
    queryKey: ['/api/metrics'],
    refetchInterval: 5000,
  });

  const searchMutation = useMutation({
    mutationFn: (criteria: SearchCriteria) => apiRequest('POST', '/api/search-events', criteria),
    onSuccess: (data: any) => {
      toast({ title: "Разведка начата", description: `Протокол "Альфа" запущен. Найдено ${data.opportunitiesFound} потенциальных целей.` });
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
    },
    onError: (e: any) => toast({ title: "Ошибка разведки", description: e.message, variant: "destructive" }),
  });
  
  const analyzeMutation = useMutation({
    mutationFn: (opportunityId: string) => apiRequest('POST', '/api/deep-analyze', { opportunityId }),
    onSuccess: (_, opportunityId) => {
        toast({ title: "Глубинный анализ", description: "Протокол 'Чарли' запущен." });
        queryClient.invalidateQueries({ queryKey: ['/api/events'] });
    },
    onError: (e: any) => toast({ title: "Ошибка анализа", description: e.message, variant: "destructive" }),
  });

  const attackMutation = useMutation({
    mutationFn: (variables: { opportunityId: string; profile: 'corporate' | 'crypto' }) =>
      apiRequest<Attack>('POST', '/api/generate-letter', { opportunityId: variables.opportunityId, speakerProfile: variables.profile }),
    onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['/api/events'] });
        toast({ title: "Синтез атаки завершен", description: "Письма готовы к отправке." });
    },
    onError: (e: any) => toast({ title: "Ошибка синтеза атаки", description: e.message, variant: "destructive" }),
  });

  const feedbackMutation = useMutation({
    mutationFn: (variables: { opportunityId: string; isGoodFit: boolean, finalPitch?: string }) =>
      apiRequest('POST', '/api/feedback', variables),
    onSuccess: (_, { isGoodFit }) => {
      toast({ title: isGoodFit ? "Статус обновлен: Отправлено" : "Статус обновлен: Отклонено" });
      queryClient.invalidateQueries({ queryKey: ['/api/events'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
    },
    onError: (e: any) => toast({ title: "Ошибка обратной связи", description: e.message, variant: "destructive" }),
  });

  const { data: attackData, isLoading: isAttackLoading } = useQuery<Attack>({
      queryKey: ['/api/generate-letter', selectedOpportunity?.id, selectedOpportunity?.speaker_profile],
      queryFn: () => attackMutation.mutateAsync({ 
          opportunityId: selectedOpportunity!.id,
          profile: selectedOpportunity!.speaker_profile as 'corporate' | 'crypto' || 'corporate'
      }),
      enabled: !!selectedOpportunity,
      staleTime: Infinity,
  });

  /**
   * УЛЬТИМАТИВНАЯ ТОЧКА ВХОДА:
   * Эта функция (`handleSearch`) является ЕДИНСТВЕННЫМ действием, которое запускает
   * весь автономный рабочий процесс "Владыка".
   * Нажатие кнопки "Запустить поиск" в ControlPanel вызывает эту функцию,
   * которая инициирует Фазу 1 (Разведка) на бэкенде. Все последующие фазы
   * (Верификация, Анализ, Синтез Атаки) выполняются либо автоматически в фоне,
   * либо по нажатию кнопок на карточках событий.
   */
  const handleSearch = (criteria: SearchCriteria) => searchMutation.mutate(criteria);
  const handleReject = (opportunityId: string) => feedbackMutation.mutate({ opportunityId, isGoodFit: false });
  const handleSent = (opportunityId: string, finalPitch: string) => feedbackMutation.mutate({ opportunityId, isGoodFit: true, finalPitch });
  const handleViewDetails = (opportunity: Opportunity) => {
    setSelectedOpportunity(opportunity);
    if(opportunity.status === 'verified'){
        analyzeMutation.mutate(opportunity.id);
    }
  };

  const isSearching = searchMutation.isPending;
  const isAnythingLoading = isLoadingOpportunities && !opportunities.length;

  const defaultMetrics: VladykaMetrics = metrics || {
    totalOpportunities: 0, byStatus: { scouted: 0, verified: 0, analyzing: 0, attack_ready: 0, sent: 0, rejected: 0 }, avgScores: { alpha: 0, bravo: 0 },
  };

  const successRate = defaultMetrics.byStatus.sent + defaultMetrics.byStatus.rejected > 0
    ? Math.round((defaultMetrics.byStatus.sent / (defaultMetrics.byStatus.sent + defaultMetrics.byStatus.rejected)) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-background">
      <Header totalEvents={metrics?.totalOpportunities ?? 0} successRate={successRate} />
      <div className="flex h-[calc(100vh-80px)]">
        <aside className="w-80 flex-shrink-0 hidden md:block">
          <ControlPanel onSearch={handleSearch} isSearching={isSearching} />
        </aside>

        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-5xl mx-auto space-y-4">
            {isSearching && <RadarSearching />}
            {isAnythingLoading && !isSearching && <ShimmerCards count={5} />}
            {!isAnythingLoading && opportunities.length === 0 && <EmptyState />}
            
            {!isSearching && opportunities.length > 0 && opportunities.map((opportunity) => (
              <EventCard key={opportunity.id} opportunity={opportunity} onReject={handleReject} onViewDetails={handleViewDetails} />
            ))}
          </div>
        </main>

        <aside className="w-80 flex-shrink-0 hidden lg:block">
          <MetricsDashboard metrics={defaultMetrics} />
        </aside>
      </div>

      <LetterPreviewModal
        opportunity={selectedOpportunity}
        attack={attackData ?? null}
        isLoading={isAttackLoading || analyzeMutation.isPending}
        isOpen={!!selectedOpportunity}
        onClose={() => setSelectedOpportunity(null)}
        onProfileChange={(profile) => {
          if (selectedOpportunity) {
            setSelectedOpportunity({ ...selectedOpportunity, speaker_profile: profile });
          }
        }}
        onSent={(finalPitch) => {
          if (selectedOpportunity) {
            handleSent(selectedOpportunity.id, finalPitch);
            setSelectedOpportunity(null);
          }
        }}
      />
    </div>
  );
}