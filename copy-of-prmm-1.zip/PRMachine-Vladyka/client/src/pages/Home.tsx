import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Opportunity, Attack } from "@shared/schema-vladyka";
import { Header } from "@/components/Header";
import { ControlPanel, SearchCriteria } from "@/components/ControlPanel";
import { EventCard } from "@/components/EventCard";
import { LetterPreviewModal } from "@/components/LetterPreviewModal";
import { MetricsDashboard } from "@/components/MetricsDashboard";
import { EmptyState, RadarSearching, ShimmerCards } from "@/components/LoadingState";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface VladykaMetrics {
  totalOpportunities: number;
  byStatus: {
    scouted: number;
    verified: number;
    analyzing: number;
    attack_ready: number;
    sent: number;
    rejected: number;
  };
  avgScores: {
    alpha: number;
    bravo: number;
  };
}

export default function Home() {
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [selectedAttack, setSelectedAttack] = useState<Attack | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { toast } = useToast();

  const { data: opportunities = [], isFetching: isFetchingOpportunities } = useQuery<Opportunity[]>({
    queryKey: ['/api/opportunities'],
  });

  const { data: metrics } = useQuery<VladykaMetrics>({
    queryKey: ['/api/metrics'],
  });

  const searchMutation = useMutation({
    mutationFn: (criteria: SearchCriteria) => apiRequest('POST', '/api/vladyka/reconnaissance', criteria),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      toast({
        title: "Поиск завершен",
        description: "Обнаружены новые возможности.",
      });
    },
    onError: () => {
      toast({
        title: "Ошибка поиска",
        description: "Не удалось выполнить поиск.",
        variant: "destructive",
      });
    },
  });
  
  const verificationMutation = useMutation({
    mutationFn: (opportunityIds: string[]) => apiRequest('POST', '/api/vladyka/verification', { opportunityIds }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      toast({
        title: "Верификация запущена",
        description: "Проверка событий началась в фоновом режиме.",
      });
    },
  });

  const feedbackMutation = useMutation({
    mutationFn: ({ opportunityId, status }: { opportunityId: string; status: 'rejected' }) => 
      apiRequest('POST', '/api/vladyka/feedback', { opportunityId, status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
    },
  });

  const attackMutation = useMutation({
    mutationFn: ({ opportunityId, profile }: { opportunityId: string; profile: 'corporate' | 'crypto' }) =>
      apiRequest<Attack>('POST', '/api/vladyka/strike-synthesis', { opportunityId, speakerProfile: profile }),
    onSuccess: (data) => {
      setSelectedAttack(data);
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
    },
    onError: () => {
      toast({
        title: "Ошибка генерации",
        description: "Не удалось сгенерировать письмо",
        variant: "destructive",
      });
    },
  });

  const handleAccept = (opportunityId: string) => {
    verificationMutation.mutate([opportunityId]);
  };

  const handleReject = (opportunityId: string) => {
    feedbackMutation.mutate({ opportunityId, status: 'rejected' });
  };

  const handleViewDetails = (opportunity: Opportunity) => {
    setSelectedOpportunity(opportunity);
    setIsModalOpen(true);
    // Initially generate with corporate profile, user can switch in modal
    attackMutation.mutate({ opportunityId: opportunity.id, speakerProfile: 'corporate' });
  };

  const handleProfileChange = (profile: 'corporate' | 'crypto') => {
    if (selectedOpportunity) {
      // Clear previous attack to show loading state
      setSelectedAttack(null);
      attackMutation.mutate({ opportunityId: selectedOpportunity.id, profile });
    }
  };

  const defaultMetrics: VladykaMetrics = metrics || {
    totalOpportunities: 0,
    byStatus: { scouted: 0, verified: 0, analyzing: 0, attack_ready: 0, sent: 0, rejected: 0 },
    avgScores: { alpha: 0, bravo: 0 },
  };

  const successRate = defaultMetrics.totalOpportunities > 0
    ? Math.round(((defaultMetrics.byStatus.sent || 0) / (defaultMetrics.byStatus.sent + defaultMetrics.byStatus.rejected)) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-background">
      <Header 
        totalEvents={defaultMetrics.totalOpportunities} 
        successRate={successRate}
      />
      
      <div className="flex h-[calc(100vh-80px)]">
        <aside className="w-80 flex-shrink-0">
          <ControlPanel 
            onSearch={searchMutation.mutate} 
            isSearching={searchMutation.isPending} 
          />
        </aside>

        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-5xl mx-auto space-y-4">
            {searchMutation.isPending && <RadarSearching />}
            {isFetchingOpportunities && !searchMutation.isPending && <ShimmerCards />}
            
            {!searchMutation.isPending && !isFetchingOpportunities && opportunities.length === 0 && <EmptyState />}
            
            {!searchMutation.isPending && !isFetchingOpportunities && opportunities.length > 0 && opportunities.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                onAccept={handleAccept}
                onReject={handleReject}
                onViewDetails={handleViewDetails}
              />
            ))}
          </div>
        </main>

        <aside className="w-80 flex-shrink-0">
          <MetricsDashboard metrics={defaultMetrics} />
        </aside>
      </div>

      <LetterPreviewModal
        opportunity={selectedOpportunity}
        attack={selectedAttack}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedOpportunity(null);
          setSelectedAttack(null);
        }}
        onProfileChange={handleProfileChange}
      />
    </div>
  );
}
