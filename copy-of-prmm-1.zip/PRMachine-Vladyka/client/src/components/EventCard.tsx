import { Opportunity } from "@shared/schema-vladyka";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, Mail, Send, Eye, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface EventCardProps {
  event: Opportunity;
  onAccept: (id: string) => void;
  onReject: (id: string) => void;
  onViewDetails: (event: Opportunity) => void;
}

export function EventCard({ event, onAccept, onReject, onViewDetails }: EventCardProps) {
  const priorityColors = {
    high: "border-l-priority-high",
    medium: "border-l-priority-medium",
    low: "border-l-priority-low",
  };

  const statusIcons = {
    scouted: null,
    verified: <CheckCircle2 className="w-4 h-4 text-blue-500" />,
    analyzing: <Loader2 className="w-4 h-4 animate-spin" />,
    attack_ready: <CheckCircle2 className="w-4 h-4 text-priority-high" />,
    sent: <Send className="w-4 h-4 text-green-500" />,
    rejected: <XCircle className="w-4 h-4 text-destructive" />,
  };
  
  const relevanceScore = event.bravo_score ?? event.alpha_score ?? 0;
  const isProcessed = event.status === 'sent' || event.status === 'rejected';

  return (
    <Card
      className={cn(
        "border-l-4 hover-elevate active-elevate-2 transition-all duration-200 animate-slide-in",
        priorityColors[event.priority],
        isProcessed && "opacity-75"
      )}
      data-testid={`card-event-${event.id}`}
    >
      <CardHeader className="space-y-3 pb-4">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div className="flex-1 min-w-0">
            <CardTitle className="text-lg font-bold text-foreground line-clamp-2" data-testid={`text-event-title-${event.id}`}>
              {event.title}
            </CardTitle>
            <CardDescription className="mt-1.5 line-clamp-2" data-testid={`text-event-description-${event.id}`}>
              {event.description}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {statusIcons[event.status as keyof typeof statusIcons]}
            <Badge 
              variant="secondary" 
              className="font-mono text-xs"
              data-testid={`badge-score-${event.id}`}
            >
              {relevanceScore}/100
            </Badge>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="outline" className="gap-1.5" data-testid={`badge-location-${event.id}`}>
            <MapPin className="w-3 h-3" />
            {event.location}
          </Badge>
          {event.event_date && (
            <Badge variant="outline" className="gap-1.5" data-testid={`badge-date-${event.id}`}>
              <Calendar className="w-3 h-3" />
              {event.event_date}
            </Badge>
          )}
          <Badge variant="outline" data-testid={`badge-category-${event.id}`}>
            {event.category}
          </Badge>
        </div>
      </CardHeader>

      {event.ai_analysis && (
        <CardContent className="pt-0 pb-4">
          <div className="p-3 bg-muted/50 rounded-md border border-border">
            <p className="text-sm text-muted-foreground italic line-clamp-3" data-testid={`text-pitch-${event.id}`}>
              "{event.ai_analysis}"
            </p>
          </div>
        </CardContent>
      )}

      <CardFooter className="pt-0 flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          {!isProcessed && (
            <>
              <Button
                onClick={() => onAccept(event.id)}
                variant="default"
                size="sm"
                className="bg-priority-high/20 text-priority-high border-priority-high hover:bg-priority-high/30"
                data-testid={`button-accept-${event.id}`}
              >
                <CheckCircle2 className="w-4 h-4 mr-1.5" />
                Подходит
              </Button>
              <Button
                onClick={() => onReject(event.id)}
                variant="outline"
                size="sm"
                className="border-destructive text-destructive hover:bg-destructive/10"
                data-testid={`button-reject-${event.id}`}
              >
                <XCircle className="w-4 h-4 mr-1.5" />
                Не подходит
              </Button>
            </>
          )}
        </div>
        <Button
          onClick={() => onViewDetails(event)}
          variant="ghost"
          size="sm"
          className="ml-auto"
          data-testid={`button-details-${event.id}`}
        >
          <Eye className="w-4 h-4 mr-1.5" />
          Подробнее
        </Button>
      </CardFooter>
    </Card>
  );
}