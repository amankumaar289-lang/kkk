import type { Express } from "express";
import {
  searchRequestSchema,
  attackRequestSchema,
  feedbackRequestSchema,
} from "@shared/schema";

import {
  executeReconnaissance,
  executeStrikeSynthesis,
  handleFeedback,
  getAllOpportunities,
  getMetrics,
  getOpportunityWithContacts,
  getAttackForOpportunity,
} from "./lib/vladykaProtocol";

export function registerRoutes(app: Express) {
  // ============================================================================
  // CORE VLADYKA PROTOCOL ENDPOINTS
  // ============================================================================

  /**
   * Запускает Фазу 1: Разведка (Alpha)
   * Ищет события, создает и возвращает новые "opportunities"
   */
  app.post("/api/search", async (req, res, next) => {
    try {
      const parsed = searchRequestSchema.parse(req.body);
      const result = await executeReconnaissance(parsed);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  /**
   * Запускает Фазу 4: Синтез Атаки (Delta)
   * Генерирует питчи для конкретной возможности
   */
  app.post("/api/attack", async (req, res, next) => {
    try {
      const parsed = attackRequestSchema.parse(req.body);
      const result = await executeStrikeSynthesis(parsed);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  /**
   * Обрабатывает фидбек пользователя (подходит/не подходит)
   */
  app.post("/api/feedback", async (req, res, next) => {
    try {
      const parsed = feedbackRequestSchema.parse(req.body);
      const result = await handleFeedback(parsed);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  // ============================================================================
  // DATA ACCESS ENDPOINTS
  // ============================================================================

  /**
   * Получает все "opportunities"
   */
  app.get("/api/opportunities", async (_req, res, next) => {
    try {
      const opportunities = await getAllOpportunities();
      res.json(opportunities);
    } catch (error) {
      next(error);
    }
  });
  
    /**
   * Получает одну "opportunity" по ID с контактами
   */
  app.get("/api/opportunities/:id", async (req, res, next) => {
    try {
      const opportunity = await getOpportunityWithContacts(req.params.id);
      if (!opportunity) {
        return res.status(404).json({ message: "Opportunity not found" });
      }
      res.json(opportunity);
    } catch (error) {
      next(error);
    }
  });

  /**
   * Получает сгенерированную "атаку" для opportunity
   */
  app.get("/api/attacks/:opportunityId", async (req, res, next) => {
    try {
      const attack = await getAttackForOpportunity(req.params.opportunityId);
      res.json(attack);
    } catch (error) {
      next(error);
    }
  });

  /**
   * Получает общую статистику и метрики
   */
  app.get("/api/metrics", async (_req, res, next) => {
    try {
      const metrics = await getMetrics();
      res.json(metrics);
    } catch (error) {
      next(error);
    }
  });
}