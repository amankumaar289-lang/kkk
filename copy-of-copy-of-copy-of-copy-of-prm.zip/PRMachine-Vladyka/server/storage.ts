import { Opportunity, Attack, Contact, AttackPitch } from '@shared/schema';
import { v4 as uuidv4 } from 'uuid';

// In-memory database
const db: {
  opportunities: Map<string, Opportunity>;
  attacks: Map<string, Attack>;
  contacts: Map<string, Contact[]>;
} = {
  opportunities: new Map(),
  attacks: new Map(),
  contacts: new Map(),
};

// --- Opportunity Management ---

export function addOpportunity(data: Omit<Opportunity, 'id' | 'created_at' | 'status' | 'contacts' | 'attack'>): Opportunity {
  const id = uuidv4();
  const now = new Date().toISOString();
  const newOpportunity: Opportunity = {
    ...data,
    id,
    created_at: now,
    status: 'scouted',
    contacts: [],
    attack: null,
  };
  db.opportunities.set(id, newOpportunity);
  return newOpportunity;
}

export function updateOpportunity(id: string, data: Partial<Omit<Opportunity, 'id'>>): Opportunity | undefined {
  const opportunity = db.opportunities.get(id);
  if (opportunity) {
    const updated = { ...opportunity, ...data };
    db.opportunities.set(id, updated);
    return updated;
  }
  return undefined;
}

export function getOpportunity(id: string): Opportunity | undefined {
  return db.opportunities.get(id);
}

export function getAllOpportunities(): Opportunity[] {
  return Array.from(db.opportunities.values()).sort((a, b) => 
    new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
  );
}

// --- Contact Management ---

export function addContact(data: Omit<Contact, 'id'>): Contact {
  const id = uuidv4();
  const newContact: Contact = { ...data, id };
  
  const existingContacts = db.contacts.get(data.opportunity_id) || [];
  db.contacts.set(data.opportunity_id, [...existingContacts, newContact]);

  // Also update the opportunity object
  const opportunity = db.opportunities.get(data.opportunity_id);
  if (opportunity) {
    opportunity.contacts.push(newContact);
  }

  return newContact;
}

export function getContactsForOpportunity(opportunityId: string): Contact[] {
  return db.contacts.get(opportunityId) || [];
}


// --- Attack Management ---

export function addAttack(data: Omit<Attack, 'id' | 'created_at'>): Attack {
  const id = uuidv4();
  const now = new Date().toISOString();
  const newAttack: Attack = {
    ...data,
    id,
    created_at: now,
  };
  db.attacks.set(data.opportunity_id, newAttack);
  
  // Also update the opportunity object
  const opportunity = db.opportunities.get(data.opportunity_id);
  if (opportunity) {
    opportunity.attack = newAttack;
  }

  return newAttack;
}

export function getAttackForOpportunity(opportunityId: string): Attack | undefined {
  return db.attacks.get(opportunityId);
}

// --- Metrics ---

export function getMetrics() {
  const opportunities = getAllOpportunities();
  const total = opportunities.length;

  const byStatus = opportunities.reduce((acc, opp) => {
    acc[opp.status] = (acc[opp.status] || 0) + 1;
    return acc;
  }, {} as Record<Opportunity['status'], number>);

  const alphaScores = opportunities.map(o => o.alpha_score).filter(Boolean) as number[];
  const bravoScores = opportunities.map(o => o.bravo_score).filter(Boolean) as number[];

  const avgAlpha = alphaScores.length > 0 ? alphaScores.reduce((a, b) => a + b, 0) / alphaScores.length : 0;
  const avgBravo = bravoScores.length > 0 ? bravoScores.reduce((a, b) => a + b, 0) / bravoScores.length : 0;

  const sentCount = byStatus.sent || 0;
  const successRate = total > 0 ? (sentCount / total) * 100 : 0;

  return {
    totalOpportunities: total,
    successRate: successRate,
    byStatus: {
      scouted: byStatus.scouted || 0,
      verified: byStatus.verified || 0,
      analyzing: byStatus.analyzing || 0,
      attack_ready: byStatus.attack_ready || 0,
      sent: byStatus.sent || 0,
      rejected: byStatus.rejected || 0,
    },
    avgScores: {
      alpha: Math.round(avgAlpha),
      bravo: Math.round(avgBravo),
    }
  };
}
