// IMPORTANT: Hardcoded API keys as requested by the user.
const BRAVE_API_KEYS = [
  "BSAiH1vhLfsKM_unpLEPqIulBOwnDgt",
  "BSA-qCbl-osY1wjC2lW4PsIjx0Qt1IN",
  "BSArBFB2NMjeC8WUZ_Mlif9CwSyjw_2",
  process.env.BRAVE_API_KEY_4, // резервный
].filter(Boolean) as string[];

if (BRAVE_API_KEYS.length === 0) {
  console.error("FATAL: No Brave API keys provided.");
}

let currentKeyIndex = 0;
const requestTimestamps: number[] = [];

function getNextApiKey(): string {
  const key = BRAVE_API_KEYS[currentKeyIndex];
  currentKeyIndex = (currentKeyIndex + 1) % BRAVE_API_KEYS.length;
  return key;
}

async function rateLimit(): Promise<void> {
  const now = Date.now();
  // Убираем старые временные метки (старше 1 секунды)
  while (requestTimestamps.length > 0 && now - requestTimestamps[0] > 1000) {
    requestTimestamps.shift();
  }

  // Если за последнюю секунду было больше запросов, чем ключей, ждем
  if (requestTimestamps.length >= BRAVE_API_KEYS.length) {
    const waitTime = 1000 - (now - requestTimestamps[0]);
    if (waitTime > 0) {
      await new Promise(resolve => setTimeout(resolve, waitTime));
    }
  }

  requestTimestamps.push(Date.now());
}

export interface BraveSearchResult {
  title: string;
  url: string;
  description?: string;
  extra_snippets?: string[];
}

export interface BraveSearchResponse {
  web?: {
    results: BraveSearchResult[];
  };
}

export async function searchEvents(query: string, retries = 3): Promise<BraveSearchResult[]> {
  await rateLimit();
  const apiKey = getNextApiKey();
  
  const searchQuery = encodeURIComponent(query);
  const url = `https://api.search.brave.com/res/v1/web/search?q=${searchQuery}&count=15&text_decorations=false&extra_snippets=true`;
  
  try {
    const res = await fetch(url, {
      headers: {
        'Accept': 'application/json',
        'X-Subscription-Token': apiKey,
      },
    });
    
    if (!res.ok) {
      throw new Error(`Brave API error: ${res.status} ${res.statusText}`);
    }
    
    const data = await res.json() as BraveSearchResponse;
    return data.web?.results || [];

  } catch (error) {
    console.error(`Brave search failed for query "${query}" with key index ${currentKeyIndex}`, error);
    if (retries > 0) {
      console.log(`Retrying... (${retries} attempts left)`);
      await new Promise(resolve => setTimeout(resolve, 1500)); // wait before retry
      return searchEvents(query, retries - 1);
    }
    return []; // Return empty array on final failure
  }
}

export async function searchMultipleQueries(queries: string[]): Promise<BraveSearchResult[]> {
  const allResults: BraveSearchResult[] = [];
  const seenUrls = new Set<string>();

  const promises = queries.map(query => searchEvents(query));
  const resultsArrays = await Promise.all(promises);

  for (const results of resultsArrays) {
    for (const result of results) {
      if (result.url && !seenUrls.has(result.url)) {
        seenUrls.add(result.url);
        allResults.push(result);
      }
    }
  }
  
  return allResults;
}