// IMPORTANT: Hardcoded API key as requested by the user.
const OPENROUTER_API_KEY = "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";

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface ChatCompletionResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export async function chatCompletion(messages: ChatMessage[]): Promise<string> {
  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
      'HTTP-Referer': 'https://pr-command-center.replit.app',
      'X-Title': 'PR Command Center',
    },
    body: JSON.stringify({
      model: 'deepseek/deepseek-r1-0528-qwen3-8b',
      messages,
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    console.error("OpenRouter API Error:", errorBody);
    throw new Error(`OpenRouter API error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json() as ChatCompletionResponse;
  return data.choices[0]?.message?.content || '';
}

export async function analyzeEventRelevance(
  eventTitle: string,
  eventDescription: string,
  location: string
): Promise<{ score: number; pitch: string; category: string }> {
  const prompt = `
  Analyze the event for relevance to an AI expert speaker based on these criteria. Provide a JSON object.

  EVENT:
  Title: ${eventTitle}
  Description: ${eventDescription}
  Location: ${location}

  SCORING CRITERIA:
  1. Location (max 40): MOSCOW offline = 40. St. Petersburg = 25. Online = 15. International = 20.
  2. Thematic (max 30): NON-AI business/sales/marketing conferences = 30. Pure AI conferences = 10.
  3. Audience (max 20): Business owners, CEOs, Sales/Marketing heads = 20. Technical specialists = 10.
  4. Format (max 10): Business conference/forum = 10. Niche meetup = 5.

  RESPONSE FORMAT (JSON ONLY):
  {
    "score": <number 0-100>,
    "pitch": "<A short, compelling one-sentence pitch for the organizers>",
    "category": "<A single relevant category like 'Business', 'Sales', 'Marketing', 'Tech', 'Finance'>"
  }
  `;

  const response = await chatCompletion([
    { role: 'system', content: 'You are an expert event analyst. Respond only with a valid JSON object.' },
    { role: 'user', content: prompt }
  ]);

  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return {
        score: Math.min(100, Math.max(0, parsed.score || 0)),
        pitch: parsed.pitch || 'AI-driven insights to boost business performance.',
        category: parsed.category || 'General'
      };
    }
  } catch (e) {
    console.error('Failed to parse AI relevance response:', response, e);
  }

  // Fallback
  return { score: 30, pitch: 'AI-driven insights to boost business performance.', category: 'General' };
}

export async function generateCoverLetter(
  eventTitle: string,
  eventDescription: string,
  speakerProfile: 'corporate' | 'crypto',
  organizerInfo: any
): Promise<string> {
  const profileData = speakerProfile === 'corporate'
    ? {
      expertise: 'AI для бизнеса и автоматизации продаж',
      achievements: 'внедрял AI в Росатом, Газпром. Эксперт по практическому применению AI в продажах и маркетинге.',
      topics: '"Как AI увеличивает продажи на 30%", "Автоматизация отдела продаж с AI", "AI для бизнеса: от хайпа к реальной выгоде"',
      link: 'https://speaker-zakhar-kondratev.replit.app/'
    } : {
      expertise: 'AI в Web3 и продакшн-технологиях',
      achievements: 'эксперт по AI и крипто-технологиям, создатель DeFAI-систем с ROI +194%.',
      topics: '"Архитектура Автономных AI-Организаций", "Deep Research для бизнеса: как AI находит то, что Google не покажет", "DeFAI: Автономные AI-системы для крипто-трейдинга"',
      link: 'http://the-trends-zakhar-kondratev.replit.app/'
    };

  const prompt = `
  Ты — PR-агент Захара Кондратьева. Напиши сопроводительное письмо организаторам мероприятия.

  ЗАДАЧА: Написать короткое, персонализированное письмо (не более 150 слов). Цель — заинтересовать организаторов, чтобы они пригласили Захара спикером (без оплаты с его стороны).

  ИНФОРМАЦИЯ О МЕРОПРИЯТИИ:
  - Название: ${eventTitle}
  - Описание: ${eventDescription}

  ИНФОРМАЦИЯ О СПИКЕРЕ (Профиль: ${speakerProfile}):
  - Имя: Захар Кондратьев
  - Экспертиза: ${profileData.expertise}
  - Ключевые достижения: ${profileData.achievements}
  - Примерные темы: ${profileData.topics}
  - Спикерское досье: ${profileData.link}

  СТРУКТУРА ПИСЬМА:
  1.  **Обращение:** Уважаемые организаторы,
  2.  **Связка:** Кратко свяжи экспертизу Захара с темой/аудиторией мероприятия.
  3.  **Ценность:** Объясни, какую уникальную, практическую пользу получат участники. Не теория, а реальные кейсы.
  4.  **Темы на выбор:** Предложи 2-3 адаптированные темы из списка выше.
  5.  **Ссылки:** Укажи ссылку на спикерское досье.
  6.  **Завершение:** С уважением, Захар Кондратьев.

  ТРЕБОВАНИЯ:
  - Максимально персонализируй под мероприятие.
  - Тон: уверенный, профессиональный, по существу.
  - Не используй шаблонные фразы.
  - Пиши только текст письма, без лишних комментариев.
  `;

  return await chatCompletion([{ role: 'user', content: prompt }]);
}

export async function extractContacts(htmlContent: string): Promise<{ emails: string[]; telegram: string[]; phones: string[]; }> {
  const cleanText = htmlContent.replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '').replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '');
  const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
  const telegramRegex = /t\.me\/[a-zA-Z0-9_]{5,}|@[a-zA-Z0-9_]{5,}/g;
  
  const emails = Array.from(new Set(cleanText.match(emailRegex) || []));
  const telegramsRaw = Array.from(new Set(cleanText.match(telegramRegex) || []));
  const telegrams = telegramsRaw.map(t => t.startsWith('@') ? t : t.split('/').pop() || t);

  return { emails, telegram: telegrams, phones: [] };
}
