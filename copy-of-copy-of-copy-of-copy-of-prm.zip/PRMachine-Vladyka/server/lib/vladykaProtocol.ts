import {
  addOpportunity,
  updateOpportunity,
  addContact,
  addAttack,
  // Fix: Alias imported functions to avoid name collision
  getAllOpportunities as storageGetAllOpportunities,
  getMetrics as storageGetMetrics,
  getOpportunity,
  // Fix: Alias imported functions to avoid name collision
  getAttackForOpportunity as storageGetAttackForOpportunity,
  getContactsForOpportunity
} from '../storage';
import { searchMultipleQueries } from './braveClient';
import { analyzeEventRelevance, generateCoverLetter, extractContacts } from './openrouterClient';
import { Opportunity, SearchRequest, AttackRequest, FeedbackRequest, Attack } from '@shared/schema';

// ============================================================================
// УТИЛИТЫ ДЛЯ ПРОТОКОЛА
// ============================================================================

function determinePriority(location: string, score: number): 'high' | 'medium' | 'low' {
  if (location === 'МОСКВА' && score >= 60) return 'high';
  if ((location === 'СПб' || location === 'Международное') && score >= 70) return 'medium';
  if (score >= 50) return 'medium';
  return 'low';
}

function extractEventDate(text: string): string | null {
  const patterns = [
    /(\d{1,2}\s+(?:января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\s+\d{4})/i,
    /\d{1,2}\.\d{1,2}\.\d{4}/,
  ];
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) return match[0];
  }
  return null;
}

// ============================================================================
// ФАЗА 1: РАЗВЕДКА (Alpha) - Поиск и первичный скоринг
// ============================================================================

export async function executeReconnaissance(request: SearchRequest) {
  console.log(`[ALPHA] Starting reconnaissance for: "${request.query}"`);
  
  const searchQueries = [`${request.query} ${request.location === 'Все' ? 'Москва' : request.location} конференция 2025`, `спикеры для ${request.query} ${request.location === 'Все' ? '' : request.location}`];
  const searchResults = await searchMultipleQueries(searchQueries);

  const opportunities: Opportunity[] = [];
  for (const result of searchResults.slice(0, 10)) { // Limit to 10 for demo
    const newOpp = addOpportunity({
      title: result.title,
      description: result.description || 'Нет описания',
      event_url: result.url,
      event_date: extractEventDate(result.description || ''),
      location: request.location === 'Все' ? 'МОСКВА' : request.location,
      category: 'Не определена',
      alpha_score: 50 + Math.floor(Math.random() * 20),
      bravo_score: null,
      priority: 'medium',
      raw_search_data: result,
    });
    opportunities.push(newOpp);
  }
  
  // Асинхронно запускаем верификацию
  if (opportunities.length > 0) {
    executeVerification({ opportunityIds: opportunities.map(o => o.id) });
  }

  return { opportunitiesFound: opportunities.length, opportunities };
}

// ============================================================================
// ФАЗА 2: ВЕРИФИКАЦИЯ (Bravo) - Проверка релевантности и извлечение контактов
// ============================================================================
export async function executeVerification(request: { opportunityIds: string[] }) {
  console.log(`[BRAVO] Starting verification for ${request.opportunityIds.length} opportunities`);

  for (const id of request.opportunityIds) {
    const opp = getOpportunity(id);
    if (!opp) continue;
    
    try {
      const { score, pitch, category } = await analyzeEventRelevance(opp.title, opp.description, opp.location);
      
      const priority = determinePriority(opp.location, score);
      
      updateOpportunity(id, {
        status: score >= 40 ? 'analyzing' : 'rejected',
        bravo_score: score,
        aiPitch: pitch,
        category,
        priority,
      });
      
      console.log(`[BRAVO] Verified: ${opp.title} | Score: ${score}`);
    } catch(e) {
      console.error(`[BRAVO] Failed to verify ${opp.title}`, e);
      updateOpportunity(id, { status: 'error' });
    }
  }
}

// ============================================================================
// ФАЗА 4: СИНТЕЗ АТАКИ (Delta)
// ============================================================================
export async function executeStrikeSynthesis(request: AttackRequest) {
  console.log(`[DELTA] Starting strike synthesis for: ${request.opportunityId}`);
  const opp = getOpportunity(request.opportunityId);
  if (!opp) throw new Error("Opportunity not found");

  updateOpportunity(opp.id, { status: 'attack_ready' });
  
  const existingAttack = getAttackForOpportunity(opp.id);
  if (existingAttack && existingAttack.speaker_profile === request.profile) {
    return existingAttack;
  }
  
  const pitches = await Promise.all(['Дерзкий', 'Консервативный', 'Технический'].map(async (variant) => {
    const body = await generateCoverLetter(opp.title, opp.description, request.profile, {});
    const subject = `Выступление на "${opp.title}": ${profileData[request.