import { z } from 'zod';

// Схема для контактов, связанных с возможностью
export const contactSchema = z.object({
  id: z.string().uuid(),
  opportunity_id: z.string().uuid(),
  email: z.string().email().optional().nullable(),
  telegram: z.string().optional().nullable(),
  phone: z.string().optional().nullable(),
  name: z.string().optional().nullable(),
  role: z.string().optional().nullable(),
});

// Схема для одного варианта питча
export const attackPitchSchema = z.object({
  variant_name: z.string(),
  subject: z.string(),
  body: z.string(),
  mailto_link: z.string(),
});

// Схема для "атаки" - набора сгенерированных питчей
export const attackSchema = z.object({
  id: z.string().uuid(),
  opportunity_id: z.string().uuid(),
  generated_pitches: z.array(attackPitchSchema),
  speaker_profile: z.enum(['corporate', 'crypto']),
  created_at: z.string(),
});

// Основная схема для "возможности" (мероприятия)
export const opportunitySchema = z.object({
  id: z.string().uuid(),
  title: z.string(),
  description: z.string(),
  event_url: z.string().url(),
  event_date: z.string().optional().nullable(),
  location: z.string(),
  category: z.string(),
  status: z.enum(['scouted', 'verified', 'analyzing', 'attack_ready', 'sent', 'rejected', 'error']),
  alpha_score: z.number().optional().nullable(),
  bravo_score: z.number().optional().nullable(),
  priority: z.enum(['high', 'medium', 'low']),
  raw_search_data: z.any().optional(),
  contacts: z.array(contactSchema).optional().default([]),
  attack: attackSchema.optional().nullable(),
  created_at: z.string(),
});

// Схема для запроса на поиск
export const searchRequestSchema = z.object({
  query: z.string().min(1),
  location: z.enum(['МОСКВА', 'СПб', 'Онлайн', 'Международное', 'Все']).default('Все'),
  dateFrom: z.string().optional(),
  dateTo: z.string().optional(),
});

// Схема для запроса на генерацию "атаки"
export const attackRequestSchema = z.object({
  opportunityId: z.string().uuid(),
  profile: z.enum(['corporate', 'crypto']),
});

// Схема для отправки фидбека
export const feedbackRequestSchema = z.object({
  opportunityId: z.string().uuid(),
  isGoodFit: z.boolean(),
});

// Экспорт типов TypeScript
export type Opportunity = z.infer<typeof opportunitySchema>;
export type Attack = z.infer<typeof attackSchema>;
export type Contact = z.infer<typeof contactSchema>;
export type AttackPitch = z.infer<typeof attackPitchSchema>;
