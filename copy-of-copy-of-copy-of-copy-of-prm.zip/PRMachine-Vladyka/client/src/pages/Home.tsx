import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Opportunity, Attack, SearchCriteria } from "@shared/schema";
import { Header } from "@/components/Header";
import { ControlPanel } from "@/components/ControlPanel";
import { EventCard } from "@/components/EventCard";
import { EventDetailModal } from "@/components/EventDetailModal";
import { MetricsDashboard } from "@/components/MetricsDashboard";
import { EmptyState, RadarSearching } from "@/components/LoadingState";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface VladykaMetrics {
  totalOpportunities: number;
  successRate: number;
  byStatus: {
    scouted: number;
    verified: number;
    analyzing: number;
    attack_ready: number;
    sent: number;
    rejected: number;
  };
  avgScores: {
    alpha: number;
    bravo: number;
  };
}

export default function Home() {
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { toast } = useToast();

  const { data: opportunities = [], isLoading: isLoadingOpportunities } = useQuery<Opportunity[]>({
    queryKey: ['/api/opportunities'],
    refetchInterval: 5000, // Опрашиваем бэкенд каждые 5 секунд
  });

  const { data: metrics } = useQuery<VladykaMetrics>({
    queryKey: ['/api/metrics'],
    refetchInterval: 5000,
  });
  
  const searchMutation = useMutation({
    mutationFn: async (criteria: SearchCriteria) => {
      return await apiRequest('POST', '/api/search', criteria);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      toast({
        title: "Фаза 'Альфа' завершена",
        description: `Найдено ${data.opportunitiesFound} новых возможностей. Запущена верификация...`,
      });
    },
    onError: (error) => {
      toast({
        title: "Ошибка поиска",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const feedbackMutation = useMutation({
    mutationFn: async ({ opportunityId, isGoodFit }: { opportunityId: string; isGoodFit: boolean }) => {
      return await apiRequest('POST', '/api/feedback', { opportunityId, isGoodFit });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
       if (variables.isGoodFit) {
        toast({ title: "Возможность принята", description: "Генерируется атака..." });
      } else {
        toast({ title: "Возможность отклонена"});
      }
    },
  });
  
  const attackMutation = useMutation<Attack, Error, { opportunityId: string, profile: 'corporate' | 'crypto' }>({
    mutationFn: async ({ opportunityId, profile }) => {
      return await apiRequest('POST', '/api/attack', { opportunityId, profile });
    },
    onSuccess: (data) => {
      queryClient.setQueryData(['/api/attacks', data.opportunity_id], data);
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      toast({
        title: "Синтез Атаки Завершен",
        description: `Сгенерировано ${data.generated_pitches.length} варианта письма.`
      });
    },
    onError: (error) => {
      toast({ title: "Ошибка генерации атаки", description: error.message, variant: 'destructive' })
    }
  });
  
  const handleSearch = (criteria: Omit<SearchCriteria, 'id'>) => {
    searchMutation.mutate(criteria);
  };
  
  const handleFeedback = (opportunityId: string, isGoodFit: boolean) => {
    feedbackMutation.mutate({ opportunityId, isGoodFit });
  };

  const handleViewDetails = (opportunity: Opportunity) => {
    setSelectedOpportunity(opportunity);
    setIsModalOpen(true);
    attackMutation.mutate({ opportunityId: opportunity.id, profile: 'corporate' });
  };

  const handleProfileChange = (profile: 'corporate' | 'crypto') => {
    if (selectedOpportunity) {
      // Clear previous attack data to show loading state
      queryClient.setQueryData(['/api/attacks', selectedOpportunity.id], null);
      attackMutation.mutate({ opportunityId: selectedOpportunity.id, profile });
    }
  };

  const defaultMetrics: VladykaMetrics = metrics || {
    totalOpportunities: 0,
    successRate: 0,
    byStatus: { scouted: 0, verified: 0, analyzing: 0, attack_ready: 0, sent: 0, rejected: 0 },
    avgScores: { alpha: 0, bravo: 0 },
  };
  
  const isProcessing = searchMutation.isPending || opportunities.some(o => ['scouted', 'verified', 'analyzing'].includes(o.status));

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header 
        totalEvents={metrics?.totalOpportunities || 0}
        successRate={metrics?.successRate || 0}
      />
      
      <div className="flex h-[calc(100vh-81px)]">
        <aside className="w-[340px] flex-shrink-0">
          <ControlPanel 
            onSearch={handleSearch} 
            isSearching={searchMutation.isPending} 
          />
        </aside>

        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-5xl mx-auto space-y-4">
            {isProcessing && !opportunities.length && <RadarSearching />}
            
            {!isProcessing && opportunities.length === 0 && <EmptyState />}
            
            {opportunities.map((opp) => (
              <EventCard
                key={opp.id}
                event={opp}
                onAccept={() => handleFeedback(opp.id, true)}
                onReject={() => handleFeedback(opp.id, false)}
                onViewDetails={handleViewDetails}
                isFeedbackPending={feedbackMutation.isPending}
              />
            ))}
          </div>
        </main>

        <aside className="w-[320px] flex-shrink-0">
          <MetricsDashboard metrics={defaultMetrics} />
        </aside>
      </div>

      {selectedOpportunity && (
        <EventDetailModal
          opportunity={selectedOpportunity}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onProfileChange={handleProfileChange}
        />
      )}
    </div>
  );
}