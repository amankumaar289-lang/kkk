import { Opportunity } from "@shared/schema";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, Mail, Send, Eye, CheckCircle2, XCircle, Loader2, Target, BrainCircuit, BotMessageSquare } from "lucide-react";
import { cn } from "@/lib/utils";

interface EventCardProps {
  event: Opportunity;
  onAccept: (id: string) => void;
  onReject: (id: string) => void;
  onViewDetails: (event: Opportunity) => void;
  isFeedbackPending: boolean;
}

export function EventCard({ event, onAccept, onReject, onViewDetails, isFeedbackPending }: EventCardProps) {
  const priorityColors = {
    high: "border-l-priority-high shadow-lg shadow-priority-high/10",
    medium: "border-l-priority-medium",
    low: "border-l-priority-low",
  };

  const statusInfo = {
    scouted: { icon: <Target className="w-4 h-4 text-blue-500 animate-pulse" />, text: "Разведка" },
    verified: { icon: <CheckCircle2 className="w-4 h-4 text-blue-400" />, text: "Верификация" },
    analyzing: { icon: <BrainCircuit className="w-4 h-4 text-purple-400 animate-pulse" />, text: "Анализ" },
    attack_ready: { icon: <BotMessageSquare className="w-4 h-4 text-green-500" />, text: "Готово к атаке" },
    sent: { icon: <Send className="w-4 h-4 text-gray-500" />, text: "Отправлено" },
    rejected: { icon: <XCircle className="w-4 h-4 text-destructive" />, text: "Отклонено" },
    error: { icon: <XCircle className="w-4 h-4 text-destructive" />, text: "Ошибка" },
  };

  const isProcessed = event.status === 'sent' || event.status === 'rejected';
  const isActionable = event.status === 'attack_ready';

  return (
    <Card
      className={cn(
        "border-l-4 hover-elevate active-elevate-2 transition-all duration-200 animate-in slide-in-from-right-5",
        priorityColors[event.priority],
        isProcessed && "opacity-60"
      )}
      data-testid={`card-event-${event.id}`}
    >
      <CardHeader className="space-y-3 pb-4">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div className="flex-1 min-w-0">
            <CardTitle className="text-lg font-bold text-foreground line-clamp-2" data-testid={`text-event-title-${event.id}`}>
              {event.title}
            </CardTitle>
            <CardDescription className="mt-1.5 line-clamp-2" data-testid={`text-event-description-${event.id}`}>
              {event.description}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
             <Badge variant="outline" className="gap-1.5 font-mono text-xs">
              {statusInfo[event.status]?.icon}
              {statusInfo[event.status]?.text}
            </Badge>
            <Badge 
              variant="secondary" 
              className="font-mono text-xs"
              data-testid={`badge-score-${event.id}`}
            >
             α: {event.alpha_score || '-'} β: {event.bravo_score || '-'}
            </Badge>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <Badge variant="outline" className="gap-1.5" data-testid={`badge-location-${event.id}`}>
            <MapPin className="w-3 h-3" />
            {event.location}
          </Badge>
          {event.event_date && (
            <Badge variant="outline" className="gap-1.5" data-testid={`badge-date-${event.id}`}>
              <Calendar className="w-3 h-3" />
              {event.event_date}
            </Badge>
          )}
          <Badge variant="outline" data-testid={`badge-category-${event.id}`}>
            {event.category}
          </Badge>
        </div>
      </CardHeader>
      
      <CardFooter className="pt-0 flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          {!isProcessed && (
            <>
              <Button
                onClick={() => onAccept(event.id)}
                variant="outline"
                size="sm"
                className="border-green-500/50 text-green-400 hover:bg-green-500/10 hover:text-green-300"
                data-testid={`button-accept-${event.id}`}
                // Fix: Cannot find name 'feedback'. Use isFeedbackPending prop instead.
                disabled={isFeedbackPending}
              >
                <CheckCircle2 className="w-4 h-4 mr-1.5" />
                Подходит
              </Button>
              <Button
                onClick={() => onReject(event.id)}
                variant="outline"
                size="sm"
                className="border-destructive/50 text-destructive hover:bg-destructive/10"
                data-testid={`button-reject-${event.id}`}
                // Fix: Cannot find name 'feedback'. Use isFeedbackPending prop instead.
                disabled={isFeedbackPending}
              >
                <XCircle className="w-4 h-4 mr-1.5" />
                Не подходит
              </Button>
            </>
          )}
        </div>
        <Button
          onClick={() => onViewDetails(event)}
          variant="ghost"
          size="sm"
          className="ml-auto"
          data-testid={`button-details-${event.id}`}
          disabled={!isActionable && !isProcessed}
        >
          <Eye className="w-4 h-4 mr-1.5" />
          {isActionable ? "Синтез атаки" : "Детали"}
        </Button>
      </CardFooter>
    </Card>
  );
}