import { Target, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  totalEvents: number;
  successRate: number;
}

export function Header({ totalEvents, successRate }: HeaderProps) {
  return (
    <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50 h-[81px]">
      <div className="container mx-auto px-6 h-full">
        <div className="flex items-center justify-between gap-4 flex-wrap h-full">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Target className="w-8 h-8 text-primary animate-glow" data-testid="icon-logo" />
              <div className="absolute inset-0 bg-primary/20 blur-lg animate-glow rounded-full"></div>
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-foreground" data-testid="text-app-title">
                PR Command Center
              </h1>
              <p className="text-sm text-muted-foreground font-mono">
                Протокол "Владыка"
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-6 flex-wrap">
            <div className="flex items-center gap-4">
              <div className="text-center" data-testid="stats-events">
                <div className="text-2xl font-bold font-mono text-foreground animate-count-up">
                  {totalEvents.toString().padStart(3, '0')}
                </div>
                <div className="text-xs text-muted-foreground uppercase tracking-wide">
                  Цели
                </div>
              </div>
              
              <div className="h-10 w-px bg-border"></div>
              
              <div className="text-center" data-testid="stats-success">
                <div className="text-2xl font-bold font-mono text-green-400">
                  {successRate.toFixed(1)}%
                </div>
                <div className="text-xs text-muted-foreground uppercase tracking-wide">
                  Успех
                </div>
              </div>
            </div>
            
            <Button 
              variant="ghost" 
              size="icon"
              data-testid="button-settings"
              className="hover-elevate active-elevate-2"
            >
              <Settings className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}