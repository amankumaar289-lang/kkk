import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Opportunity, Attack } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, CheckCircle2, Building2, Coins, Loader2, BotMessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface EventDetailModalProps {
  opportunity: Opportunity | null;
  isOpen: boolean;
  onClose: () => void;
  onProfileChange: (profile: 'corporate' | 'crypto') => void;
}

export function EventDetailModal({
  opportunity,
  isOpen,
  onClose,
  onProfileChange,
}: EventDetailModalProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const { data: attack, isLoading: isLoadingAttack } = useQuery<Attack>({
    queryKey: ['/api/attacks', opportunity?.id],
    queryFn: async () => apiRequest('GET', `/api/attacks/${opportunity!.id}`),
    enabled: !!opportunity,
    refetchOnWindowFocus: false,
  });

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast({
        title: "Скопировано!",
        description: "Письмо скопировано в буфер обмена",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Ошибка копирования",
        variant: "destructive"
      });
    }
  };

  if (!opportunity) return null;

  const currentProfile = attack?.speaker_profile || 'corporate';
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col" data-testid="modal-letter-preview">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-3" data-testid="text-modal-title">
            <span>{opportunity.title}</span>
            <Badge variant="outline" data-testid="badge-event-location">
              {opportunity.location}
            </Badge>
          </DialogTitle>
          <DialogDescription data-testid="text-modal-description">
            Синтез атаки: персонализированные сопроводительные письма
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2 py-3 border-y border-border">
          <span className="text-sm text-muted-foreground">Профиль спикера:</span>
          <Button
            variant={currentProfile === 'corporate' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => onProfileChange('corporate')}
            className="gap-1.5"
            data-testid="button-profile-corporate"
          >
            <Building2 className="w-4 h-4" />
            Корпоративный
          </Button>
          <Button
            variant={currentProfile === 'crypto' ? 'secondary' : 'outline'}
            size="sm"
            onClick={() => onProfileChange('crypto')}
            className="gap-1.5"
            data-testid="button-profile-crypto"
          >
            <Coins className="w-4 h-4" />
            Крипто/Web3
          </Button>
        </div>

        <div className="flex-1 overflow-auto p-1">
          {isLoadingAttack && (
            <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
              <BotMessageSquare className="w-12 h-12 text-primary animate-pulse" />
              <h3 className="text-lg font-bold">Синтез атаки...</h3>
              <p className="text-sm text-muted-foreground font-mono">DeepSeek R1 генерирует питчи...</p>
            </div>
          )}
          {attack && (
            <Tabs defaultValue={attack.generated_pitches[0].variant_name} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                {attack.generated_pitches.map(pitch => (
                   <TabsTrigger key={pitch.variant_name} value={pitch.variant_name}>{pitch.variant_name}</TabsTrigger>
                ))}
              </TabsList>
              {attack.generated_pitches.map(pitch => (
                <TabsContent key={pitch.variant_name} value={pitch.variant_name}>
                  <div className="bg-muted/30 p-6 rounded-lg mt-4 max-h-[45vh] overflow-y-auto">
                    <h4 className="font-bold mb-2">Тема: {pitch.subject}</h4>
                    <div
                      className="whitespace-pre-wrap leading-relaxed text-sm prose dark:prose-invert"
                    >
                      {pitch.body}
                    </div>
                  </div>
                   <div className="mt-4 flex justify-end">
                      <Button
                        onClick={() => handleCopy(`Тема: ${pitch.subject}\n\n${pitch.body}`)}
                        variant="default"
                        className="gap-2"
                      >
                        {copied ? (
                          <><CheckCircle2 className="w-4 h-4" />Скопировано!</>
                        ) : (
                          <><Copy className="w-4 h-4" />Копировать</>
                        )}
                      </Button>
                   </div>
                </TabsContent>
              ))}
            </Tabs>
          )}
        </div>

        <DialogFooter>
          <Button onClick={onClose} variant="outline" data-testid="button-close-modal">
            Закрыть
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}