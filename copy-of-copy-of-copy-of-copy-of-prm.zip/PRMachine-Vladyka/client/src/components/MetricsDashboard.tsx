import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Radar, Target, Telescope, CheckCircle, Brain, Rocket, PaperPlane, XCircle } from "lucide-react";

interface VladykaMetrics {
  totalOpportunities: number;
  byStatus: {
    scouted: number;
    verified: number;
    analyzing: number;
    attack_ready: number;
    sent: number;
    rejected: number;
  };
  avgScores: {
    alpha: number;
    bravo: number;
  };
}

interface MetricsDashboardProps {
  metrics: VladykaMetrics;
}

// Fix: Property 'colorClass' is missing. Made `colorClass` optional and handle undefined.
const StatusItem = ({ icon, label, value, colorClass, testId }: { icon: any, label: string, value: number, colorClass?: string, testId: string }) => (
  <div className="flex items-center justify-between">
    <span className={`text-sm text-muted-foreground flex items-center gap-2 ${colorClass || ''}`}>
      {icon} {label}
    </span>
    <span className="text-sm font-bold font-mono" data-testid={testId}>
      {value}
    </span>
  </div>
);

export function MetricsDashboard({ metrics }: MetricsDashboardProps) {
  return (
    <div className="h-full bg-card border-l border-border p-6 space-y-6 overflow-y-auto">
      <div className="space-y-2">
        <h2 className="text-lg font-bold text-foreground flex items-center gap-2">
          <Radar className="w-5 h-5 text-primary" />
          Протокол Владыка
        </h2>
        <p className="text-sm text-muted-foreground">
          Статус оперативной системы
        </p>
      </div>

      <Card className="bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm border border-primary/20">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Всего возможностей
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-bold font-mono text-foreground" data-testid="text-total-opportunities">
            {metrics.totalOpportunities}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
            <Target className="w-4 h-4" />
            Средние скоры
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">α (Разведка)</span>
              <span className="text-2xl font-bold text-blue-400 font-mono" data-testid="text-alpha-score">
                {metrics.avgScores.alpha}/100
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">β (Верификация)</span>
              <span className="text-2xl font-bold text-green-400 font-mono" data-testid="text-bravo-score">
                {metrics.avgScores.bravo}/100
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-card/50 to-card/30 backdrop-blur-sm">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Воронка
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <StatusItem icon={<Telescope />} label="Разведка" value={metrics.byStatus.scouted} testId="text-status-scouted" />
          <StatusItem icon={<CheckCircle />} label="Верификация" value={metrics.byStatus.verified} colorClass="text-blue-400" testId="text-status-verified" />
          <StatusItem icon={<Brain />} label="Анализ" value={metrics.byStatus.analyzing} colorClass="text-purple-400" testId="text-status-analyzing" />
          <StatusItem icon={<Rocket />} label="К атаке готовы" value={metrics.byStatus.attack_ready} colorClass="text-priority-high" testId="text-status-attack-ready" />
          <StatusItem icon={<PaperPlane />} label="Отправлено" value={metrics.byStatus.sent} colorClass="text-green-500" testId="text-status-sent" />
          <StatusItem icon={<XCircle />} label="Отклонено" value={metrics.byStatus.rejected} colorClass="text-destructive" testId="text-status-rejected" />
        </CardContent>
      </Card>
    </div>
  );
}