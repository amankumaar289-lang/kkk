import { pgTable, text, varchar, timestamp, uuid, integer, jsonb, boolean, pgEnum } from 'drizzle-orm/pg-core';
import { createInsertSchema, createSelectSchema } from 'drizzle-zod';
import { z } from 'zod';

// ============================================================================
// DATABASE SCHEMA (Drizzle ORM)
// ============================================================================

export const opportunityStatusEnum = pgEnum('opportunity_status', ['scouted', 'analyzing', 'verified', 'attack_ready', 'sent', 'rejected', 'error']);
export const priorityEnum = pgEnum('priority', ['low', 'medium', 'high']);
export const contactTypeEnum = pgEnum('contact_type', ['email', 'telegram', 'phone', 'website']);
export const speakerProfileEnum = pgEnum('speaker_profile', ['corporate', 'crypto']);

export const opportunities = pgTable('opportunities', {
  id: uuid('id').primaryKey().defaultRandom(),
  title: varchar('title', { length: 255 }).notNull(),
  description: text('description'),
  event_url: varchar('event_url', { length: 512 }).notNull().unique(),
  event_date: varchar('event_date', { length: 255 }),
  location: varchar('location', { length: 50 }).notNull(),
  category: varchar('category', { length: 100 }),
  status: opportunityStatusEnum('status').notNull().default('scouted'),
  priority: priorityEnum('priority').notNull().default('low'),
  alpha_score: integer('alpha_score'), // Initial search relevance
  bravo_score: integer('bravo_score'), // AI-based relevance
  ai_analysis: text('ai_analysis'),
  key_insights: jsonb('key_insights').$type<string[]>(),
  created_at: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  updated_at: timestamp('updated_at', { withTimezone: true }).defaultNow().notNull(),
});

export const contacts = pgTable('contacts', {
  id: uuid('id').primaryKey().defaultRandom(),
  opportunity_id: uuid('opportunity_id').references(() => opportunities.id, { onDelete: 'cascade' }).notNull(),
  type: contactTypeEnum('type').notNull(),
  value: varchar('value', { length: 255 }).notNull(),
  created_at: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});

export const pitchSchema = z.object({
  variant_name: z.string(),
  subject: z.string(),
  body: z.string(),
  mailto_link: z.string().optional(),
});

export type Pitch = z.infer<typeof pitchSchema>;

export const attacks = pgTable('attacks', {
  id: uuid('id').primaryKey().defaultRandom(),
  opportunity_id: uuid('opportunity_id').references(() => opportunities.id, { onDelete: 'cascade' }).notNull(),
  speaker_profile: speakerProfileEnum('speaker_profile').notNull(),
  generated_pitches: jsonb('generated_pitches').$type<Pitch[]>().notNull(),
  ai_recommendation: text('ai_recommendation'),
  user_chosen_pitch: jsonb('user_chosen_pitch').$type<Pitch>(),
  is_sent: boolean('is_sent').default(false).notNull(),
  response_received: boolean('response_received').default(false).notNull(),
  created_at: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
});


// ============================================================================
// ZOD SCHEMAS (for validation and type inference)
// ============================================================================

// SELECT schemas (for reading from DB)
export const OpportunitySchema = createSelectSchema(opportunities, {
    contacts: z.array(createSelectSchema(contacts)).optional(),
});
export const ContactSchema = createSelectSchema(contacts);
export const AttackSchema = createSelectSchema(attacks);

// INSERT schemas (for writing to DB)
export const InsertOpportunitySchema = createInsertSchema(opportunities);
export const InsertContactSchema = createInsertSchema(contacts);
export const InsertAttackSchema = createInsertSchema(attacks);

// API Schemas
export const searchRequestSchema = z.object({
  query: z.string(),
  location: z.string(),
  dateFrom: z.string().optional(),
  dateTo: z.string().optional(),
});
export type SearchRequest = z.infer<typeof searchRequestSchema>;

export const generatePitchesRequestSchema = z.object({
  opportunityId: z.string().uuid(),
  speakerProfile: z.enum(['corporate', 'crypto']),
});
export type GeneratePitchesRequest = z.infer<typeof generatePitchesRequestSchema>;

export const sendPitchRequestSchema = z.object({
  finalPitch: pitchSchema,
});
export type SendPitchRequest = z.infer<typeof sendPitchRequestSchema>;

// Shared Types
export type Opportunity = z.infer<typeof OpportunitySchema>;
export type Contact = z.infer<typeof ContactSchema>;
export type Attack = z.infer<typeof AttackSchema>;
export type InsertOpportunity = z.infer<typeof InsertOpportunitySchema>;
export type InsertContact = z.infer<typeof InsertContactSchema>;
export type InsertAttack = z.infer<typeof InsertAttackSchema>;

export type SpeakerProfileContent = {
  url: string;
  summary: string;
};

// Brave Search API Types (based on usage)
export interface BraveSearchResult {
    title: string;
    url: string;
    description?: string;
    [key: string]: any;
}

export interface BraveSearchResponse {
    web?: {
        results: BraveSearchResult[];
    };
    [key: string]: any;
}