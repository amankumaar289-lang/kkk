import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Header } from "@/components/Header";
import { ControlPanel } from "@/components/ControlPanel";
import { MetricsDashboard } from "@/components/MetricsDashboard";
import { EventCard } from "@/components/EventCard";
import { EmptyState, RadarSearching, ShimmerCards } from "@/components/LoadingState";
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable";
import { LetterPreviewModal } from "@/components/LetterPreviewModal";
import { apiRequest } from "@/lib/queryClient";
import type { Opportunity, Pitch } from "@shared/schema-vladyka";
import { useToast } from "@/hooks/use-toast";

interface SearchCriteria {
  query: string;
  location: string;
  dateFrom?: string;
  dateTo?: string;
}

export default function Home() {
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [isLetterModalOpen, setIsLetterModalOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: metrics } = useQuery({
    queryKey: ['/api/metrics'],
    refetchInterval: 5000, // Poll for metrics updates
  });

  const { data: opportunities, isLoading: isLoadingOpportunities, isFetching: isFetchingOpportunities } = useQuery<Opportunity[]>({
    queryKey: ['/api/opportunities'],
    initialData: [],
    refetchInterval: 5000, // Poll for opportunity updates
  });
  
  const searchMutation = useMutation({
    mutationFn: (criteria: SearchCriteria) => apiRequest('POST', '/api/search', criteria),
    onSuccess: () => {
      toast({
        title: "✅ Поиск запущен",
        description: "Протокол 'Разведка' активирован. Результаты будут появляться по мере обработки.",
      });
    },
    onError: (error) => {
       toast({
        variant: "destructive",
        title: "❌ Ошибка поиска",
        description: error.message || "Не удалось запустить поиск.",
      });
    },
  });

  const markAsSentMutation = useMutation({
      mutationFn: ({ attackId, finalPitch }: { attackId: string, finalPitch: Pitch }) => 
          apiRequest('PATCH', `/api/attacks/${attackId}/sent`, { finalPitch }),
      onSuccess: () => {
          toast({ title: '✅ Pitch Marked as Sent', description: 'Opportunity status updated.' });
          queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
          queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
          setIsLetterModalOpen(false);
      },
      onError: (error: Error) => {
          toast({ variant: 'destructive', title: '❌ Update Failed', description: error.message });
      }
  });

  const handleSearch = (criteria: SearchCriteria) => {
    searchMutation.mutate(criteria);
  };
  
  const handleGenerateLetter = (opportunity: Opportunity) => {
    setSelectedOpportunity(opportunity);
    setIsLetterModalOpen(true);
  };

  const renderContent = () => {
    if (isLoadingOpportunities && (!opportunities || opportunities.length === 0)) {
      return <ShimmerCards count={5} />;
    }
    
    if (isFetchingOpportunities && !searchMutation.isPending && (!opportunities || opportunities.length === 0)) {
         return <RadarSearching />;
    }
    
    if (searchMutation.isPending) {
        return <RadarSearching />;
    }

    if (!opportunities || opportunities.length === 0) {
      return <EmptyState />;
    }

    return (
      <div className="space-y-4">
        {opportunities.map((event) => (
          <EventCard key={event.id} event={event} onGenerateLetter={handleGenerateLetter} />
        ))}
      </div>
    );
  };

  const defaultMetrics = {
    totalOpportunities: 0,
    byStatus: { scouted: 0, verified: 0, analyzing: 0, attack_ready: 0, sent: 0, rejected: 0, error: 0 },
    avgScores: { alpha: 0, bravo: 0 },
    successRate: 0
  };

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      <Header 
        totalEvents={metrics?.totalOpportunities || 0}
        successRate={metrics?.successRate || 0}
      />
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal" className="h-full">
          <ResizablePanel defaultSize={20} minSize={15} maxSize={30}>
            <ControlPanel onSearch={handleSearch} isSearching={searchMutation.isPending} />
          </ResizablePanel>
          <ResizableHandle withHandle />
          <ResizablePanel defaultSize={55} minSize={40}>
            <main className="h-full overflow-y-auto p-6">
              {renderContent()}
            </main>
          </ResizablePanel>
          <ResizableHandle withHandle />
          <ResizablePanel defaultSize={25} minSize={20} maxSize={35}>
             <MetricsDashboard metrics={metrics || defaultMetrics} />
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>

      {selectedOpportunity && (
        <LetterPreviewModal
          opportunity={selectedOpportunity}
          isOpen={isLetterModalOpen}
          onOpenChange={setIsLetterModalOpen}
          onMarkAsSent={markAsSentMutation.mutate}
          isSending={markAsSentMutation.isPending}
        />
      )}
    </div>
  );
}