import { useState, useMemo, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Opportunity, Attack, Pitch } from '@shared/schema-vladyka';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Bot, Copy, Send, Loader2, Sparkles } from 'lucide-react';
import { Skeleton } from './ui/skeleton';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';

interface LetterPreviewModalProps {
  opportunity: Opportunity;
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  onMarkAsSent: (payload: { attackId: string; finalPitch: Pitch }) => void;
  isSending: boolean;
}

export function LetterPreviewModal({ opportunity, isOpen, onOpenChange, onMarkAsSent, isSending }: LetterPreviewModalProps) {
  const { toast } = useToast();
  const [speakerProfile, setSpeakerProfile] = useState<'corporate' | 'crypto'>('corporate');
  const [editedPitches, setEditedPitches] = useState<Record<string, Pitch>>({});

  const { data: attack, isLoading: isLoadingAttack, refetch } = useQuery<Attack | null>({
    queryKey: [`/api/opportunities/${opportunity.id}/attack`],
    enabled: isOpen,
  });

  const generateMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/attacks', { opportunityId: opportunity.id, speakerProfile }),
    onSuccess: () => {
      toast({ title: '✅ Pitches Generated', description: 'Strike variants are ready for deployment.' });
      refetch();
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
    },
    onError: (error: Error) => {
      toast({ variant: 'destructive', title: '❌ Generation Failed', description: error.message });
    },
  });
  
  const pitches = useMemo(() => attack?.generated_pitches || [], [attack]);

  useEffect(() => {
    if (isOpen && pitches.length > 0) {
      const initialEdits: Record<string, Pitch> = {};
      pitches.forEach(p => {
        initialEdits[p.variant_name] = { ...p };
      });
      setEditedPitches(initialEdits);
    } else {
      setEditedPitches({});
    }
  }, [isOpen, pitches]);

  const handlePitchChange = (variantName: string, field: 'subject' | 'body', value: string) => {
    setEditedPitches(prev => ({
      ...prev,
      [variantName]: {
        ...prev[variantName],
        [field]: value
      }
    }));
  };

  const handleCopyToClipboard = (pitch: Pitch) => {
    const text = `Subject: ${pitch.subject}\n\n${pitch.body}`;
    navigator.clipboard.writeText(text);
    toast({ title: '📋 Copied to clipboard' });
  };
  
  const handleMarkAsSent = (pitch: Pitch) => {
    if (!attack) return;
    onMarkAsSent({ attackId: attack.id, finalPitch: pitch });
  };

  const renderContent = () => {
    if (isLoadingAttack) {
      return (
        <div className="space-y-4">
          <Skeleton className="h-10 w-1/2" />
          <Skeleton className="h-40 w-full" />
        </div>
      );
    }

    if (generateMutation.isPending) {
        return (
            <div className="flex flex-col items-center justify-center space-y-4 py-8">
                <Loader2 className="w-12 h-12 animate-spin text-primary" />
                <p className="text-muted-foreground">Synthesizing strike variants...</p>
            </div>
        );
    }
    
    if (!attack || pitches.length === 0) {
      return (
        <div className="text-center py-8 space-y-4">
          <p className="text-muted-foreground">No attack plan generated yet.</p>
          <p>Select a speaker profile and initiate synthesis.</p>
        </div>
      );
    }
    
    const defaultTab = attack.ai_recommendation?.includes(pitches[0].variant_name) ? pitches[0].variant_name : (pitches[1] && attack.ai_recommendation?.includes(pitches[1].variant_name) ? pitches[1].variant_name : pitches[0].variant_name);

    return (
      <Tabs defaultValue={defaultTab} className="w-full">
        <TabsList className={`grid w-full grid-cols-${pitches.length}`}>
          {pitches.map((pitch) => (
            <TabsTrigger key={pitch.variant_name} value={pitch.variant_name} className="relative">
                {pitch.variant_name}
                {attack.ai_recommendation?.includes(pitch.variant_name) && <Sparkles className="w-3 h-3 text-yellow-400 absolute top-1 right-1" />}
            </TabsTrigger>
          ))}
        </TabsList>
        {attack.ai_recommendation && (
            <div className="mt-4 p-3 bg-blue-900/30 border border-blue-700 rounded-md text-sm flex items-start gap-3">
                <Bot className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                <p className="text-blue-200"><strong className="font-semibold text-blue-300">AI Recommendation:</strong> {attack.ai_recommendation}</p>
            </div>
        )}
        {pitches.map((pitch) => (
          <TabsContent key={pitch.variant_name} value={pitch.variant_name}>
            <Card className="bg-muted/50 mt-2">
              <CardContent className="space-y-4 pt-4">
                <div className='space-y-1.5'>
                    <Label htmlFor={`subject-${pitch.variant_name}`}>Subject</Label>
                    <Input id={`subject-${pitch.variant_name}`} value={editedPitches[pitch.variant_name]?.subject || ''} onChange={(e) => handlePitchChange(pitch.variant_name, 'subject', e.target.value)} />
                </div>
                <div className='space-y-1.5'>
                    <Label htmlFor={`body-${pitch.variant_name}`}>Body</Label>
                    <Textarea id={`body-${pitch.variant_name}`} value={editedPitches[pitch.variant_name]?.body || ''} onChange={(e) => handlePitchChange(pitch.variant_name, 'body', e.target.value)} className="h-48 font-mono text-xs" />
                </div>
                <div className="flex gap-2 justify-end">
                  <Button variant="outline" size="sm" onClick={() => handleCopyToClipboard(editedPitches[pitch.variant_name])}>
                    <Copy className="w-4 h-4 mr-2" /> Copy
                  </Button>
                  <a href={editedPitches[pitch.variant_name]?.mailto_link || '#'} target="_blank" rel="noopener noreferrer">
                    <Button size="sm">
                        <Send className="w-4 h-4 mr-2" /> Атаковать
                    </Button>
                  </a>
                  <Button size="sm" variant="secondary" onClick={() => handleMarkAsSent(editedPitches[pitch.variant_name])} disabled={isSending}>
                      {isSending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
                      Отметить как отправленное
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    );
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Синтез Атаки: {opportunity.title}</DialogTitle>
          <DialogDescription>
            Протокол "Точный Выстрел". Генерация и отправка персонализированных писем.
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 py-4 max-h-[70vh] overflow-y-auto pr-2">
            <div className="md:col-span-1 space-y-4">
                <Label>Профиль спикера</Label>
                <RadioGroup value={speakerProfile} onValueChange={(v) => setSpeakerProfile(v as 'corporate' | 'crypto')} className="space-y-2">
                    <div className="flex items-center space-x-2">
                        <RadioGroupItem value="corporate" id="r-corporate" />
                        <Label htmlFor="r-corporate">Corporate</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <RadioGroupItem value="crypto" id="r-crypto" />
                        <Label htmlFor="r-crypto">Crypto/Web3</Label>
                    </div>
                </RadioGroup>
                <Button onClick={() => generateMutation.mutate()} disabled={generateMutation.isPending} className="w-full">
                    {generateMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    {attack ? 'Перегенерировать' : 'Сгенерировать'}
                </Button>
            </div>
            <div className="md:col-span-3">
                {renderContent()}
            </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Закрыть</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}