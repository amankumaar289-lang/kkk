import * as React from "react";
import { Opportunity } from "@shared/schema-vladyka";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Award, Calendar, ExternalLink, MapPin, Bot, Rocket, Mail, Send as TelegramIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface EventCardProps {
  event: Opportunity;
  onGenerateLetter: (event: Opportunity) => void;
}

const priorityClasses = {
  high: "border-l-priority-high",
  medium: "border-l-priority-medium",
  low: "border-l-priority-low",
};

const statusColors: Record<string, string> = {
    scouted: "bg-gray-500",
    analyzing: "bg-blue-500 animate-pulse",
    verified: "bg-blue-600",
    attack_ready: "bg-priority-high",
    sent: "bg-green-600",
    rejected: "bg-destructive",
    error: "bg-destructive",
};


export function EventCard({ event, onGenerateLetter }: EventCardProps) {
  const canGenerateLetter = ['verified', 'attack_ready', 'sent'].includes(event.status);

  return (
    <Card className={cn("border-l-4 transition-all hover:shadow-lg", priorityClasses[event.priority as keyof typeof priorityClasses] || "border-l-muted")}>
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <CardTitle className="text-lg font-bold">
              <a href={event.event_url} target="_blank" rel="noopener noreferrer" className="hover:underline flex items-center gap-2">
                {event.title}
                <ExternalLink className="w-4 h-4 text-muted-foreground" />
              </a>
            </CardTitle>
            <CardDescription className="text-xs font-mono text-muted-foreground pt-1">
              ID: {event.id}
            </CardDescription>
          </div>
          <Tooltip>
            <TooltipTrigger>
                 <Badge variant="outline" className="flex items-center gap-1.5 cursor-default">
                    <div className={cn("w-2 h-2 rounded-full", statusColors[event.status] || "bg-gray-400")}></div>
                    {event.status}
                </Badge>
            </TooltipTrigger>
            <TooltipContent>
                <p>Status: {event.status}</p>
                <p>Priority: {event.priority}</p>
            </TooltipContent>
          </Tooltip>
        </div>
        <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap pt-2">
          {event.event_date && (
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4" />
              <span>{event.event_date}</span>
            </div>
          )}
          <div className="flex items-center gap-1.5">
            <MapPin className="w-4 h-4" />
            <span>{event.location}</span>
          </div>
           {event.category && event.category !== 'TBD' && <Badge variant="secondary">{event.category}</Badge>}
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-muted-foreground line-clamp-3">
          {event.description}
        </p>
        {event.ai_analysis && (
            <div className="mt-3 p-3 bg-muted/50 rounded-md text-sm">
                <p className="flex items-center gap-2 font-semibold text-foreground">
                    <Bot className="w-4 h-4 text-primary" />
                    AI Analysis (Bravo)
                </p>
                <p className="text-muted-foreground italic mt-1">"{event.ai_analysis}"</p>
            </div>
        )}
        {event.contacts && event.contacts.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {event.contacts.map(contact => (
              <Tooltip key={contact.id}>
                <TooltipTrigger asChild>
                  <a 
                    href={contact.type === 'email' ? `mailto:${contact.value}` : `https://t.me/${contact.value.replace('@', '')}`}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-2 py-1 text-xs bg-muted rounded-md hover:bg-muted/80"
                  >
                    {contact.type === 'email' ? <Mail className="w-3 h-3" /> : <TelegramIcon className="w-3 h-3" />}
                    <span>{contact.value}</span>
                  </a>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Contact ({contact.type})</p>
                </TooltipContent>
              </Tooltip>
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex items-center justify-between">
        <div className="flex items-center gap-4 text-sm font-mono">
            <Tooltip>
                <TooltipTrigger>
                    <div className="flex items-center gap-2">
                        <span className="text-blue-500 font-bold">Alpha:</span>
                        <span>{event.alpha_score ?? '-'}%</span>
                    </div>
                </TooltipTrigger>
                <TooltipContent>Alpha Score (Первичная разведка)</TooltipContent>
            </Tooltip>
            <Tooltip>
                <TooltipTrigger>
                    <div className="flex items-center gap-2">
                        <span className="text-green-500 font-bold">Bravo:</span>
                         <span>{event.bravo_score ?? '-'}%</span>
                    </div>
                </TooltipTrigger>
                <TooltipContent>Bravo Score (AI-Верификация)</TooltipContent>
            </Tooltip>
        </div>
        <Button
          onClick={() => onGenerateLetter(event)}
          disabled={!canGenerateLetter}
          size="sm"
        >
          <Rocket className="w-4 h-4 mr-2" />
          {event.status === 'sent' || event.status === 'attack_ready' ? 'Открыть письма' : 'Синтез Атаки'}
        </Button>
      </CardFooter>
    </Card>
  );
}