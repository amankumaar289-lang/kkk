import { type Express, Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import {
  executeReconnaissance,
  executeStrikeSynthesis,
  getAllOpportunities,
  getOpportunityById, // This was the problematic import
  getAttackByOpportunityId,
  getProtocolMetrics,
  handleFeedback, // This was the problematic import
  updateAttackStatus,
} from './lib/vladykaProtocol';
import { searchRequestSchema, generatePitchesRequestSchema, sendPitchRequestSchema } from '@shared/schema-vladyka';

// Helper for handling async routes
const asyncHandler = (fn: (req: Request, res: Response, next: NextFunction) => Promise<any>) =>
  (req: Request, res: Response, next: NextFunction) => {
    return Promise.resolve(fn(req, res, next)).catch(next);
  };

// Helper for validating request body
const validateBody = (schema: z.ZodSchema) => (req: Request, res: Response, next: NextFunction) => {
  try {
    req.body = schema.parse(req.body);
    next();
  } catch (error) {
    res.status(400).json(error);
  }
};

export function registerRoutes(app: Express) {
  // --- VLADYKA PROTOCOL API ---

  // GET /api/opportunities - Fetch all opportunities
  app.get('/api/opportunities', asyncHandler(async (req, res) => {
    const opportunities = await getAllOpportunities();
    res.json(opportunities);
  }));

  // GET /api/opportunities/:id - Fetch a single opportunity
  app.get('/api/opportunities/:id', asyncHandler(async (req, res) => {
    const opportunity = await getOpportunityById(req.params.id);
    if (!opportunity) {
      return res.status(404).json({ message: 'Opportunity not found' });
    }
    res.json(opportunity);
  }));
  
  // GET /api/opportunities/:id/attack - Fetch the latest attack for an opportunity
  app.get('/api/opportunities/:id/attack', asyncHandler(async (req, res) => {
    const attack = await getAttackByOpportunityId(req.params.id);
    res.json(attack || null);
  }));


  // POST /api/search - Start reconnaissance (Phase 1)
  app.post('/api/search', validateBody(searchRequestSchema), asyncHandler(async (req, res) => {
    // We don't wait for this to finish, it runs in the background
    executeReconnaissance(req.body);
    res.status(202).json({ message: 'Reconnaissance initiated. Results will appear as they are processed.' });
  }));

  // POST /api/attacks - Generate pitches (Phase 4)
  app.post('/api/attacks', validateBody(generatePitchesRequestSchema), asyncHandler(async (req, res) => {
    const attack = await executeStrikeSynthesis(req.body);
    res.status(201).json(attack);
  }));

  // PATCH /api/attacks/:id/sent - Mark an attack as sent
  app.patch('/api/attacks/:id/sent', validateBody(sendPitchRequestSchema), asyncHandler(async (req, res) => {
      const { id } = req.params;
      const { finalPitch } = req.body;
      const updatedAttack = await updateAttackStatus(id, finalPitch);
      res.json(updatedAttack);
  }));

  // POST /api/opportunities/:id/feedback - Provide feedback on an opportunity
  app.post('/api/opportunities/:id/feedback', asyncHandler(async (req, res) => {
    const { id } = req.params;
    const { isGoodFit } = req.body; // Expects a boolean
    if (typeof isGoodFit !== 'boolean') {
      return res.status(400).json({ message: 'isGoodFit must be a boolean' });
    }
    const [updatedOpportunity] = await handleFeedback(id, isGoodFit);
    res.json(updatedOpportunity);
  }));

  // GET /api/metrics - Get protocol metrics
  app.get('/api/metrics', asyncHandler(async (req, res) => {
    const metrics = await getProtocolMetrics();
    res.json(metrics);
  }));
}
