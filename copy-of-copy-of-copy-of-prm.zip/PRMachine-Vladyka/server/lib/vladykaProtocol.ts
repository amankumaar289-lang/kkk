import { db } from './db';
import { searchMultipleQueries, getPageContent } from './braveClient';
import { analyzeEventRelevance, generateAttackPitches, extractContacts, summarizeForDeepAnalysis, recommendBestPitches, GENERATION_MODEL } from './openrouterClient';
import { eq, desc, sql } from 'drizzle-orm';
import { 
    Opportunity, opportunities, contacts, attacks, SearchRequest, 
    generatePitchesRequestSchema, Pitch, InsertAttack, intel_assets, Attack 
} from '@shared/schema-vladyka';
import { z } from 'zod';

type StrikeSynthesisRequest = z.infer<typeof generatePitchesRequestSchema>;

// ============================================================================
// УТИЛИТЫ ДЛЯ ПРОТОКОЛА
// ============================================================================

function generateSearchQueries(query: string, location: string): string[] {
    const baseQueries = [
        `${query} ${location} выступление спикер`, `${query} ${location} конференция 2025`,
        `${query} ${location} митап выступить`, `${query} ${location} call for speakers`,
    ];
    if (location === 'Все') {
        return [
            ...baseQueries.map(q => q.replace('Все', 'Москва')),
            ...baseQueries.map(q => q.replace('Все', 'СПб')),
            ...baseQueries.map(q => q.replace('Все', 'Онлайн')),
        ].slice(0, 15);
    }
    return baseQueries;
}

function determineLocation(text: string): string {
    const lowerText = text.toLowerCase();
    if (lowerText.includes('москва') || lowerText.includes('moscow')) return 'МОСКВА';
    if (lowerText.includes('санкт-петербург') || lowerText.includes('питер') || lowerText.includes('спб')) return 'СПб';
    if (lowerText.includes('онлайн') || lowerText.includes('online') || lowerText.includes('remote')) return 'Онлайн';
    if (lowerText.includes('международ') || lowerText.includes('international')) return 'Международное';
    return 'Онлайн';
}

function determinePriority(location: string, score: number): 'high' | 'medium' | 'low' {
    if (location === 'МОСКВА' && score >= 70) return 'high';
    if (location === 'СПб' && score >= 65) return 'medium';
    if (score >= 80) return 'medium';
    if (score >= 50) return 'medium';
    return 'low';
}

function extractEventDate(description: string): string | null {
    const datePatterns = [
        /(\d{1,2})\s+(января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\s+(\d{4})/i,
        /(\d{1,2})\.(\d{1,2})\.(\d{4})/, /(\d{4})-(\d{2})-(\d{2})/,
    ];
    for (const pattern of datePatterns) {
        const match = description.match(pattern);
        if (match) return match[0];
    }
    return null;
}

function calculateAlphaScore(result: any): number {
    let score = 50;
    const text = (result.title + ' ' + (result.description || '')).toLowerCase();
    if (text.includes('speaker') || text.includes('спикер')) score += 15;
    if (text.includes('call for') || text.includes('заявки')) score += 15;
    if (result.description && result.description.length > 200) score += 5;
    return Math.min(100, score);
}


// ============================================================================
// ОСНОВНЫЕ ФАЗЫ ПРОТОКОЛА
// ============================================================================

/**
 * ПРОТОКОЛ "ГЛУБИННАЯ ЭСКАЛАЦИЯ"
 */
async function executeDeepEscalation(opportunityId: string, opportunityTitle: string) {
    console.log(`💥 [ESCALATION] Starting deep dive for high-priority target: ${opportunityTitle}`);
    const deepDiveQueries = [
        `${opportunityTitle} программа`,
        `${opportunityTitle} спикеры прошлых лет`,
        `${opportunityTitle} отзывы участников`,
        `${opportunityTitle} организаторы`,
        `кто выступал на ${opportunityTitle} 2024`,
    ];
    const searchResults = await searchMultipleQueries(deepDiveQueries);
    const contentToSummarize = searchResults.map(r => `URL: ${r.url}\nTitle: ${r.title}\nDescription: ${r.description}`).join('\n\n---\n\n');
    
    if(contentToSummarize) {
        const summary = await summarizeForDeepAnalysis(contentToSummarize);
        await db.update(opportunities)
            .set({ deep_analysis_report: summary })
            .where(eq(opportunities.id, opportunityId));
        console.log(`💥 [ESCALATION] Deep analysis report generated for ${opportunityId}`);
    }
}

/**
 * ФАЗА 2/3: Верификация и Анализ (Bravo/Charlie)
 */
async function executeVerificationAndAnalysis(opportunityId: string) {
    console.log(`🔎 [BRAVO/CHARLIE] Starting verification for opportunity: ${opportunityId}`);
    
    const [opportunity] = await db.select().from(opportunities).where(eq(opportunities.id, opportunityId));
    if (!opportunity) {
        console.error(`❌ [BRAVO] Opportunity ${opportunityId} not found for verification.`);
        return;
    }
    
    await db.update(opportunities).set({ status: 'analyzing', updated_at: new Date() }).where(eq(opportunities.id, opportunityId));
    
    const htmlContent = await getPageContent(opportunity.event_url);
    if (!htmlContent) console.warn(`⚠️ [BRAVO] Could not fetch page content for ${opportunity.event_url}`);
    
    const { emails, telegram } = await extractContacts(htmlContent);
    const contactsToInsert = [
        ...emails.map(value => ({ opportunity_id: opportunityId, type: 'email' as const, value })),
        ...telegram.map(value => ({ opportunity_id: opportunityId, type: 'telegram' as const, value }))
    ];

    if (contactsToInsert.length > 0) {
        await db.insert(contacts).values(contactsToInsert).onConflictDoNothing();
        console.log(`📞 [BRAVO] Extracted ${contactsToInsert.length} contacts for ${opportunityId}`);
    }

    const { score: bravo_score, pitch: ai_analysis, category } = await analyzeEventRelevance(opportunity.title, opportunity.description);

    const newStatus = bravo_score >= 40 ? 'verified' : 'rejected';
    await db.update(opportunities)
        .set({
            status: newStatus, bravo_score, ai_analysis, category,
            priority: determinePriority(opportunity.location, bravo_score),
            updated_at: new Date()
        })
        .where(eq(opportunities.id, opportunityId));
        
    console.log(`✅ [CHARLIE] Analysis complete for ${opportunityId}. Status: ${newStatus}, Score: ${bravo_score}`);

    // Trigger Deep Escalation if alpha score was high
    if (opportunity.alpha_score && opportunity.alpha_score > 85) {
        await executeDeepEscalation(opportunity.id, opportunity.title);
    }
}

/**
 * ФАЗА 1: Разведка (Alpha)
 */
export async function executeReconnaissance(request: SearchRequest): Promise<void> {
    console.log(`🔍 [ALPHA] Starting reconnaissance for: "${request.query}" in ${request.location}`);
    
    const searchQueries = generateSearchQueries(request.query, request.location);
    const searchResults = await searchMultipleQueries(searchQueries);
    console.log(`📊 [ALPHA] Found ${searchResults.length} raw results. Starting processing pipeline.`);

    for (const result of searchResults.slice(0, 20)) {
        try {
            const [existing] = await db.select().from(opportunities).where(eq(opportunities.event_url, result.url)).limit(1);
            if (existing) continue;

            const [opportunity] = await db.insert(opportunities).values({
                title: result.title,
                description: result.description || '',
                event_url: result.url,
                event_date: extractEventDate(result.description || ''),
                location: determineLocation(result.title + ' ' + (result.description || '')),
                category: 'TBD',
                status: 'scouted',
                alpha_score: calculateAlphaScore(result),
            }).returning();
            
            console.log(`✅ [ALPHA] Created opportunity: ${opportunity.title}. Triggering Bravo/Charlie phase.`);
            executeVerificationAndAnalysis(opportunity.id); // Run in background

        } catch (error) {
            console.error(`❌ [ALPHA] Error processing result for ${result.url}:`, error);
        }
    }
    console.log(`🏁 [ALPHA] Reconnaissance pipeline finished.`);
}

/**
 * ФАЗА 4: Синтез Атаки (Delta)
 */
export async function executeStrikeSynthesis(request: StrikeSynthesisRequest): Promise<Attack> {
    console.log(`🎯 [DELTA] Starting strike synthesis for opportunity: ${request.opportunityId}`);
    
    const [opportunity] = await db.query.opportunities.findMany({ where: eq(opportunities.id, request.opportunityId), with: { contacts: true } });
    if (!opportunity) throw new Error(`Opportunity ${request.opportunityId} not found`);

    const allAssets = await db.select().from(intel_assets).where(eq(intel_assets.is_active, true));
    const opportunityKeywords = `${opportunity.title} ${opportunity.description} ${opportunity.category}`.toLowerCase();
    const relevantAssets = allAssets.filter(asset => 
        asset.keywords?.some(kw => opportunityKeywords.includes(kw))
    ).slice(0, 5);
    console.log(`🛡️ [DELTA] Found ${relevantAssets.length} relevant assets from the Arsenal.`);

    const { pitches: generatedPitches } = await generateAttackPitches(opportunity, relevantAssets);
    if (!generatedPitches || generatedPitches.length === 0) throw new Error("AI failed to generate any pitches.");
    
    const { bestPitches, recommendation } = await recommendBestPitches(opportunity, generatedPitches);
    if (!bestPitches || bestPitches.length === 0) throw new Error("AI failed to recommend best pitches.");

    const finalPitches = bestPitches.map((pitch: Omit<Pitch, 'mailto_link'>) => {
        const to = opportunity.contacts.filter(c => c.type === 'email').map(c => c.value).join(',');
        const subject = encodeURIComponent(pitch.subject);
        const body = encodeURIComponent(pitch.body);
        return { ...pitch, mailto_link: `mailto:${to}?subject=${subject}&body=${body}` };
    });

    const [attack] = await db.insert(attacks).values({
        opportunity_id: request.opportunityId,
        generated_pitches: finalPitches,
        speaker_profile: request.speakerProfile,
        ai_recommendation: recommendation
    }).returning();
    
    await db.update(opportunities).set({ status: 'attack_ready', updated_at: new Date() }).where(eq(opportunities.id, request.opportunityId));
    
    console.log(`✅ [DELTA] Strike synthesis complete: ${finalPitches.length} pitches generated and recommended.`);
    return attack;
}

// ============================================================================
// УПРАВЛЕНИЕ ДАННЫМИ
// ============================================================================

export async function updateAttackStatus(attackId: string, finalPitch: Pitch) {
  const [updatedAttack] = await db.update(attacks)
    .set({ is_sent: true, user_chosen_pitch: finalPitch })
    .where(eq(attacks.id, attackId))
    .returning();

  if (updatedAttack && updatedAttack.opportunity_id) {
    await db.update(opportunities)
      .set({ status: 'sent', updated_at: new Date() })
      .where(eq(opportunities.id, updatedAttack.opportunity_id));
  }
  return updatedAttack;
}

// Fix: Add missing handleFeedback function
export async function handleFeedback(opportunityId: string, isGoodFit: boolean) {
    const newStatus = isGoodFit ? 'verified' : 'rejected';
    return db.update(opportunities)
        .set({ status: newStatus, updated_at: new Date() })
        .where(eq(opportunities.id, opportunityId))
        .returning();
}

export async function getAllOpportunities() {
    return db.query.opportunities.findMany({
        with: { contacts: true },
        orderBy: [desc(opportunities.created_at)],
    });
}

// Fix: Add missing getOpportunityById function
export async function getOpportunityById(id: string) {
    const [opportunity] = await db.query.opportunities.findMany({
        where: eq(opportunities.id, id),
        with: { contacts: true },
        limit: 1,
    });
    return opportunity;
}


export async function getAttackByOpportunityId(opportunityId: string) {
    const [attack] = await db.select().from(attacks).where(eq(attacks.opportunity_id, opportunityId)).orderBy(desc(attacks.created_at));
    return attack;
}

export async function getProtocolMetrics() {
    const allOpportunities = await db.select().from(opportunities);
    const byStatus = allOpportunities.reduce((acc, opp) => {
        acc[opp.status as Opportunity['status']] = (acc[opp.status as Opportunity['status']] || 0) + 1;
        return acc;
    }, {} as Record<Opportunity['status'], number>);

    const validAlpha = allOpportunities.filter(o => o.alpha_score != null);
    const avgAlpha = validAlpha.reduce((s, o) => s + o.alpha_score!, 0) / (validAlpha.length || 1);
    
    const validBravo = allOpportunities.filter(o => o.bravo_score != null);
    const avgBravo = validBravo.reduce((s, o) => s + o.bravo_score!, 0) / (validBravo.length || 1);
    
    const accepted = ['verified', 'attack_ready', 'sent'].reduce((sum, s) => sum + (byStatus[s as keyof typeof byStatus] || 0), 0);
    const processed = accepted + (byStatus.rejected || 0);
    const successRate = processed > 0 ? Math.round((accepted / processed) * 100) : 0;

    return {
        totalOpportunities: allOpportunities.length,
        byStatus: {
            scouted: byStatus.scouted || 0, verified: byStatus.verified || 0, analyzing: byStatus.analyzing || 0,
            attack_ready: byStatus.attack_ready || 0, sent: byStatus.sent || 0, rejected: byStatus.rejected || 0,
            error: byStatus.error || 0,
        },
        avgScores: { alpha: Math.round(avgAlpha), bravo: Math.round(avgBravo) },
        successRate: isNaN(successRate) ? 0 : successRate,
    };
}
