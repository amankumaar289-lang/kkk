import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from '@shared/schema-vladyka';

const connectionString = process.env.SUPABASE_DB_CONNECTION_STRING;

if (!connectionString) {
  throw new Error('SUPABASE_DB_CONNECTION_STRING is not set in environment variables. Please check your .env file.');
}

const client = postgres(connectionString, {
  max: 10,
  idle_timeout: 20,
  connect_timeout: 10,
  prepare: false,
});

export const db = drizzle(client, { schema });
