import { Opportunity, IntelAsset } from '@shared/schema-vladyka';

const OPENROUTER_API_KEY = "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";

const ANALYSIS_MODEL = 'deepseek/deepseek-r1-0528-qwen3-8b';
export const GENERATION_MODEL = 'anthropic/claude-3-haiku-20240307';


interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface ChatCompletionResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export async function chatCompletion(messages: ChatMessage[], model: string, useJsonFormat: boolean = true): Promise<string> {
  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
      'HTTP-Referer': 'https://pr-command-center.replit.app',
      'X-Title': 'PR Command Center',
    },
    body: JSON.stringify({
      model,
      messages,
      ...(useJsonFormat ? { response_format: { type: "json_object" } } : {}),
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`OpenRouter API error (${model}): ${response.status} ${response.statusText} - ${errorBody}`);
  }

  const data = await response.json() as ChatCompletionResponse;
  return data.choices[0]?.message?.content || '';
}

function safeJsonParse<T>(jsonString: string, fallback: T): T {
  try {
    const cleanJsonString = jsonString.replace(/^```json\s*|```$/g, '').trim();
    return JSON.parse(cleanJsonString);
  } catch (e) {
    console.error("Failed to parse JSON response from AI:", jsonString);
    return fallback;
  }
}

export async function analyzeEventRelevance(
  eventTitle: string,
  eventDescription: string | null,
): Promise<{ score: number; pitch: string; category: string }> {
  const prompt = `
Analyze the event for a speaking opportunity for an AI expert.
My criteria are:
- Priority 1 (High): Offline events in Moscow for business, sales, marketing audiences.
- Priority 2 (Medium): St. Petersburg events, international English-speaking events in Moscow.
- Priority 3 (Low): Online events, pure AI conferences (less desirable as they are full of competitors, not clients).
- Audience: Target decision-makers (CEOs, Heads of Sales) in companies with >$50k annual revenue.

EVENT:
Title: ${eventTitle}
Description: ${eventDescription || 'No description provided.'}

RESPONSE FORMAT (JSON ONLY):
{
  "score": <number from 0 to 100 based on my criteria>,
  "pitch": "<A 1-2 sentence compelling pitch showing the value my AI expertise brings to THIS specific event's audience>",
  "category": "<A short category like 'Business', 'Sales', 'Marketing', 'Tech', 'Crypto'>"
}
`;

  const response = await chatCompletion([
    { role: 'system', content: 'You are an expert event analyst. You must respond in JSON format.' },
    { role: 'user', content: prompt }
  ], ANALYSIS_MODEL);
  
  return safeJsonParse(response, { score: 0, pitch: "Could not analyze event.", category: "Uncategorized" });
}


export async function generateAttackPitches(
  opportunity: Opportunity,
  relevantAssets: IntelAsset[]
): Promise<any> {
    const assetsString = relevantAssets.map(asset => `- ${asset.name}: ${asset.content}`).join('\n');
    
    const brief = opportunity.deep_analysis_report || opportunity.description;

    const prompt = `
You are an AI assistant tasked with generating 5-7 distinct, personalized speaker application pitches for an event, using the provided context.

**EVENT BRIEF:**
${brief}

**SPEAKER'S RELEVANT ASSETS (ARSENAL):**
${assetsString}

**TASK:**
Generate 5-7 unique pitch variants. Each must be a JSON object with "variant_name", "subject", and "body".
The body must be highly tailored, referencing the event's themes and audience, and weaving in the most relevant assets from the arsenal provided.

**RESPONSE FORMAT (JSON ONLY):**
{
  "pitches": [
    { "variant_name": "Confident & Direct", "subject": "...", "body": "..." },
    { "variant_name": "Value-Oriented", "subject": "...", "body": "..." },
    { "variant_name": "Intriguing & Provocative", "subject": "...", "body": "..." },
    { "variant_name": "Academic & Expert", "subject": "...", "body": "..." },
    { "variant_name": "B2B Value Focus", "subject": "...", "body": "..." }
  ]
}
`;

    const response = await chatCompletion([
        { role: 'system', content: 'You are an expert PR assistant. Respond in JSON format ONLY.' },
        { role: 'user', content: prompt }
    ], GENERATION_MODEL);
    
    return safeJsonParse(response, { pitches: [] });
}

export async function recommendBestPitches(
  opportunity: Opportunity,
  pitches: any[]
): Promise<{ bestPitches: any[], recommendation: string }> {
  const pitchesString = JSON.stringify(pitches, null, 2);

  const prompt = `
Given the event details and a list of generated pitches, select the TOP 2-3 best pitches and provide a brief justification for your choice.

**EVENT DETAILS:**
- Title: ${opportunity.title}
- Description: ${opportunity.description}
- Category: ${opportunity.category}
- AI Analysis: ${opportunity.ai_analysis}

**GENERATED PITCHES:**
${pitchesString}

**TASK:**
1.  Identify the 2 or 3 strongest pitches from the list.
2.  Provide a concise recommendation explaining WHY these are the best choices for this specific event.

**RESPONSE FORMAT (JSON ONLY):**
{
  "bestPitches": [
    { "variant_name": "...", "subject": "...", "body": "..." },
    { "variant_name": "...", "subject": "...", "body": "..." }
  ],
  "recommendation": "The 'Confident & Direct' and 'Value-Oriented' variants are recommended because..."
}
`;
  const response = await chatCompletion([
    { role: 'system', content: 'You are a master PR strategist. Respond in JSON format ONLY.' },
    { role: 'user', content: prompt }
  ], GENERATION_MODEL);

  return safeJsonParse(response, { bestPitches: pitches.slice(0, 2), recommendation: "Default selection due to analysis error." });
}


export async function extractContacts(htmlContent: string): Promise<{
  emails: string[];
  telegram: string[];
}> {
  const prompt = `
Extract all unique email addresses and Telegram usernames from the following HTML content.

HTML:
\`\`\`html
${htmlContent.substring(0, 8000)}
\`\`\`

RESPONSE FORMAT (JSON ONLY):
{
  "emails": ["email1@example.com", "email2@example.com"],
  "telegram": ["@telegram_user1", "@telegram_user2"]
}
`;
  const response = await chatCompletion([
    { role: 'system', content: 'You are an expert data extractor. You must respond in JSON format.' },
    { role: 'user', content: prompt }
  ], ANALYSIS_MODEL);
  
  return safeJsonParse(response, { emails: [], telegram: [] });
}

export async function summarizeForDeepAnalysis(fullContent: string): Promise<string> {
    const prompt = `Summarize the following content into a concise brief of no more than 2000 tokens. Focus on the event's theme, target audience, key speakers, and organizer's goals. This will be used as context for a larger AI model.

    CONTENT:
    ${fullContent.substring(0, 15000)}
    `;

    return await chatCompletion([{ role: 'user', content: prompt }], ANALYSIS_MODEL, false);
}