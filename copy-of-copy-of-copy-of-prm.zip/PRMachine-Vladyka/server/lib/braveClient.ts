import { BraveSearchResult, BraveSearchResponse } from "@shared/schema-vladyka";

const BRAVE_API_KEYS = [
  process.env.BRAVE_API_KEY_1,
  process.env.BRAVE_API_KEY_2,
  process.env.BRAVE_API_KEY_3,
].filter(Boolean) as string[];

if (BRAVE_API_KEYS.length === 0) {
  console.warn("No Brave API keys found in environment variables. Search will not work.");
}

let currentKeyIndex = 0;
const requestQueue: { fn: () => Promise<any>; resolve: (value: any) => void; reject: (reason?: any) => void }[] = [];
let isProcessing = false;

function getNextApiKey(): string {
  if (BRAVE_API_KEYS.length === 0) {
    throw new Error("No Brave API keys are configured.");
  }
  const key = BRAVE_API_KEYS[currentKeyIndex];
  currentKeyIndex = (currentKeyIndex + 1) % BRAVE_API_KEYS.length;
  return key;
}

async function processQueue() {
  if (isProcessing || requestQueue.length === 0) {
    return;
  }
  isProcessing = true;

  const { fn, resolve, reject } = requestQueue.shift()!;
  
  try {
    const result = await fn();
    resolve(result);
  } catch (error) {
    reject(error);
  } finally {
    setTimeout(() => {
      isProcessing = false;
      processQueue();
    }, 1100); // 1 request per second + buffer
  }
}

function rateLimitedRequest<T>(fn: () => Promise<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    requestQueue.push({ fn, resolve, reject });
    processQueue();
  });
}

export async function searchBrave(query: string, retries = 3): Promise<BraveSearchResult[]> {
  const apiKey = getNextApiKey();
  
  const searchQuery = encodeURIComponent(query);
  const url = `https://api.search.brave.com/res/v1/web/search?q=${searchQuery}&count=20&text_decorations=false&extra_snippets=true`;

  try {
    const response = await rateLimitedRequest(async () => {
      console.log(`[BraveClient] Searching for: "${query}"`);
      const res = await fetch(url, {
        headers: {
          'Accept': 'application/json',
          'X-Subscription-Token': apiKey,
        },
      });
      
      if (!res.ok) {
        const errorText = await res.text();
        throw new Error(`Brave API error: ${res.status} ${res.statusText} - ${errorText}`);
      }
      
      return res.json();
    });
    
    const data = response as BraveSearchResponse;
    return data.web?.results || [];
  } catch (error) {
    if (retries > 0) {
      console.warn(`[BraveClient] Error searching, retrying... (${retries} attempts left). Error: ${error}`);
      await new Promise(resolve => setTimeout(resolve, 2000));
      return searchBrave(query, retries - 1);
    }
    throw error;
  }
}

export async function searchMultipleQueries(queries: string[]): Promise<BraveSearchResult[]> {
  const allResults: BraveSearchResult[] = [];
  const seenUrls = new Set<string>();

  for (const query of queries) {
    try {
      const results = await searchBrave(query);
      for (const result of results) {
        if (result.url && !seenUrls.has(result.url)) {
          seenUrls.add(result.url);
          allResults.push(result);
        }
      }
    } catch (error) {
      console.error(`[BraveClient] Failed to execute query "${query}":`, error);
    }
  }

  return allResults;
}

export async function getPageContent(url: string): Promise<string> {
    try {
        const response = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36' } });
        if (!response.ok) {
            return '';
        }
        return await response.text();
    } catch (error) {
        console.error(`[BraveClient] Failed to fetch page content for ${url}:`, error);
        return '';
    }
}
