# PR Command Center - Архитектура "Владыка"

## Обзор проекта

Автоматизированная система поиска, анализа и генерации заявок на выступления. Система построена на 4-фазном протоколе "Владыка", использует Brave Search API для разведки, AI-модель DeepSeek R1 для анализа и синтеза, и Supabase (PostgreSQL) для персистентного хранения данных через Drizzle ORM.

## Текущее состояние

**Статус:** ✅ **АРХИТЕКТУРА "ВЛАДЫКА" РАЗВЕРНУТА** - Все компоненты интегрированы и функционируют.

**Последние изменения:**
- ✅ **Миграция на Supabase:** Система полностью переведена с in-memory хранилища на PostgreSQL базу данных в Supabase.
- ✅ **Интеграция Drizzle ORM:** Создана строгая схема данных в `shared/schema-vladyka.ts` и инициализирован клиент `server/lib/db.ts`.
- ✅ **Реализация протокола "Владыка":** Все 4 фазы (Разведка, Верификация, Глубинный Анализ, Синтез Удара) реализованы в `server/lib/vladykaProtocol.ts`.
- ✅ **Интеграция "Арсенала":** Фаза "Синтез Удара" теперь динамически использует данные из таблицы `intel_assets` для создания релевантных писем.
- ✅ **Реализация "Точный Выстрел":** Бэкенд теперь генерирует готовые `mailto:` ссылки для каждого варианта письма.
- ✅ **Обновлен UI/UX:** Интерфейс адаптирован под новый 4-фазный рабочий процесс, включая новые статусы и скоринг.

## Архитектура системы

### Frontend (React + TypeScript + Tailwind)
- **Header:** Метрики в реальном времени.
- **ControlPanel:** Запуск Фазы 1 ("Разведка").
- **EventCard:** Отображение `opportunities` из БД, включая статусы `analyzing`, `attack_ready`. Кнопка "✅ Подходит" запускает Фазу 3 ("Глубинный Анализ").
- **LetterPreviewModal:** Запрашивает сгенерированные `attacks`, отображает 3 варианта писем и предоставляет готовые `mailto:` ссылки.
- **MetricsDashboard:** Статистика из БД.

### Backend (Express + TypeScript + Supabase)
- **База данных:** Supabase PostgreSQL, управляется через Drizzle ORM.
- **Brave Search API:** 4 API ключа с ротацией для Фазы 1 и Фазы 3.
- **OpenRouter API:** DeepSeek R1 для всех AI-операций.
- **Протокол "Владыка":** Основная бизнес-логика в `server/lib/vladykaProtocol.ts`.

### API Endpoints
- `POST /api/search-events` - Запускает Фазу 1 и 2: Разведка и Верификация.
- `POST /api/deep-analyze/:opportunityId` - Запускает Фазу 3: Глубинный Анализ.
- `POST /api/generate-pitches` - Запускает Фазу 4: Синтез Удара (если еще не выполнен).
- `GET /api/opportunities` - Получает все возможности из Supabase.
- `GET /api/attacks/:opportunityId` - Получает сгенерированную "атаку" для возможности.
- `GET /api/metrics` - Получает метрики из Supabase.
- `POST /api/feedback` - Обратная связь (только для "отклонено").
- `PUT /api/attacks/:attackId` - Обновляет статус отправки письма.

## Схема данных (Supabase/Drizzle)
- **`intel_assets`**: "Арсенал" - ваши темы, кейсы, регалии, партнерства.
- **`opportunities`**: Основная таблица с найденными мероприятиями и их статусами.
- **`contacts`**: Извлеченные контакты организаторов.
- **`attacks`**: Сгенерированные варианты писем (`mailto:` ссылки) для каждой атаки.

## Технический стек

### Frontend
- React 18, TypeScript, Vite
- Tailwind CSS (дизайн "Command Center")
- TanStack Query v5
- Wouter, Shadcn/ui, Framer Motion

### Backend
- Express.js, TypeScript
- Supabase (PostgreSQL)
- Drizzle ORM
- Brave Search API, OpenRouter API

### Важные файлы
- **`shared/schema-vladyka.ts`** - **Новая Drizzle-схема, единый источник правды.**
- **`server/lib/db.ts`** - **Новый Drizzle-клиент.**
- **`server/lib/vladykaProtocol.ts`** - **Новая основная бизнес-логика.**
- `server/routes.ts` - Обновленные API endpoints.
- `client/src/pages/Home.tsx` - Обновленный UI-workflow.
- **`server/storage.ts`** - **УДАЛЕН.**

## Переменные окружения (`.env`)

```env
# Supabase
SUPABASE_URL="https://nldzwfopogknvjjhtuns.supabase.co"
SUPABASE_ANON_KEY="eyJhbGciOiJIUz..."
SUPABASE_DB_CONNECTION_STRING="postgres://postgres.nldzwfopogknvjjhtuns:[YOUR_PASSWORD]@aws-0-eu-central-1.pooler.supabase.com:6543/postgres"

# Brave Search API (4 ключа)
BRAVE_API_KEY_1="BSAiH1vhLfsKM_unpLEPqIulBOwnDgt"
BRAVE_API_KEY_2="BSA-qCbl-osY1wjC2lW4PsIjx0Qt1IN"
BRAVE_API_KEY_3="BSArBFB2NMjeC8WUZ_Mlif9CwSyjw_2"
BRAVE_API_KEY_4="(резервный)"

# OpenRouter API
OPENROUTER_API_KEY="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"
```

## Workflow "Владыка"

1.  **Запуск:** Пользователь нажимает "Запустить поиск".
2.  **Фаза 1+2 (Автоматически):** Бэкенд ищет события, верифицирует, оценивает (`alpha`/`bravo` score) и сохраняет в `opportunities` со статусом `verified`.
3.  **Принятие решения:** Пользователь видит карточки. Нажимает "✅ Подходит".
4.  **Фаза 3 (Автоматически):** Бэкенд запускает "Глубинный Анализ", обновляет статус на `analyzing`, проводит доп. поиск, генерирует `DeepAnalysisReport` и обновляет статус на `attack_ready`.
5.  **Атака:** Пользователь нажимает "Открыть письма" на карточке со статусом `attack_ready`.
6.  **Фаза 4 (По запросу):** Бэкенд запускает "Синтез Удара", используя "Арсенал" и отчет, генерирует 3 варианта писем и `mailto:` ссылки, сохраняет в `attacks`.
7.  **Действие:** Модальное окно показывает 3 варианта. Пользователь выбирает, редактирует (опционально) и нажимает кнопку-ссылку `mailto:`.
8.  **Обратная связь:** Система регистрирует отправку и обновляет статус `opportunity` на `sent`.
