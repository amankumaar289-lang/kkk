import type { Express, Request, Response } from 'express';
import { db, tables } from './lib/db';
import { generateSearchQueries, determineLocation, determinePriority, extractEventDate } from './lib/tdrProtocol';
import { searchMultipleQueries } from './lib/braveClient';
import { analyzeEventRelevance, summarizeContent, generatePitchesFromReport, extractContacts } from './lib/openrouterClient';
import { desc, eq, and, sql, isNull, not } from 'drizzle-orm';
import { searchRequestSchema, Metrics } from '@shared/schema-vladyka';

async function runAsync(fn: () => Promise<any>) {
  try {
    await fn();
  } catch (error) {
    console.error('Error in async background task:', error);
  }
}

export function registerRoutes(app: Express) {
  // GET /api/opportunities - Fetch all opportunities
  app.get('/api/opportunities', async (_req: Request, res: Response) => {
    const opportunities = await db.query.opportunities.findMany({
      orderBy: [
        sql`
          CASE status
            WHEN 'attack_ready' THEN 1
            WHEN 'verified' THEN 2
            WHEN 'scouted' THEN 3
            WHEN 'analyzing' THEN 4
            ELSE 5
          END
        `,
        sql`
          CASE priority
            WHEN 'high' THEN 1
            WHEN 'medium' THEN 2
            WHEN 'low' THEN 3
          END
        `,
        desc(tables.opportunities.scouted_at),
      ],
      where: and(
        not(eq(tables.opportunities.status, 'rejected')),
        not(eq(tables.opportunities.status, 'sent'))
      )
    });
    res.json(opportunities);
  });

  // GET /api/metrics - Get system metrics
  app.get('/api/metrics', async (_req: Request, res: Response) => {
    const totalOpportunitiesResult = await db.select({ count: sql<number>`count(*)` }).from(tables.opportunities);
    const totalOpportunities = Number(totalOpportunitiesResult[0].count);
    
    const statusCounts = await db
      .select({
        status: tables.opportunities.status,
        count: sql<number>`count(*)`,
      })
      .from(tables.opportunities)
      .groupBy(tables.opportunities.status);

    const byStatus: Metrics['byStatus'] = {
      scouted: 0, verified: 0, analyzing: 0, attack_ready: 0, sent: 0, rejected: 0, accepted: 0
    };
    statusCounts.forEach(row => {
      if (row.status in byStatus) {
        byStatus[row.status as keyof typeof byStatus] = Number(row.count);
      }
    });

    const acceptedCount = byStatus.accepted;
    const sentCount = byStatus.sent;
    const successRate = sentCount > 0 ? (acceptedCount / sentCount) * 100 : 0;
    
    const avgScoresResult = await db.select({
        alpha: sql<number>`avg(${tables.opportunities.alpha_score})`,
        bravo: sql<number>`avg(${tables.opportunities.bravo_score})`
    }).from(tables.opportunities).where(not(isNull(tables.opportunities.alpha_score)));

    const metrics: Metrics = {
        totalOpportunities,
        byStatus,
        avgScores: {
            alpha: avgScoresResult[0]?.alpha || 0,
            bravo: avgScoresResult[0]?.bravo || 0,
        },
        successRate,
    };

    res.json(metrics);
  });

  // POST /api/search-events - Kick off a new search
  app.post('/api/search-events', (req: Request, res: Response) => {
    const validation = searchRequestSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ error: 'Invalid search criteria', details: validation.error.issues });
    }

    const { query, location } = validation.data;

    runAsync(async () => {
      const searchQueries = generateSearchQueries(query, location);
      const searchResults = await searchMultipleQueries(searchQueries);

      for (const result of searchResults) {
        if (!result.url) continue;
        
        const existing = await db.query.opportunities.findFirst({
          where: eq(tables.opportunities.event_url, result.url),
        });
        if (existing) continue;

        const combinedText = `${result.title} ${result.description} ${result.extra_snippets?.join(' ')}`;
        const resultLocation = determineLocation(combinedText);
        
        if (location !== 'Все' && location !== resultLocation) {
          continue;
        }

        const { score, pitch, category } = await analyzeEventRelevance(result.title, result.description, resultLocation);
        
        if (score.alpha < 40 || score.bravo < 40) continue;

        const priority = determinePriority(resultLocation, (score.alpha + score.bravo) / 2);
        const eventDate = extractEventDate(combinedText);
        
        await db.insert(tables.opportunities).values({
          title: result.title,
          description: result.description,
          event_url: result.url,
          event_date: eventDate,
          location: resultLocation,
          category: category,
          status: 'verified',
          alpha_score: score.alpha,
          bravo_score: score.bravo,
          priority: priority,
          ai_analysis: pitch,
        }).onConflictDoNothing();
      }
    });

    res.status(202).json({ message: 'Search initiated.' });
  });

  // POST /api/deep-analyze/:id - Run deep analysis on an opportunity
  app.post('/api/deep-analyze/:id', async (req: Request, res: Response) => {
    const { id } = req.params;
    await db.update(tables.opportunities).set({ status: 'analyzing' }).where(eq(tables.opportunities.id, id));
    
    runAsync(async () => {
        const opportunity = await db.query.opportunities.findFirst({ where: eq(tables.opportunities.id, id) });
        if (!opportunity || !opportunity.event_url) return;
        
        const response = await fetch(opportunity.event_url);
        const html = await response.text();

        const report = await summarizeContent(html, opportunity.title);
        const contacts = await extractContacts(html);
        
        await db.update(tables.opportunities)
          .set({ deep_analysis_report: { report } as any, status: 'attack_ready' })
          .where(eq(tables.opportunities.id, id));

        for(const email of contacts.emails) {
            if (email) {
                await db.insert(tables.contacts).values({
                    opportunity_id: id,
                    email
                }).onConflictDoNothing();
            }
        }
    });
    
    res.status(202).json({ message: 'Deep analysis initiated.' });
  });

  // POST /api/feedback - Mark an opportunity as rejected
  app.post('/api/feedback', async (req: Request, res: Response) => {
    const { opportunityId, isGoodFit } = req.body;
    if (isGoodFit === false) {
      await db.update(tables.opportunities)
        .set({ status: 'rejected' })
        .where(eq(tables.opportunities.id, opportunityId));
      return res.status(200).json({ message: 'Feedback recorded' });
    }
    return res.status(400).json({ message: 'Only rejection is handled here.'});
  });

  // GET /api/attacks/:id - Get attack data for an opportunity
  app.get('/api/attacks/:id', async (req: Request, res: Response) => {
    const { id } = req.params;
    const attack = await db.query.attacks.findFirst({
        where: eq(tables.attacks.opportunity_id, id),
        orderBy: [desc(tables.attacks.created_at)],
    });
    res.json(attack);
  });

  // POST /api/generate-pitches - Generate pitches for an attack
  app.post('/api/generate-pitches', async (req: Request, res: Response) => {
    const { opportunityId, speakerProfile } = req.body;
    
    const opportunity = await db.query.opportunities.findFirst({ where: eq(tables.opportunities.id, opportunityId) });
    if (!opportunity?.deep_analysis_report) {
        return res.status(404).json({ message: 'Opportunity or its deep analysis not found.' });
    }
    
    const report = (opportunity.deep_analysis_report as any)?.report || '';
    const arsenal = await db.query.intel_assets.findMany({ where: eq(tables.intel_assets.is_active, true) });
    const contacts = await db.query.contacts.findMany({ where: eq(tables.contacts.opportunity_id, opportunityId) });
    const primaryEmail = contacts.find(c => c.email)?.email;

    let pitches = await generatePitchesFromReport(opportunity.title, report, speakerProfile, arsenal);

    if (primaryEmail) {
        pitches = pitches.map(p => ({
            ...p,
            mailto_link: `mailto:${primaryEmail}?subject=${encodeURIComponent(p.subject)}&body=${encodeURIComponent(p.body)}`
        }));
    } else {
        pitches = pitches.map(p => ({
            ...p,
            mailto_link: '#'
        }));
    }
    
    const [newAttack] = await db.insert(tables.attacks).values({
        opportunity_id: opportunityId,
        generated_pitches: pitches as any,
        speaker_profile: speakerProfile,
    }).returning();
    
    res.status(201).json(newAttack);
  });

  // PUT /api/attacks/:id - Mark an attack as sent
  app.put('/api/attacks/:id', async (req: Request, res: Response) => {
    const { id } = req.params;
    const { chosenVariant, chosenPitch } = req.body;

    const attack = await db.query.attacks.findFirst({ where: eq(tables.attacks.id, id) });
    if (!attack) {
        return res.status(404).json({ message: 'Attack not found' });
    }
    
    await db.update(tables.attacks)
        .set({
            is_sent: true,
            sent_at: new Date(),
            user_chosen_pitch: chosenPitch,
            user_chosen_variant: chosenVariant,
        })
        .where(eq(tables.attacks.id, id));
    
    await db.update(tables.opportunities)
        .set({ status: 'sent' })
        .where(eq(tables.opportunities.id, attack.opportunity_id));
        
    res.status(200).json({ message: 'Attack marked as sent' });
  });
}
