export function generateSearchQueries(userQuery: string, location: string): string[] {
  const locationQueries: Record<string, string[]> = {
    'МОСКВА': ['москва', 'moscow', 'мск'],
    'СПб': ['санкт-петербург', 'петербург', 'спб', 'saint petersburg'],
    'Онлайн': ['онлайн', 'online', 'вебинар', 'webinar'],
    'Международное': ['international', 'conference', 'summit'],
    'Все': []
  };

  const baseKeywords = [
    'конференция',
    'форум', 
    'саммит',
    'meetup',
    'conference',
    'summit',
    'event'
  ];

  const thematicKeywords = [
    'бизнес',
    'продажи',
    'маркетинг',
    'AI',
    'технологии',
    'digital',
    'автоматизация',
    'innovation',
    'business',
    'sales',
    'marketing'
  ];

  const queries: string[] = [];
  const locationTerms = locationQueries[location] || [];

  if (userQuery) {
    queries.push(userQuery);
  }

  for (const baseKw of baseKeywords.slice(0, 3)) {
    for (const themeKw of thematicKeywords.slice(0, 4)) {
      if (locationTerms.length > 0) {
        for (const loc of locationTerms.slice(0, 2)) {
          queries.push(`${baseKw} ${themeKw} ${loc}`);
        }
      } else {
        queries.push(`${baseKw} ${themeKw}`);
      }
    }
  }

  const dateQueries = [
    new Date().getFullYear().toString(),
    `${new Date().getFullYear()} ${new Date().getFullYear() + 1}`,
  ];

  for (const dateQuery of dateQueries) {
    queries.push(`конференция ${dateQuery}`);
    if (locationTerms.length > 0) {
      queries.push(`конференция ${locationTerms[0]} ${dateQuery}`);
    }
  }

  return queries.slice(0, 15);
}

export function determineLocation(text: string): string {
  const lowerText = text.toLowerCase();
  
  if (lowerText.includes('москв') || lowerText.includes('moscow') || lowerText.includes('мск')) {
    return 'МОСКВА';
  }
  if (lowerText.includes('петербург') || lowerText.includes('спб') || lowerText.includes('saint petersburg')) {
    return 'СПб';
  }
  if (lowerText.includes('онлайн') || lowerText.includes('online') || lowerText.includes('вебинар') || lowerText.includes('webinar')) {
    return 'Онлайн';
  }
  if (lowerText.includes('international') || lowerText.includes('global') || lowerText.includes('world')) {
    return 'Международное';
  }
  
  return 'Онлайн';
}

export function determinePriority(location: string, score: number): 'high' | 'medium' | 'low' {
  if (location === 'МОСКВА' && score >= 70) return 'high';
  if (location === 'МОСКВА' && score >= 50) return 'medium';
  if (location === 'СПб' && score >= 70) return 'medium';
  if (location === 'Международное' && score >= 80) return 'medium';
  if (score >= 60) return 'medium';
  return 'low';
}

export function extractEventDate(text: string): string | undefined {
  const datePatterns = [
    /(\d{1,2})\s+(января|февраля|марта|апреля|мая|июня|июля|августа|сентября|октября|ноября|декабря)\s+(\d{4})/i,
    /(\d{1,2})\.(\d{1,2})\.(\d{4})/,
    /(\d{4})-(\d{1,2})-(\d{1,2})/,
  ];

  for (const pattern of datePatterns) {
    const match = text.match(pattern);
    if (match) {
      return match[0];
    }
  }

  return undefined;
}

export function categorizeEvent(title: string, description: string): string {
  const text = `${title} ${description}`.toLowerCase();
  
  const categories: Record<string, string[]> = {
    'AI/Технологии': ['ai', 'искусственный интеллект', 'машинное обучение', 'ml', 'технологии'],
    'Продажи': ['продажи', 'sales', 'crm', 'b2b'],
    'Маркетинг': ['маркетинг', 'marketing', 'digital', 'smm'],
    'Бизнес': ['бизнес', 'business', 'предпринимательство', 'стартап'],
    'HR/Управление': ['hr', 'управление', 'менеджмент', 'лидерство'],
    'Финансы': ['финансы', 'инвестиции', 'блокчейн', 'крипто'],
  };

  for (const [category, keywords] of Object.entries(categories)) {
    for (const keyword of keywords) {
      if (text.includes(keyword)) {
        return category;
      }
    }
  }

  return 'Другое';
}
