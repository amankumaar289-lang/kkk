import { IntelAsset, Pitch } from "@shared/schema-vladyka";

const OPENROUTER_API_KEY = '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';

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface ChatCompletionResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export async function chatCompletion(messages: ChatMessage[]): Promise<string> {
  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
      'HTTP-Referer': 'https://pr-command-center.replit.app',
      'X-Title': 'PR Command Center',
    },
    body: JSON.stringify({
      model: 'deepseek/deepseek-r1-0528-qwen3-8b',
      messages,
    }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`OpenRouter API error: ${response.status} ${response.statusText} - ${errorBody}`);
  }

  const data = await response.json() as ChatCompletionResponse;
  return data.choices[0]?.message?.content || '';
}

export async function analyzeEventRelevance(
  eventTitle: string,
  eventDescription: string,
  location: string
): Promise<{ score: { alpha: number; bravo: number }; pitch: string; category: string }> {
  const prompt = `Проанализируй мероприятие для спикера-эксперта по AI. Оцени два параметра: Alpha (Релевантность) и Bravo (Ценность аудитории).

МЕРОПРИЯТИЕ:
Название: ${eventTitle}
Описание: ${eventDescription}
Локация: ${location}

КРИТЕРИИ ОЦЕНКИ:
1. Alpha Score (Релевантность для спикера, макс 100):
   - Тематика (60%): НЕ AI конференции (продажи, маркетинг, бизнес) - высокий балл. AI конференции - низкий балл.
   - Локация (40%): МОСКВА офлайн - высший приоритет. СПб с оплатой - средний. Онлайн - ниже. Международные - высокий, если тема подходит.

2. Bravo Score (Ценность аудитории, макс 100):
   - Аудитория (70%): Бизнес, CEO, отделы продаж - высокий балл. IT-специалисты - средний.
   - Формат (30%): Бизнес-конференция, форум - высокий балл. Узкоспециализированный митап - ниже.

ВЕРНИ ТОЛЬКО JSON:
{
  "score": {
    "alpha": 85,
    "bravo": 90
  },
  "pitch": "Краткое предложение ценности для организаторов (1-2 предложения, почему спикер ИДЕАЛЕН для них)",
  "category": "Категория мероприятия (например, 'Бизнес', 'Технологии', 'Маркетинг')"
}`;

  const response = await chatCompletion([
    { role: 'user', content: prompt }
  ]);

  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return {
        score: {
          alpha: Math.min(100, Math.max(0, parsed.score?.alpha || 0)),
          bravo: Math.min(100, Math.max(0, parsed.score?.bravo || 0)),
        },
        pitch: parsed.pitch || '',
        category: parsed.category || 'Другое'
      };
    }
  } catch (e) {
    console.error('Failed to parse AI response:', e, 'Response was:', response);
  }

  return { score: { alpha: 50, bravo: 50 }, pitch: '', category: 'Другое' };
}

export async function summarizeContent(content: string, eventTitle: string): Promise<string> {
  const prompt = `Проанализируй следующий контент, собранный о мероприятии "${eventTitle}", и составь концентрированный отчет (deep analysis report) объемом до 5000 токенов.

  СЫРЫЕ ДАННЫЕ:
  ---
  ${content.slice(0, 15000)}
  ---

  ЗАДАЧА:
  Создай структурированный отчет в формате Markdown.
  1. **Ключевая информация:** Основные темы, целевая аудитория, ключевые спикеры, спонсоры, формат.
  2. **"Боли" и интересы аудитории:** Что волнует этих людей? Какие проблемы они пытаются решить?
  3. **"Точки входа" для спикера по AI:** Какие темы из его арсенала будут наиболее релевантны? Какие кейсы "выстрелят"?
  4. **Tone of Voice:** Какой стиль общения у организаторов? (формальный, дерзкий, инновационный).
  5. **Ключевые выводы:** 2-3 главных инсайта для подготовки ультимативного питча.

  ОТЧЕТ ДОЛЖЕН БЫТЬ СТРУКТУРИРОВАННЫМ И МАКСИМАЛЬНО ИНФОРМАТИВНЫМ.
  `;
  const response = await chatCompletion([
    { role: 'user', content: prompt }
  ]);
  return response.trim();
}

export async function generatePitchesFromReport(
  eventTitle: string,
  deepAnalysisReport: string,
  speakerProfile: 'corporate' | 'crypto',
  arsenal: IntelAsset[]
): Promise<Omit<Pitch, 'mailto_link'>[]> {
  const profileData = speakerProfile === 'corporate'
    ? `Спикерское досье: Корпоративное. Фокус на B2B, Enterprise, GovTech. Ссылка: https://speaker-zakhar-kondratev.replit.app/`
    : `Спикерское досье: Крипто/Креатив. Фокус на Web3, DeFAI, AI-продакшн. Ссылка: http://the-trends-zakhar-kondratev.replit.app/`;

  const arsenalString = arsenal.map(asset => `- ${asset.asset_type}: ${asset.name} (ключевые слова: ${asset.keywords?.join(', ')})`).join('\n');

  const prompt = `Ты — AI-продюсер Захар Кондратьев. Твоя задача — сгенерировать 3 "гениальные" версии письма для подачи заявки на выступление.

  КОНТЕКСТ:
  Мероприятие: ${eventTitle}
  Профиль спикера для этой атаки: ${profileData}
  
  Ультимативный отчет о мероприятии (Deep Analysis Report):
  ---
  ${deepAnalysisReport}
  ---

  Доступный "Арсенал" (активы спикера):
  ---
  ${arsenalString}
  ---
  
  ЗАДАЧА:
  На основе отчета и арсенала, сгенерируй 3 РАЗНЫХ варианта питча. Каждый вариант должен иметь тему (subject) и текст (body).
  
  ВАРИАНТЫ:
  1. "Дерзкий и Провокационный": Брось вызов, покажи, что их текущая повестка устарела. Используй цитаты из манифеста.
  2. "Академический и Экспертный": Сделай акцент на опыте с гос. структурами (Росатом, Суд), ВШЭ, глобальном диалоге (OpenAI).
  3. "B2B-ценность": Фокус на ROI, увеличении продаж, экономии. Используй кейсы с конкретными результатами (тендеры, ТВ-ролики).

  ТРЕБОВАНИЯ К КАЖДОМУ ПИСЬМУ:
  - Максимальная персонализация под мероприятие (используй инсайты из отчета).
  - Выбери 1-2 САМЫЕ РЕЛЕВАНТНЫЕ темы из арсенала для предложения.
  - Длина тела письма: 150-250 слов.
  - В конце каждого письма добавь ссылки на спикерское досье и видео выступления.

  ВЕРНИ ТОЛЬКО JSON в формате массива объектов:
  [
    {
      "variant_name": "Дерзкий",
      "subject": "Тема письма 1",
      "body": "Текст письма 1..."
    },
    {
      "variant_name": "Академический",
      "subject": "Тема письма 2",
      "body": "Текст письма 2..."
    },
    {
      "variant_name": "B2B-Ценность",
      "subject": "Тема письма 3",
      "body": "Текст письма 3..."
    }
  ]
  `;

  const response = await chatCompletion([
    { role: 'user', content: prompt }
  ]);
  
  try {
    const jsonMatch = response.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed to parse pitches response:', e, 'Response was:', response);
  }
  
  // Fallback
  return [
    { variant_name: 'Fallback', subject: `Выступление на ${eventTitle}`, body: `Генерация не удалась. Отчет: ${deepAnalysisReport}` }
  ];
}


export async function extractContacts(htmlContent: string): Promise<{
  emails: string[];
  telegram: string[];
  phones: string[];
}> {
  // Более "жадный" и менее строгий regex для email
  const emailRegex = /[\w\-._+]+@[\w\-._]+\.[a-zA-Z]{2,}/g;
  
  const telegramRegex = /t\.me\/[a-zA-Z0-9_]{5,}|@[a-zA-Z0-9_]{5,}/g;
  const phoneRegex = /(?:\+?7|8)?[-\s(]*\d{3}[)-\s]*\d{3}[-\s]*\d{2}[-\s]*\d{2}/g;

  const emails = Array.from(new Set(htmlContent.match(emailRegex) || []))
    .filter(email => !email.endsWith('.png') && !email.endsWith('.svg'));
    
  const telegram = Array.from(new Set(htmlContent.match(telegramRegex) || []));
  const phones = Array.from(new Set(htmlContent.match(phoneRegex) || []));

  return { emails, telegram, phones };
}