import { db, tables } from './db';
import { generateSearchQueries, determineLocation, determinePriority, extractEventDate } from './tdrProtocol';
import { searchMultipleQueries } from './braveClient';
import { analyzeEventRelevance, summarizeContent, generatePitchesFromReport, extractContacts } from './openrouterClient';
import { desc, eq, and, sql, isNull, not } from 'drizzle-orm';
import type { Opportunity, IntelAsset, Pitch, Metrics } from '@shared/schema-vladyka';

// ============================================================================
// ФАЗА 1 & 2: РАЗВЕДКА И ВЕРИФИКАЦИЯ
// ============================================================================
export async function executeReconnaissance(query: string, location: string): Promise<void> {
  const searchQueries = generateSearchQueries(query, location);
  const searchResults = await searchMultipleQueries(searchQueries);

  for (const result of searchResults) {
    if (!result.url) continue;

    const existing = await db.query.opportunities.findFirst({
      where: eq(tables.opportunities.event_url, result.url),
    });
    if (existing) continue;

    const combinedText = `${result.title} ${result.description} ${result.extra_snippets?.join(' ')}`;
    const resultLocation = determineLocation(combinedText);
    
    if (location !== 'Все' && location !== resultLocation) {
      continue;
    }

    const { score, pitch, category } = await analyzeEventRelevance(result.title, result.description, resultLocation);
    
    if (score.alpha < 40 || score.bravo < 40) continue;

    const priority = determinePriority(resultLocation, (score.alpha + score.bravo) / 2);
    const eventDate = extractEventDate(combinedText);
    
    await db.insert(tables.opportunities).values({
      title: result.title,
      description: result.description,
      event_url: result.url,
      event_date: eventDate,
      location: resultLocation,
      category: category,
      status: 'verified',
      alpha_score: score.alpha,
      bravo_score: score.bravo,
      priority: priority,
      ai_analysis: pitch,
    }).onConflictDoNothing();
  }
}

// ============================================================================
// ФАЗА 3: ГЛУБИННЫЙ АНАЛИЗ
// ============================================================================
export async function executeDeepAnalysis(opportunityId: string): Promise<void> {
  await db.update(tables.opportunities).set({ status: 'analyzing' }).where(eq(tables.opportunities.id, opportunityId));

  const opportunity = await db.query.opportunities.findFirst({ where: eq(tables.opportunities.id, opportunityId) });
  if (!opportunity || !opportunity.event_url) return;
  
  // Дополнительная разведка
  const deepSearchQueries = generateSearchQueries(`"${opportunity.title}"`, opportunity.location);
  const searchResults = await searchMultipleQueries(deepSearchQueries);
  const snippets = searchResults.map(r => `${r.title}\n${r.description}\n${r.extra_snippets?.join('\n')}`).join('\n\n');
  
  const response = await fetch(opportunity.event_url);
  const html = await response.text();
  const combinedContent = `${html}\n\n---Snippets---\n\n${snippets}`;

  const report = await summarizeContent(combinedContent, opportunity.title);
  const contacts = await extractContacts(html);
  
  await db.update(tables.opportunities)
    .set({ deep_analysis_report: { report } as any, status: 'attack_ready' })
    .where(eq(tables.opportunities.id, opportunityId));

  for (const email of contacts.emails) {
    await db.insert(tables.contacts).values({ opportunity_id: opportunityId, email }).onConflictDoNothing();
  }
  for (const telegram of contacts.telegram) {
    await db.insert(tables.contacts).values({ opportunity_id: opportunityId, telegram }).onConflictDoNothing();
  }
  for (const phone of contacts.phones) {
    await db.insert(tables.contacts).values({ opportunity_id: opportunityId, phone }).onConflictDoNothing();
  }
}

// ============================================================================
// ФАЗА 4: СИНТЕЗ УДАРА (ТОЧНЫЙ ВЫСТРЕЛ)
// ============================================================================
export async function executeStrikeSynthesis(opportunityId: string, speakerProfile: 'corporate' | 'crypto'): Promise<any> {
  const opportunity = await db.query.opportunities.findFirst({ where: eq(tables.opportunities.id, opportunityId) });
  if (!opportunity?.deep_analysis_report) {
    throw new Error('Opportunity or its deep analysis not found.');
  }
  
  const report = (opportunity.deep_analysis_report as any)?.report || '';
  const arsenal = await db.query.intel_assets.findMany({ where: eq(tables.intel_assets.is_active, true) });
  const contacts = await db.query.contacts.findMany({ where: eq(tables.contacts.opportunity_id, opportunityId) });
  const primaryEmail = contacts.find(c => c.email)?.email;

  let pitches = await generatePitchesFromReport(opportunity.title, report, speakerProfile, arsenal);

  if (primaryEmail) {
    pitches = pitches.map(p => ({
      ...p,
      mailto_link: `mailto:${primaryEmail}?subject=${encodeURIComponent(p.subject)}&body=${encodeURIComponent(p.body)}`
    }));
  } else {
    pitches = pitches.map(p => ({ ...p, mailto_link: '#' }));
  }
  
  const [newAttack] = await db.insert(tables.attacks).values({
    opportunity_id: opportunityId,
    generated_pitches: pitches as any,
    speaker_profile: speakerProfile,
  }).returning();
  
  return newAttack;
}


// ============================================================================
// CRUD И ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================================================

export async function getOpportunities(): Promise<Opportunity[]> {
  return db.query.opportunities.findMany({
    orderBy: [
      sql`
        CASE status
          WHEN 'attack_ready' THEN 1
          WHEN 'verified' THEN 2
          WHEN 'scouted' THEN 3
          WHEN 'analyzing' THEN 4
          ELSE 5
        END
      `,
      sql`
        CASE priority
          WHEN 'high' THEN 1
          WHEN 'medium' THEN 2
          WHEN 'low' THEN 3
        END
      `,
      desc(tables.opportunities.scouted_at),
    ],
    where: and(
      not(eq(tables.opportunities.status, 'rejected')),
      not(eq(tables.opportunities.status, 'sent'))
    )
  });
}

export async function updateOpportunityFeedback(opportunityId: string, isGoodFit: boolean): Promise<void> {
  if (isGoodFit === false) {
    await db.update(tables.opportunities)
      .set({ status: 'rejected' })
      .where(eq(tables.opportunities.id, opportunityId));
  }
}

export async function markAttackAsSent(attackId: string, chosenVariant: number, chosenPitch: string): Promise<void> {
    const attack = await db.query.attacks.findFirst({ where: eq(tables.attacks.id, attackId) });
    if (!attack) {
        throw new Error('Attack not found');
    }
    
    await db.update(tables.attacks)
        .set({
            is_sent: true,
            sent_at: new Date(),
            user_chosen_pitch: chosenPitch,
            user_chosen_variant: chosenVariant,
        })
        .where(eq(tables.attacks.id, attackId));
    
    if (attack.opportunity_id) {
        await db.update(tables.opportunities)
            .set({ status: 'sent' })
            .where(eq(tables.opportunities.id, attack.opportunity_id));
    }
}

export async function getProtocolMetrics(): Promise<Metrics> {
     const totalOpportunitiesResult = await db.select({ count: sql<number>`count(*)` }).from(tables.opportunities);
    const totalOpportunities = Number(totalOpportunitiesResult[0].count);
    
    const statusCounts = await db
      .select({ status: tables.opportunities.status, count: sql<number>`count(*)` })
      .from(tables.opportunities)
      .groupBy(tables.opportunities.status);

    const byStatus: Metrics['byStatus'] = {
      scouted: 0, verified: 0, analyzing: 0, attack_ready: 0, sent: 0, rejected: 0, accepted: 0
    };
    statusCounts.forEach(row => {
      if (row.status in byStatus) {
        byStatus[row.status as keyof typeof byStatus] = Number(row.count);
      }
    });

    const acceptedCount = byStatus.accepted;
    const sentCount = byStatus.sent;
    const successRate = (sentCount + acceptedCount) > 0 ? (acceptedCount / (sentCount + acceptedCount)) * 100 : 0;
    
    const avgScoresResult = await db.select({
        alpha: sql<number>`avg(${tables.opportunities.alpha_score})`,
        bravo: sql<number>`avg(${tables.opportunities.bravo_score})`
    }).from(tables.opportunities).where(not(isNull(tables.opportunities.alpha_score)));

    return {
        totalOpportunities,
        byStatus,
        avgScores: {
            alpha: Number(avgScoresResult[0]?.alpha) || 0,
            bravo: Number(avgScoresResult[0]?.bravo) || 0,
        },
        successRate,
    };
}
