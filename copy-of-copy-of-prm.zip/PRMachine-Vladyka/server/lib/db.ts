import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from '@shared/schema-vladyka';

// Hardcoded connection string as per user request for zero-config setup.
const connectionString = "postgresql://postgres.nldzwfopogknvjjhtuns:NeuroMag_1_1@db.nldzwfopogknvjjhtuns.supabase.co:5432/postgres";

const queryClient = postgres(connectionString, {
  max: 10,
  idle_timeout: 20,
  connect_timeout: 10,
});

export const db = drizzle(queryClient, { schema });
export * as tables from '@shared/schema-vladyka';
