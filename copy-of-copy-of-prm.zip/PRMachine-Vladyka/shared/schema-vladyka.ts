import { pgTable, text, integer, boolean, timestamp, jsonb, uuid } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod";

// ============================================================================
// ТАБЛИЦА: intel_assets - Арсенал интеллектуальных активов
// ============================================================================
export const intel_assets = pgTable("intel_assets", {
  id: uuid("id").primaryKey().defaultRandom(),
  asset_type: text("asset_type").notNull(), // 'topic', 'case_study', 'partnership', 'accolade', 'manifesto_quote', 'link', 'past_performance'
  name: text("name").notNull().unique(),
  content: text("content"),
  target_audience_pain_points: text("target_audience_pain_points").array(),
  selection_criteria: text("selection_criteria").array(),
  keywords: text("keywords").array(),
  is_active: boolean("is_active").default(true),
});

export const selectIntelAssetSchema = createSelectSchema(intel_assets);
export type IntelAsset = z.infer<typeof selectIntelAssetSchema>;

// ============================================================================
// ТАБЛИЦА: opportunities - Возможности (мероприятия)
// ============================================================================
export const opportunities = pgTable("opportunities", {
  id: uuid("id").primaryKey().defaultRandom(),
  title: text("title").notNull(),
  description: text("description"),
  event_url: text("event_url").notNull().unique(),
  event_date: text("event_date"),
  location: text("location").notNull(),
  category: text("category"),
  status: text("status").notNull().default("scouted"), // scouted -> verified -> analyzing -> attack_ready -> sent -> rejected
  alpha_score: integer("alpha_score"),
  bravo_score: integer("bravo_score"),
  priority: text("priority").notNull().default("medium"),
  ai_analysis: text("ai_analysis"),
  deep_analysis_report: jsonb("deep_analysis_report"),
  scouted_at: timestamp("scouted_at").defaultNow().notNull(),
});

// ============================================================================
// ТАБЛИЦА: contacts - Контакты организаторов
// ============================================================================
export const contacts = pgTable("contacts", {
  id: uuid("id").primaryKey().defaultRandom(),
  opportunity_id: uuid("opportunity_id").notNull().references(() => opportunities.id, { onDelete: 'cascade' }),
  email: text("email"),
  telegram: text("telegram"),
  phone: text("phone"),
  name: text("name"),
  role: text("role"),
  linkedin_url: text("linkedin_url"),
});

// ============================================================================
// ТАБЛИЦА: attacks - Сгенерированные письма для атаки
// ============================================================================
export const attacks = pgTable("attacks", {
  id: uuid("id").primaryKey().defaultRandom(),
  opportunity_id: uuid("opportunity_id").notNull().references(() => opportunities.id, { onDelete: 'cascade' }),
  generated_pitches: jsonb("generated_pitches").notNull(),
  user_chosen_variant: integer("user_chosen_variant"),
  user_chosen_pitch: text("user_chosen_pitch"),
  is_sent: boolean("is_sent").default(false).notNull(),
  sent_at: timestamp("sent_at"),
  speaker_profile: text("speaker_profile").notNull(), // 'corporate' or 'crypto'
  created_at: timestamp("created_at").defaultNow().notNull(),
});

// ============================================================================
// ZOD СХЕМЫ И ТИПЫ
// ============================================================================
export const selectOpportunitySchema = createSelectSchema(opportunities);
export type Opportunity = z.infer<typeof selectOpportunitySchema>;

export const selectContactSchema = createSelectSchema(contacts);
export type Contact = z.infer<typeof selectContactSchema>;

export const pitchSchema = z.object({
  variant_name: z.string(),
  subject: z.string(),
  body: z.string(),
  mailto_link: z.string(),
});
export type Pitch = z.infer<typeof pitchSchema>;

export const selectAttackSchema = createSelectSchema(attacks, {
  generated_pitches: z.array(pitchSchema)
});
export type Attack = z.infer<typeof selectAttackSchema>;

export const metricsSchema = z.object({
  totalOpportunities: z.number(),
  byStatus: z.object({
    scouted: z.number(),
    verified: z.number(),
    analyzing: z.number(),
    attack_ready: z.number(),
    sent: z.number(),
    rejected: z.number(),
    accepted: z.number(),
  }),
  avgScores: z.object({
    alpha: z.number(),
    bravo: z.number(),
  }),
  successRate: z.number(),
});
export type Metrics = z.infer<typeof metricsSchema>;

export const searchRequestSchema = z.object({
  query: z.string().min(1),
  location: z.enum(['МОСКВА', 'СПб', 'Онлайн', 'Международное', 'Все']).default('Все'),
  dateFrom: z.string().optional(),
  dateTo: z.string().optional(),
});
export type SearchRequest = z.infer<typeof searchRequestSchema>;
