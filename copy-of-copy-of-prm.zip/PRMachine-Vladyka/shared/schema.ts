// This file is deprecated. The new source of truth for schema is `schema-vladyka.ts`.
export {};
