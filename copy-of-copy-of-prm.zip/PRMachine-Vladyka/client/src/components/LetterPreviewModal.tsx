
import { useState, useEffect } from "react";
import { Opportunity, Attack, Pitch } from "@shared/schema-vladyka";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Copy, CheckCircle2, Building2, Coins, Loader2, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LetterPreviewModalProps {
  opportunity: Opportunity | null;
  attack: Attack | null;
  isLoading: boolean;
  isOpen: boolean;
  onClose: () => void;
  onProfileChange: (profile: 'corporate' | 'crypto') => void;
  onMarkAsSent: (data: { attackId: string; chosenVariant: number; chosenPitch: string }) => void;
}

export function LetterPreviewModal({
  opportunity,
  attack,
  isLoading,
  isOpen,
  onClose,
  onProfileChange,
  onMarkAsSent,
}: LetterPreviewModalProps) {
  const [activeTab, setActiveTab] = useState("0");
  const [editedPitches, setEditedPitches] = useState<Record<string, { subject: string; body: string }>>({});
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen) {
      setActiveTab("0");
      setEditedPitches({});
    }
  }, [isOpen]);

  const handleCopy = async () => {
    if (!attack || !attack.generated_pitches) return;
    
    const activePitch = editedPitches[activeTab] || (attack.generated_pitches as Pitch[])[parseInt(activeTab, 10)];
    if (!activePitch) return;
    
    const textToCopy = `Subject: ${activePitch.subject}\n\n${activePitch.body}`;

    await navigator.clipboard.writeText(textToCopy);
    toast({
      title: "Скопировано!",
      description: "Тема и текст письма скопированы в буфер обмена.",
    });
  };
  
  const handleAttack = () => {
    if (!attack || !attack.generated_pitches) return;

    const chosenVariant = parseInt(activeTab, 10);
    const chosenPitchObject = editedPitches[activeTab] || (attack.generated_pitches as Pitch[])[chosenVariant];
    const finalPitchText = `Subject: ${chosenPitchObject.subject}\n\n${chosenPitchObject.body}`;
    
    onMarkAsSent({
      attackId: attack.id,
      chosenVariant,
      chosenPitch: finalPitchText,
    });
  }

  const handleTextChange = (field: 'subject' | 'body', value: string) => {
    const currentPitch = (attack?.generated_pitches as Pitch[] | undefined)?.[parseInt(activeTab, 10)];
    if (!currentPitch) return;

    setEditedPitches(prev => ({
      ...prev,
      [activeTab]: {
        ...(prev[activeTab] || { subject: currentPitch.subject, body: currentPitch.body }),
        [field]: value,
      }
    }));
  };

  if (!opportunity) return null;
  
  const pitches = (attack?.generated_pitches as Pitch[] | undefined) || [];
  const activePitchData = editedPitches[activeTab] || pitches[parseInt(activeTab, 10)];
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col" data-testid="modal-letter-preview">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-3" data-testid="text-modal-title">
            <span>{opportunity.title}</span>
            <Badge variant="outline" data-testid="badge-event-location">
              {opportunity.location}
            </Badge>
          </DialogTitle>
          <DialogDescription data-testid="text-modal-description">
            Синтез Атаки: 3 варианта сопроводительного письма. Протокол "Точный выстрел" активен.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-2 py-3 border-y border-border">
          <span className="text-sm text-muted-foreground">Спикерское досье:</span>
          <Button
            variant={attack?.speaker_profile === 'corporate' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onProfileChange('corporate')}
            className="gap-1.5"
            disabled={isLoading}
          >
            <Building2 className="w-4 h-4" />
            Корпоративное
          </Button>
          <Button
            variant={attack?.speaker_profile === 'crypto' ? 'default' : 'outline'}
            size="sm"
            onClick={() => onProfileChange('crypto')}
            className="gap-1.5"
            disabled={isLoading}
          >
            <Coins className="w-4 h-4" />
            Крипто/Web3
          </Button>
        </div>
        
        <div className="flex-1 overflow-auto pr-6 -mr-6">
          {isLoading ? (
             <div className="flex items-center justify-center h-full min-h-[400px]">
                <div className="text-center space-y-4">
                  <Loader2 className="w-12 h-12 text-primary animate-spin mx-auto" />
                  <p className="font-mono text-muted-foreground">Генерация вариантов атаки...</p>
                  <p className="text-xs text-muted-foreground/50">Протокол "Владыка": Фаза 4</p>
                </div>
             </div>
          ) : (
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                {pitches.map((pitch, index) => (
                  <TabsTrigger key={index} value={String(index)}>{pitch.variant_name}</TabsTrigger>
                ))}
              </TabsList>
              {pitches.map((pitch, index) => (
                <TabsContent key={index} value={String(index)}>
                  <div className="bg-muted/30 p-4 rounded-lg min-h-[400px] flex flex-col gap-4">
                     <Textarea
                        placeholder="Тема письма..."
                        value={editedPitches[String(index)]?.subject ?? pitch.subject}
                        onChange={(e) => handleTextChange('subject', e.target.value)}
                        className="font-bold text-lg bg-background"
                      />
                     <Textarea
                        placeholder="Тело письма..."
                        value={editedPitches[String(index)]?.body ?? pitch.body}
                        onChange={(e) => handleTextChange('body', e.target.value)}
                        className="flex-1 font-serif text-base bg-background"
                        rows={15}
                      />
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          )}
        </div>

        <DialogFooter className="pt-4 gap-2">
          <Button
            asChild
            variant="default"
            className="gap-2 bg-gradient-to-r from-priority-high to-green-600 text-white shadow-glow"
            disabled={isLoading || pitches.length === 0}
            onClick={handleAttack}
          >
            <a href={activePitchData?.mailto_link || '#'}>
              <Send className="w-4 h-4" />
              Атаковать
            </a>
          </Button>
          <Button
            onClick={handleCopy}
            variant="secondary"
            className="gap-2"
            disabled={isLoading || pitches.length === 0}
          >
            <Copy className="w-4 h-4" />
            Копировать
          </Button>
          <Button onClick={onClose} variant="outline">
            Закрыть
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}