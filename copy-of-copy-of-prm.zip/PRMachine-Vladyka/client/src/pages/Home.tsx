import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Opportunity, Attack, Metrics } from "@shared/schema-vladyka";
import { Header } from "@/components/Header";
import { ControlPanel } from "@/components/ControlPanel";
import { EventCard } from "@/components/EventCard";
import { LetterPreviewModal } from "@/components/LetterPreviewModal";
import { MetricsDashboard } from "@/components/MetricsDashboard";
import { EmptyState, RadarSearching } from "@/components/LoadingState";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const defaultMetrics: Metrics = {
  totalOpportunities: 0,
  byStatus: {
    scouted: 0,
    verified: 0,
    analyzing: 0,
    attack_ready: 0,
    sent: 0,
    rejected: 0,
    accepted: 0,
  },
  avgScores: {
    alpha: 0,
    bravo: 0,
  },
  successRate: 0,
};

export default function Home() {
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const { toast } = useToast();

  const { data: opportunities = [], isFetching: isFetchingOpportunities } = useQuery<Opportunity[]>({
    queryKey: ['/api/opportunities'],
    refetchInterval: 3000,
  });

  const { data: metrics = defaultMetrics } = useQuery<Metrics>({
    queryKey: ['/api/metrics'],
    refetchInterval: 3000,
  });

  const searchMutation = useMutation({
    mutationFn: (criteria: any) => apiRequest('POST', '/api/search-events', criteria),
    onSuccess: () => {
      toast({
        title: "Фаза 1: Разведка Запущена",
        description: "Система начала сканирование. Новые цели появятся на панели.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
    },
    onError: (error) => {
      toast({
        title: "Ошибка Разведки",
        description: `Не удалось запустить поиск: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const deepAnalyzeMutation = useMutation({
    mutationFn: (opportunityId: string) => apiRequest('POST', `/api/deep-analyze/${opportunityId}`),
    onSuccess: (data, opportunityId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      toast({
        title: "Фаза 3: Глубинный Анализ",
        description: `Запущен для opportunity ${opportunityId.slice(0, 8)}...`,
      });
    },
     onError: (error) => {
      toast({
        title: "Ошибка Анализа",
        description: `Не удалось запустить анализ: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  const feedbackMutation = useMutation({
    mutationFn: ({ opportunityId, isGoodFit }: { opportunityId: string; isGoodFit: boolean }) =>
      apiRequest('POST', '/api/feedback', { opportunityId, isGoodFit }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      toast({ title: `Цель отклонена и заархивирована.` });
    },
  });

  const attackMutation = useMutation({
    mutationFn: ({ opportunityId, profile }: { opportunityId: string; profile: 'corporate' | 'crypto' }) =>
      apiRequest<Attack>('POST', '/api/generate-pitches', { opportunityId, speakerProfile: profile }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/attacks', selectedOpportunity?.id] });
      toast({
        title: "Фаза 4: Синтез Удара Завершен",
        description: "Варианты атаки сгенерированы.",
      });
    },
    onError: (error) => {
       toast({
        title: "Ошибка Синтеза",
        description: `Не удалось сгенерировать письмо: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const markAsSentMutation = useMutation({
    mutationFn: ({ attackId, chosenVariant, chosenPitch }: { attackId: string; chosenVariant: number; chosenPitch: string; }) =>
      apiRequest('PUT', `/api/attacks/${attackId}`, { chosenVariant, chosenPitch }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/opportunities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/metrics'] });
      toast({
        title: "Атака зафиксирована!",
        description: "Ваш выбор сохранен для будущего анализа.",
      });
    },
  });

  const { data: selectedAttack, isFetching: isFetchingAttack } = useQuery<Attack>({
      queryKey: ['/api/attacks', selectedOpportunity?.id],
      queryFn: () => apiRequest('GET', `/api/attacks/${selectedOpportunity!.id}`),
      enabled: !!selectedOpportunity && isModalOpen,
      refetchOnWindowFocus: false,
  });

  const handleSearch = (criteria: any) => {
    searchMutation.mutate(criteria);
  };

  const handleAccept = (opportunityId: string) => {
    deepAnalyzeMutation.mutate(opportunityId);
  };

  const handleReject = (opportunityId: string) => {
    feedbackMutation.mutate({ opportunityId, isGoodFit: false });
  };

  const handleViewDetails = (opportunity: Opportunity) => {
    setSelectedOpportunity(opportunity);
    setIsModalOpen(true);
    if (opportunity.status === 'attack_ready') {
      attackMutation.mutate({ opportunityId: opportunity.id, profile: 'corporate' });
    }
  };

  const handleProfileChange = (profile: 'corporate' | 'crypto') => {
    if (selectedOpportunity) {
      attackMutation.mutate({ opportunityId: selectedOpportunity.id, profile });
    }
  };
  
  const isSearching = searchMutation.isPending;
  const isListLoading = isFetchingOpportunities && !isSearching && opportunities.length === 0;

  return (
    <div className="min-h-screen bg-background">
      <Header 
        totalEvents={metrics.totalOpportunities} 
        successRate={metrics.successRate} 
      />
      
      <div className="flex h-[calc(100vh-80px)]">
        <aside className="w-80 flex-shrink-0">
          <ControlPanel 
            onSearch={handleSearch} 
            isSearching={isSearching} 
          />
        </aside>

        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-5xl mx-auto space-y-4">
            {(isSearching || isListLoading) && <RadarSearching />}
            
            {!isSearching && !isListLoading && opportunities.length === 0 && <EmptyState />}
            
            {!isSearching && opportunities.length > 0 && opportunities.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                onAccept={handleAccept}
                onReject={handleReject}
                onViewDetails={handleViewDetails}
                isAnalyzing={deepAnalyzeMutation.isPending && deepAnalyzeMutation.variables === event.id}
              />
            ))}
          </div>
        </main>

        <aside className="w-80 flex-shrink-0">
          <MetricsDashboard metrics={metrics} />
        </aside>
      </div>

      <LetterPreviewModal
        opportunity={selectedOpportunity}
        attack={selectedAttack || null}
        isLoading={isFetchingAttack || attackMutation.isPending}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedOpportunity(null);
          queryClient.removeQueries({ queryKey: ['/api/attacks'] })
        }}
        onProfileChange={handleProfileChange}
        onMarkAsSent={markAsSentMutation.mutate}
      />
    </div>
  );
}