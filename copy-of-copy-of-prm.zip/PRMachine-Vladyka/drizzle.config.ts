import { defineConfig } from 'drizzle-kit';

export default defineConfig({
  schema: './shared/schema-vladyka.ts',
  out: './drizzle',
  dialect: 'postgresql',
  dbCredentials: {
    // Hardcoded connection string as per user request for zero-config setup.
    url: "postgresql://postgres.nldzwfopogknvjjhtuns:NeuroMag_1_1@db.nldzwfopogknvjjhtuns.supabase.co:5432/postgres",
  },
  verbose: true,
  strict: true,
});
